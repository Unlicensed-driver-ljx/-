/****************************************************************************
** Meta object code from reading C++ file 'onlinetunedialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../camlink/H264code1210/H264code/QTracker_booster_G4040/UI/onlinetunedialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'onlinetunedialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_OnlineTuneDialog_t {
    QByteArrayData data[73];
    char stringdata0[1513];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_OnlineTuneDialog_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_OnlineTuneDialog_t qt_meta_stringdata_OnlineTuneDialog = {
    {
QT_MOC_LITERAL(0, 0, 16), // "OnlineTuneDialog"
QT_MOC_LITERAL(1, 17, 12), // "onG400Detect"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 5), // "state"
QT_MOC_LITERAL(4, 37, 25), // "onDisplayContrastUpFactor"
QT_MOC_LITERAL(5, 63, 3), // "val"
QT_MOC_LITERAL(6, 67, 26), // "onDisplayContrastLowFactor"
QT_MOC_LITERAL(7, 94, 11), // "onSaveImage"
QT_MOC_LITERAL(8, 106, 21), // "onTrackChangeThresh_0"
QT_MOC_LITERAL(9, 128, 21), // "onTrackChangeThresh_1"
QT_MOC_LITERAL(10, 150, 21), // "onTrackChangeThresh_3"
QT_MOC_LITERAL(11, 172, 32), // "onG400CamerasaveimagestateChange"
QT_MOC_LITERAL(12, 205, 5), // "index"
QT_MOC_LITERAL(13, 211, 26), // "onG400Camerastartsaveimage"
QT_MOC_LITERAL(14, 238, 25), // "onG400Camerastopsaveimage"
QT_MOC_LITERAL(15, 264, 16), // "btnToggleddisply"
QT_MOC_LITERAL(16, 281, 7), // "checked"
QT_MOC_LITERAL(17, 289, 17), // "btnToggleddisplyC"
QT_MOC_LITERAL(18, 307, 18), // "btnToggleddisplyLU"
QT_MOC_LITERAL(19, 326, 18), // "btnToggleddisplyLD"
QT_MOC_LITERAL(20, 345, 18), // "btnToggleddisplyRU"
QT_MOC_LITERAL(21, 364, 18), // "btnToggleddisplyRD"
QT_MOC_LITERAL(22, 383, 25), // "onG400CameraAuxiliaryLine"
QT_MOC_LITERAL(23, 409, 25), // "btnToggledshowByteStretch"
QT_MOC_LITERAL(24, 435, 25), // "btnToggledshowMeanStretch"
QT_MOC_LITERAL(25, 461, 29), // "btnToggledshowSkylightStretch"
QT_MOC_LITERAL(26, 491, 19), // "onG400CameraSetType"
QT_MOC_LITERAL(27, 511, 18), // "onG400ImageBitShow"
QT_MOC_LITERAL(28, 530, 21), // "SetLongWaveCameraType"
QT_MOC_LITERAL(29, 552, 23), // "SetMediumWaveCameraType"
QT_MOC_LITERAL(30, 576, 31), // "SetMediumWaveInfraredCameraType"
QT_MOC_LITERAL(31, 608, 25), // "SetVisibleLightCameraType"
QT_MOC_LITERAL(32, 634, 15), // "SetNoCameraMode"
QT_MOC_LITERAL(33, 650, 10), // "Delay_MSec"
QT_MOC_LITERAL(34, 661, 4), // "msec"
QT_MOC_LITERAL(35, 666, 28), // "btnToggledGuideModeTradition"
QT_MOC_LITERAL(36, 695, 28), // "btnToggledGuideModeSinglerod"
QT_MOC_LITERAL(37, 724, 22), // "onTrackChangeTrackGate"
QT_MOC_LITERAL(38, 747, 24), // "btnToggledTrackTradition"
QT_MOC_LITERAL(39, 772, 19), // "btnToggledTrackAI_1"
QT_MOC_LITERAL(40, 792, 19), // "btnToggledTrackAI_2"
QT_MOC_LITERAL(41, 812, 30), // "btnToggledModeTraditionXingxin"
QT_MOC_LITERAL(42, 843, 29), // "btnToggledModeTraditionZhixin"
QT_MOC_LITERAL(43, 873, 25), // "btnToggledModeTraditionUp"
QT_MOC_LITERAL(44, 899, 27), // "btnToggledModeTraditionDown"
QT_MOC_LITERAL(45, 927, 27), // "btnToggledModeTraditionLeft"
QT_MOC_LITERAL(46, 955, 28), // "btnToggledModeTraditionRight"
QT_MOC_LITERAL(47, 984, 29), // "btnToggledModeTraditionLeftUp"
QT_MOC_LITERAL(48, 1014, 31), // "btnToggledModeTraditionLeftDown"
QT_MOC_LITERAL(49, 1046, 30), // "btnToggledModeTraditionRightUp"
QT_MOC_LITERAL(50, 1077, 32), // "btnToggledModeTraditionRightDown"
QT_MOC_LITERAL(51, 1110, 23), // "ImageProcessingLoadPath"
QT_MOC_LITERAL(52, 1134, 27), // "ImageProcessingDisplayStart"
QT_MOC_LITERAL(53, 1162, 25), // "ImageProcessingDisplayEnd"
QT_MOC_LITERAL(54, 1188, 31), // "ImageProcessingStartMeasurement"
QT_MOC_LITERAL(55, 1220, 31), // "ImageProcessingMeasurementShape"
QT_MOC_LITERAL(56, 1252, 24), // "ImageProcessingDataEmpty"
QT_MOC_LITERAL(57, 1277, 18), // "OpenSoftwareManual"
QT_MOC_LITERAL(58, 1296, 13), // "saveHistogram"
QT_MOC_LITERAL(59, 1310, 4), // "path"
QT_MOC_LITERAL(60, 1315, 1), // "S"
QT_MOC_LITERAL(61, 1317, 3), // "Mat"
QT_MOC_LITERAL(62, 1321, 1), // "D"
QT_MOC_LITERAL(63, 1323, 14), // "saveProjection"
QT_MOC_LITERAL(64, 1338, 17), // "onC640CameraState"
QT_MOC_LITERAL(65, 1356, 23), // "CameraSetCameraLinkMode"
QT_MOC_LITERAL(66, 1380, 20), // "CameraSetImageFormat"
QT_MOC_LITERAL(67, 1401, 15), // "CameraImageLive"
QT_MOC_LITERAL(68, 1417, 17), // "CameraImageunLive"
QT_MOC_LITERAL(69, 1435, 17), // "CameraSetImageBit"
QT_MOC_LITERAL(70, 1453, 17), // "CameraSetImageTap"
QT_MOC_LITERAL(71, 1471, 18), // "CameraEleImageStab"
QT_MOC_LITERAL(72, 1490, 22) // "CameraImageEnhancement"

    },
    "OnlineTuneDialog\0onG400Detect\0\0state\0"
    "onDisplayContrastUpFactor\0val\0"
    "onDisplayContrastLowFactor\0onSaveImage\0"
    "onTrackChangeThresh_0\0onTrackChangeThresh_1\0"
    "onTrackChangeThresh_3\0"
    "onG400CamerasaveimagestateChange\0index\0"
    "onG400Camerastartsaveimage\0"
    "onG400Camerastopsaveimage\0btnToggleddisply\0"
    "checked\0btnToggleddisplyC\0btnToggleddisplyLU\0"
    "btnToggleddisplyLD\0btnToggleddisplyRU\0"
    "btnToggleddisplyRD\0onG400CameraAuxiliaryLine\0"
    "btnToggledshowByteStretch\0"
    "btnToggledshowMeanStretch\0"
    "btnToggledshowSkylightStretch\0"
    "onG400CameraSetType\0onG400ImageBitShow\0"
    "SetLongWaveCameraType\0SetMediumWaveCameraType\0"
    "SetMediumWaveInfraredCameraType\0"
    "SetVisibleLightCameraType\0SetNoCameraMode\0"
    "Delay_MSec\0msec\0btnToggledGuideModeTradition\0"
    "btnToggledGuideModeSinglerod\0"
    "onTrackChangeTrackGate\0btnToggledTrackTradition\0"
    "btnToggledTrackAI_1\0btnToggledTrackAI_2\0"
    "btnToggledModeTraditionXingxin\0"
    "btnToggledModeTraditionZhixin\0"
    "btnToggledModeTraditionUp\0"
    "btnToggledModeTraditionDown\0"
    "btnToggledModeTraditionLeft\0"
    "btnToggledModeTraditionRight\0"
    "btnToggledModeTraditionLeftUp\0"
    "btnToggledModeTraditionLeftDown\0"
    "btnToggledModeTraditionRightUp\0"
    "btnToggledModeTraditionRightDown\0"
    "ImageProcessingLoadPath\0"
    "ImageProcessingDisplayStart\0"
    "ImageProcessingDisplayEnd\0"
    "ImageProcessingStartMeasurement\0"
    "ImageProcessingMeasurementShape\0"
    "ImageProcessingDataEmpty\0OpenSoftwareManual\0"
    "saveHistogram\0path\0S\0Mat\0D\0saveProjection\0"
    "onC640CameraState\0CameraSetCameraLinkMode\0"
    "CameraSetImageFormat\0CameraImageLive\0"
    "CameraImageunLive\0CameraSetImageBit\0"
    "CameraSetImageTap\0CameraEleImageStab\0"
    "CameraImageEnhancement"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_OnlineTuneDialog[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      62,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  324,    2, 0x0a /* Public */,
       4,    1,  327,    2, 0x0a /* Public */,
       6,    1,  330,    2, 0x0a /* Public */,
       7,    0,  333,    2, 0x0a /* Public */,
       8,    1,  334,    2, 0x0a /* Public */,
       9,    1,  337,    2, 0x0a /* Public */,
      10,    1,  340,    2, 0x0a /* Public */,
      11,    1,  343,    2, 0x0a /* Public */,
      13,    0,  346,    2, 0x0a /* Public */,
      14,    0,  347,    2, 0x0a /* Public */,
      15,    1,  348,    2, 0x0a /* Public */,
      17,    1,  351,    2, 0x0a /* Public */,
      18,    1,  354,    2, 0x0a /* Public */,
      19,    1,  357,    2, 0x0a /* Public */,
      20,    1,  360,    2, 0x0a /* Public */,
      21,    1,  363,    2, 0x0a /* Public */,
      22,    1,  366,    2, 0x0a /* Public */,
      23,    1,  369,    2, 0x0a /* Public */,
      24,    1,  372,    2, 0x0a /* Public */,
      25,    1,  375,    2, 0x0a /* Public */,
      26,    1,  378,    2, 0x0a /* Public */,
      27,    1,  381,    2, 0x0a /* Public */,
      28,    0,  384,    2, 0x0a /* Public */,
      29,    0,  385,    2, 0x0a /* Public */,
      30,    0,  386,    2, 0x0a /* Public */,
      31,    0,  387,    2, 0x0a /* Public */,
      32,    0,  388,    2, 0x0a /* Public */,
      33,    1,  389,    2, 0x0a /* Public */,
      35,    1,  392,    2, 0x0a /* Public */,
      36,    1,  395,    2, 0x0a /* Public */,
      37,    1,  398,    2, 0x0a /* Public */,
      38,    1,  401,    2, 0x0a /* Public */,
      39,    1,  404,    2, 0x0a /* Public */,
      40,    1,  407,    2, 0x0a /* Public */,
      41,    1,  410,    2, 0x0a /* Public */,
      42,    1,  413,    2, 0x0a /* Public */,
      43,    1,  416,    2, 0x0a /* Public */,
      44,    1,  419,    2, 0x0a /* Public */,
      45,    1,  422,    2, 0x0a /* Public */,
      46,    1,  425,    2, 0x0a /* Public */,
      47,    1,  428,    2, 0x0a /* Public */,
      48,    1,  431,    2, 0x0a /* Public */,
      49,    1,  434,    2, 0x0a /* Public */,
      50,    1,  437,    2, 0x0a /* Public */,
      51,    0,  440,    2, 0x0a /* Public */,
      52,    0,  441,    2, 0x0a /* Public */,
      53,    0,  442,    2, 0x0a /* Public */,
      54,    1,  443,    2, 0x0a /* Public */,
      55,    1,  446,    2, 0x0a /* Public */,
      56,    0,  449,    2, 0x0a /* Public */,
      57,    0,  450,    2, 0x0a /* Public */,
      58,    3,  451,    2, 0x0a /* Public */,
      63,    3,  458,    2, 0x0a /* Public */,
      64,    0,  465,    2, 0x0a /* Public */,
      65,    1,  466,    2, 0x0a /* Public */,
      66,    1,  469,    2, 0x0a /* Public */,
      67,    1,  472,    2, 0x0a /* Public */,
      68,    1,  475,    2, 0x0a /* Public */,
      69,    1,  478,    2, 0x0a /* Public */,
      70,    1,  481,    2, 0x0a /* Public */,
      71,    1,  484,    2, 0x0a /* Public */,
      72,    1,  487,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,   34,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, 0x80000000 | 61,   59,   60,   62,
    QMetaType::Void, QMetaType::QString, QMetaType::Int, 0x80000000 | 61,   59,   60,   62,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Bool,   16,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,

       0        // eod
};

void OnlineTuneDialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<OnlineTuneDialog *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->onG400Detect((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: _t->onDisplayContrastUpFactor((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 2: _t->onDisplayContrastLowFactor((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 3: _t->onSaveImage(); break;
        case 4: _t->onTrackChangeThresh_0((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 5: _t->onTrackChangeThresh_1((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 6: _t->onTrackChangeThresh_3((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->onG400CamerasaveimagestateChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: _t->onG400Camerastartsaveimage(); break;
        case 9: _t->onG400Camerastopsaveimage(); break;
        case 10: _t->btnToggleddisply((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->btnToggleddisplyC((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 12: _t->btnToggleddisplyLU((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->btnToggleddisplyLD((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 14: _t->btnToggleddisplyRU((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 15: _t->btnToggleddisplyRD((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 16: _t->onG400CameraAuxiliaryLine((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->btnToggledshowByteStretch((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->btnToggledshowMeanStretch((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->btnToggledshowSkylightStretch((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 20: _t->onG400CameraSetType((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 21: _t->onG400ImageBitShow((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 22: _t->SetLongWaveCameraType(); break;
        case 23: _t->SetMediumWaveCameraType(); break;
        case 24: _t->SetMediumWaveInfraredCameraType(); break;
        case 25: _t->SetVisibleLightCameraType(); break;
        case 26: _t->SetNoCameraMode(); break;
        case 27: _t->Delay_MSec((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 28: _t->btnToggledGuideModeTradition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 29: _t->btnToggledGuideModeSinglerod((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 30: _t->onTrackChangeTrackGate((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 31: _t->btnToggledTrackTradition((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 32: _t->btnToggledTrackAI_1((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 33: _t->btnToggledTrackAI_2((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 34: _t->btnToggledModeTraditionXingxin((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 35: _t->btnToggledModeTraditionZhixin((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 36: _t->btnToggledModeTraditionUp((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 37: _t->btnToggledModeTraditionDown((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 38: _t->btnToggledModeTraditionLeft((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 39: _t->btnToggledModeTraditionRight((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 40: _t->btnToggledModeTraditionLeftUp((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 41: _t->btnToggledModeTraditionLeftDown((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 42: _t->btnToggledModeTraditionRightUp((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 43: _t->btnToggledModeTraditionRightDown((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 44: _t->ImageProcessingLoadPath(); break;
        case 45: _t->ImageProcessingDisplayStart(); break;
        case 46: _t->ImageProcessingDisplayEnd(); break;
        case 47: _t->ImageProcessingStartMeasurement((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 48: _t->ImageProcessingMeasurementShape((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 49: _t->ImageProcessingDataEmpty(); break;
        case 50: _t->OpenSoftwareManual(); break;
        case 51: _t->saveHistogram((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< Mat(*)>(_a[3]))); break;
        case 52: _t->saveProjection((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< Mat(*)>(_a[3]))); break;
        case 53: _t->onC640CameraState(); break;
        case 54: _t->CameraSetCameraLinkMode((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 55: _t->CameraSetImageFormat((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 56: _t->CameraImageLive((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 57: _t->CameraImageunLive((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 58: _t->CameraSetImageBit((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 59: _t->CameraSetImageTap((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 60: _t->CameraEleImageStab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 61: _t->CameraImageEnhancement((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject OnlineTuneDialog::staticMetaObject = { {
    QMetaObject::SuperData::link<QDialog::staticMetaObject>(),
    qt_meta_stringdata_OnlineTuneDialog.data,
    qt_meta_data_OnlineTuneDialog,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *OnlineTuneDialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *OnlineTuneDialog::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_OnlineTuneDialog.stringdata0))
        return static_cast<void*>(this);
    return QDialog::qt_metacast(_clname);
}

int OnlineTuneDialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 62)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 62;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 62)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 62;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
