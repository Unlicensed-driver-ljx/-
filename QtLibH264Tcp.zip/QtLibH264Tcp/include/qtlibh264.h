#ifndef QTLIBH264_H
#define QTLIBH264_H

#include "QtLibH264_global.h"

class QTLIBH264_EXPORT QtLibH264
{
public:
    QtLibH264();
};

#endif // QTLIBH264_H
