/********************************************************************************
** Form generated from reading UI file 'onlinetunedialog.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ONLINETUNEDIALOG_H
#define UI_ONLINETUNEDIALOG_H

#include <QtCore/QLocale>
#include <QtCore/QVariant>
#include <QtGui/QIcon>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_OnlineTuneDialog
{
public:
    QGridLayout *gridLayout;
    QTabWidget *tabWidget;
    QWidget *tab;
    QGridLayout *gridLayout_10;
    QGroupBox *groupBox_34;
    QPushButton *pushButtonCameraState;
    QGroupBox *groupBox_11;
    QLabel *label;
    QComboBox *comboBoxsaveimagestate;
    QPushButton *pushButtonSaveImage;
    QPushButton *pushButtonstartsaveimage;
    QPushButton *pushButtonstopsaveimage;
    QProgressBar *progressBarsaveimage;
    QLabel *labelsaveimage;
    QGroupBox *groupBox_21;
    QComboBox *comboBoxType;
    QLabel *label_13;
    QLabel *labelCameraSize;
    QSpacerItem *verticalSpacer_2;
    QGroupBox *groupBox_3;
    QWidget *gridLayoutWidget;
    QGridLayout *gridLayout_2;
    QLineEdit *lineEditResolutionW;
    QLabel *label_15;
    QLabel *label_16;
    QLabel *label_5;
    QLabel *label_17;
    QLabel *label_20;
    QLabel *label_10;
    QLabel *label_14;
    QComboBox *comboBoxCameraLinkMode;
    QLineEdit *lineEditResolutionH;
    QComboBox *comboBoxImageFormat;
    QRadioButton *radioButtonlive;
    QRadioButton *radioButtonunlive;
    QSpinBox *spinBoxImageBit;
    QSpinBox *spinBoxImageTap;
    QWidget *tab_4;
    QGridLayout *gridLayout_6;
    QGroupBox *groupBox_7;
    QRadioButton *radioButtondisplyLU;
    QRadioButton *radioButtondisplyLD;
    QRadioButton *radioButtondisplyRU;
    QRadioButton *radioButtondisplyRD;
    QRadioButton *radioButtondisplyC;
    QRadioButton *radioButtondisply;
    QGroupBox *groupBox_2;
    QGridLayout *gridLayout_5;
    QLabel *label_4;
    QLabel *label_3;
    QRadioButton *radioButtonshowByteStretch;
    QRadioButton *radioButtonshowMeanStretch;
    QRadioButton *radioButtonshowSkylightStretch;
    QDoubleSpinBox *doubleSpinBoxContrastUpFactor;
    QDoubleSpinBox *doubleSpinBoxContrastLowFactor;
    QComboBox *comboBoxImageBitShow;
    QLabel *label_54;
    QGroupBox *groupBox_6;
    QLCDNumber *lcdNumberDiskSpace;
    QLabel *label_2;
    QGroupBox *groupBox;
    QLabel *label_44;
    QLCDNumber *lcdNumberTime;
    QLabel *label_46;
    QLabel *label_47;
    QLabel *label_48;
    QLabel *label_50;
    QLabel *label_51;
    QLabel *label_52;
    QLabel *label_53;
    QLCDNumber *lcdNumberGain;
    QLCDNumber *lcdNumberExptime;
    QLCDNumber *lcdNumberAzimuth;
    QLCDNumber *lcdNumberElevatio;
    QLCDNumber *lcdNumberLongitude;
    QLCDNumber *lcdNumberLatitude;
    QLCDNumber *lcdNumberAltitude;
    QLCDNumber *lcdNumberMistiming;
    QLCDNumber *lcdNumberElevatioZero;
    QLabel *label_56;
    QLCDNumber *lcdNumberAzimuthZero;
    QLabel *label_57;
    QLabel *label_49;
    QCheckBox *checkBoxDATpowerstate;
    QCheckBox *checkBoxDATsavefitsstate;
    QGroupBox *groupBox_18;
    QCheckBox *checkBoxAuxiliaryLine;
    QSpacerItem *verticalSpacer;
    QGroupBox *groupBox_8;
    QCheckBox *checkBoxEleImageStab;
    QCheckBox *checkBoxImageEnhancement;
    QWidget *tab_3;
    QGroupBox *groupBox_27;
    QRadioButton *radioButtonModeTraditionXingxin;
    QRadioButton *radioButtonModeTraditionZhixin;
    QRadioButton *radioButtonModeTraditionUp;
    QRadioButton *radioButtonModeTraditionDown;
    QRadioButton *radioButtonModeTraditionLeft;
    QRadioButton *radioButtonModeTraditionRight;
    QRadioButton *radioButtonModeTraditionLeftUp;
    QRadioButton *radioButtonModeTraditionLeftDown;
    QRadioButton *radioButtonModeTraditionRightUp;
    QRadioButton *radioButtonModeTraditionRightDown;
    QGroupBox *groupBox_25;
    QRadioButton *radioButtonGuideModeTradition;
    QRadioButton *radioButtonGuideModeSinglerod;
    QGroupBox *groupBox_26;
    QRadioButton *radioButtonTrackTradition;
    QRadioButton *radioButtonTrackAI_1;
    QGroupBox *groupBox_28;
    QCheckBox *checkBoxDetect;
    QGroupBox *groupBox_29;
    QSpinBox *spinBoxSetTrackGateSize;
    QLabel *label_24;
    QLabel *label_25;
    QSpinBox *spinBoxthresTradition;
    QCheckBox *checkBoxAutoThresTradition;
    QLabel *label_26;
    QSpinBox *spinBoxminSizeTradition;
    QGroupBox *groupBox_30;
    QDoubleSpinBox *doubleSpinBoxTrackThresh_0;
    QSpinBox *spinBoxTrackThresh_3;
    QDoubleSpinBox *doubleSpinBoxTrackThresh_1;
    QLabel *label_9;
    QLabel *label_28;
    QLabel *label_29;
    QWidget *tab_9;
    QGroupBox *groupBox_19;
    QPushButton *pushButtonImagePath;
    QTextEdit *textEditImagePath;
    QPushButton *pushButtonImageDisplayStart;
    QPushButton *pushButtonImageDisplayEnd;
    QGroupBox *groupBox_4;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_11;
    QLCDNumber *lcdNumberMeanValue;
    QLCDNumber *lcdNumberVariance;
    QLCDNumber *lcdNumberMaxGrayValue;
    QLCDNumber *lcdNumberMinGrayValue;
    QGroupBox *groupBox_5;
    QLabel *label_30;
    QLabel *label_31;
    QLCDNumber *lcdNumberStartXY;
    QLCDNumber *lcdNumberEndXY;
    QLabel *label_32;
    QLabel *label_33;
    QLabel *label_34;
    QLCDNumber *lcdNumberHorizontalDistance;
    QLCDNumber *lcdNumberVerticalDistance;
    QLCDNumber *lcdNumberRegionalArea;
    QCheckBox *checkBoxStartMeasurement;
    QPushButton *pushButtonDataEmpty;
    QLabel *label_42;
    QComboBox *comboBoxMeasurementShape;
    QWidget *tab_5;
    QGroupBox *groupBox_31;
    QLabel *label_12;
    QLabel *label_36;
    QLabel *label_37;
    QPushButton *pushButtonLOGO;
    QLabel *label_38;
    QLabel *label_39;
    QLabel *label_40;
    QLabel *label_41;
    QPushButton *pushButtonURL;
    QGroupBox *groupBox_32;
    QPushButton *pushButtonSoftwareManual;

    void setupUi(QDialog *OnlineTuneDialog)
    {
        if (OnlineTuneDialog->objectName().isEmpty())
            OnlineTuneDialog->setObjectName(QString::fromUtf8("OnlineTuneDialog"));
        OnlineTuneDialog->resize(367, 1117);
        OnlineTuneDialog->setMinimumSize(QSize(367, 0));
        OnlineTuneDialog->setMaximumSize(QSize(367, 16777215));
        gridLayout = new QGridLayout(OnlineTuneDialog);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        tabWidget = new QTabWidget(OnlineTuneDialog);
        tabWidget->setObjectName(QString::fromUtf8("tabWidget"));
        tab = new QWidget();
        tab->setObjectName(QString::fromUtf8("tab"));
        gridLayout_10 = new QGridLayout(tab);
        gridLayout_10->setObjectName(QString::fromUtf8("gridLayout_10"));
        groupBox_34 = new QGroupBox(tab);
        groupBox_34->setObjectName(QString::fromUtf8("groupBox_34"));
        groupBox_34->setMinimumSize(QSize(0, 65));
        groupBox_34->setMaximumSize(QSize(16777215, 62));
        pushButtonCameraState = new QPushButton(groupBox_34);
        pushButtonCameraState->setObjectName(QString::fromUtf8("pushButtonCameraState"));
        pushButtonCameraState->setGeometry(QRect(70, 30, 201, 23));

        gridLayout_10->addWidget(groupBox_34, 3, 0, 1, 1);

        groupBox_11 = new QGroupBox(tab);
        groupBox_11->setObjectName(QString::fromUtf8("groupBox_11"));
        groupBox_11->setMinimumSize(QSize(0, 120));
        groupBox_11->setMaximumSize(QSize(16777215, 120));
        label = new QLabel(groupBox_11);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(10, 30, 40, 26));
        label->setMaximumSize(QSize(40, 16777215));
        comboBoxsaveimagestate = new QComboBox(groupBox_11);
        comboBoxsaveimagestate->addItem(QString());
        comboBoxsaveimagestate->addItem(QString());
        comboBoxsaveimagestate->addItem(QString());
        comboBoxsaveimagestate->addItem(QString());
        comboBoxsaveimagestate->setObjectName(QString::fromUtf8("comboBoxsaveimagestate"));
        comboBoxsaveimagestate->setGeometry(QRect(70, 30, 90, 25));
        comboBoxsaveimagestate->setMinimumSize(QSize(0, 15));
        comboBoxsaveimagestate->setMaximumSize(QSize(90, 25));
        pushButtonSaveImage = new QPushButton(groupBox_11);
        pushButtonSaveImage->setObjectName(QString::fromUtf8("pushButtonSaveImage"));
        pushButtonSaveImage->setGeometry(QRect(170, 30, 101, 26));
        pushButtonstartsaveimage = new QPushButton(groupBox_11);
        pushButtonstartsaveimage->setObjectName(QString::fromUtf8("pushButtonstartsaveimage"));
        pushButtonstartsaveimage->setGeometry(QRect(70, 60, 91, 25));
        pushButtonstartsaveimage->setMinimumSize(QSize(0, 15));
        pushButtonstartsaveimage->setMaximumSize(QSize(16777215, 25));
        pushButtonstopsaveimage = new QPushButton(groupBox_11);
        pushButtonstopsaveimage->setObjectName(QString::fromUtf8("pushButtonstopsaveimage"));
        pushButtonstopsaveimage->setGeometry(QRect(170, 60, 101, 25));
        pushButtonstopsaveimage->setMinimumSize(QSize(0, 15));
        pushButtonstopsaveimage->setMaximumSize(QSize(16777215, 25));
        progressBarsaveimage = new QProgressBar(groupBox_11);
        progressBarsaveimage->setObjectName(QString::fromUtf8("progressBarsaveimage"));
        progressBarsaveimage->setGeometry(QRect(70, 90, 201, 23));
        progressBarsaveimage->setLocale(QLocale(QLocale::Chinese, QLocale::China));
        progressBarsaveimage->setValue(0);
        labelsaveimage = new QLabel(groupBox_11);
        labelsaveimage->setObjectName(QString::fromUtf8("labelsaveimage"));
        labelsaveimage->setGeometry(QRect(280, 90, 31, 20));

        gridLayout_10->addWidget(groupBox_11, 5, 0, 1, 1);

        groupBox_21 = new QGroupBox(tab);
        groupBox_21->setObjectName(QString::fromUtf8("groupBox_21"));
        groupBox_21->setMinimumSize(QSize(0, 62));
        groupBox_21->setMaximumSize(QSize(16777215, 62));
        comboBoxType = new QComboBox(groupBox_21);
        comboBoxType->addItem(QString());
        comboBoxType->addItem(QString());
        comboBoxType->addItem(QString());
        comboBoxType->addItem(QString());
        comboBoxType->addItem(QString());
        comboBoxType->setObjectName(QString::fromUtf8("comboBoxType"));
        comboBoxType->setGeometry(QRect(60, 30, 141, 23));
        label_13 = new QLabel(groupBox_21);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(10, 30, 59, 21));
        labelCameraSize = new QLabel(groupBox_21);
        labelCameraSize->setObjectName(QString::fromUtf8("labelCameraSize"));
        labelCameraSize->setGeometry(QRect(220, 30, 91, 21));

        gridLayout_10->addWidget(groupBox_21, 0, 0, 1, 1);

        verticalSpacer_2 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_10->addItem(verticalSpacer_2, 6, 0, 1, 1);

        groupBox_3 = new QGroupBox(tab);
        groupBox_3->setObjectName(QString::fromUtf8("groupBox_3"));
        groupBox_3->setMinimumSize(QSize(0, 260));
        gridLayoutWidget = new QWidget(groupBox_3);
        gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
        gridLayoutWidget->setGeometry(QRect(10, 30, 301, 225));
        gridLayout_2 = new QGridLayout(gridLayoutWidget);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        lineEditResolutionW = new QLineEdit(gridLayoutWidget);
        lineEditResolutionW->setObjectName(QString::fromUtf8("lineEditResolutionW"));

        gridLayout_2->addWidget(lineEditResolutionW, 0, 2, 1, 1);

        label_15 = new QLabel(gridLayoutWidget);
        label_15->setObjectName(QString::fromUtf8("label_15"));

        gridLayout_2->addWidget(label_15, 2, 0, 1, 1);

        label_16 = new QLabel(gridLayoutWidget);
        label_16->setObjectName(QString::fromUtf8("label_16"));

        gridLayout_2->addWidget(label_16, 3, 0, 1, 1);

        label_5 = new QLabel(gridLayoutWidget);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_2->addWidget(label_5, 0, 0, 1, 1);

        label_17 = new QLabel(gridLayoutWidget);
        label_17->setObjectName(QString::fromUtf8("label_17"));

        gridLayout_2->addWidget(label_17, 4, 0, 1, 1);

        label_20 = new QLabel(gridLayoutWidget);
        label_20->setObjectName(QString::fromUtf8("label_20"));

        gridLayout_2->addWidget(label_20, 5, 0, 1, 1);

        label_10 = new QLabel(gridLayoutWidget);
        label_10->setObjectName(QString::fromUtf8("label_10"));

        gridLayout_2->addWidget(label_10, 0, 1, 1, 1);

        label_14 = new QLabel(gridLayoutWidget);
        label_14->setObjectName(QString::fromUtf8("label_14"));

        gridLayout_2->addWidget(label_14, 1, 1, 1, 1);

        comboBoxCameraLinkMode = new QComboBox(gridLayoutWidget);
        comboBoxCameraLinkMode->addItem(QString());
        comboBoxCameraLinkMode->addItem(QString());
        comboBoxCameraLinkMode->addItem(QString());
        comboBoxCameraLinkMode->setObjectName(QString::fromUtf8("comboBoxCameraLinkMode"));

        gridLayout_2->addWidget(comboBoxCameraLinkMode, 2, 2, 1, 1);

        lineEditResolutionH = new QLineEdit(gridLayoutWidget);
        lineEditResolutionH->setObjectName(QString::fromUtf8("lineEditResolutionH"));

        gridLayout_2->addWidget(lineEditResolutionH, 1, 2, 1, 1);

        comboBoxImageFormat = new QComboBox(gridLayoutWidget);
        comboBoxImageFormat->addItem(QString());
        comboBoxImageFormat->setObjectName(QString::fromUtf8("comboBoxImageFormat"));

        gridLayout_2->addWidget(comboBoxImageFormat, 5, 2, 1, 1);

        radioButtonlive = new QRadioButton(gridLayoutWidget);
        radioButtonlive->setObjectName(QString::fromUtf8("radioButtonlive"));

        gridLayout_2->addWidget(radioButtonlive, 6, 0, 1, 1);

        radioButtonunlive = new QRadioButton(gridLayoutWidget);
        radioButtonunlive->setObjectName(QString::fromUtf8("radioButtonunlive"));
        radioButtonunlive->setChecked(true);

        gridLayout_2->addWidget(radioButtonunlive, 6, 2, 1, 1);

        spinBoxImageBit = new QSpinBox(gridLayoutWidget);
        spinBoxImageBit->setObjectName(QString::fromUtf8("spinBoxImageBit"));
        spinBoxImageBit->setMinimum(8);
        spinBoxImageBit->setMaximum(16);
        spinBoxImageBit->setValue(8);

        gridLayout_2->addWidget(spinBoxImageBit, 3, 2, 1, 1);

        spinBoxImageTap = new QSpinBox(gridLayoutWidget);
        spinBoxImageTap->setObjectName(QString::fromUtf8("spinBoxImageTap"));
        spinBoxImageTap->setMinimum(1);
        spinBoxImageTap->setMaximum(10);
        spinBoxImageTap->setValue(3);

        gridLayout_2->addWidget(spinBoxImageTap, 4, 2, 1, 1);


        gridLayout_10->addWidget(groupBox_3, 1, 0, 1, 1);

        tabWidget->addTab(tab, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QString::fromUtf8("tab_4"));
        gridLayout_6 = new QGridLayout(tab_4);
        gridLayout_6->setObjectName(QString::fromUtf8("gridLayout_6"));
        groupBox_7 = new QGroupBox(tab_4);
        groupBox_7->setObjectName(QString::fromUtf8("groupBox_7"));
        groupBox_7->setMinimumSize(QSize(0, 100));
        groupBox_7->setMaximumSize(QSize(16777215, 100));
        radioButtondisplyLU = new QRadioButton(groupBox_7);
        radioButtondisplyLU->setObjectName(QString::fromUtf8("radioButtondisplyLU"));
        radioButtondisplyLU->setGeometry(QRect(10, 30, 100, 21));
        radioButtondisplyLD = new QRadioButton(groupBox_7);
        radioButtondisplyLD->setObjectName(QString::fromUtf8("radioButtondisplyLD"));
        radioButtondisplyLD->setGeometry(QRect(10, 70, 100, 21));
        radioButtondisplyRU = new QRadioButton(groupBox_7);
        radioButtondisplyRU->setObjectName(QString::fromUtf8("radioButtondisplyRU"));
        radioButtondisplyRU->setGeometry(QRect(230, 30, 100, 21));
        radioButtondisplyRD = new QRadioButton(groupBox_7);
        radioButtondisplyRD->setObjectName(QString::fromUtf8("radioButtondisplyRD"));
        radioButtondisplyRD->setGeometry(QRect(230, 70, 100, 21));
        radioButtondisplyC = new QRadioButton(groupBox_7);
        radioButtondisplyC->setObjectName(QString::fromUtf8("radioButtondisplyC"));
        radioButtondisplyC->setGeometry(QRect(120, 70, 100, 21));
        radioButtondisply = new QRadioButton(groupBox_7);
        radioButtondisply->setObjectName(QString::fromUtf8("radioButtondisply"));
        radioButtondisply->setGeometry(QRect(120, 30, 100, 21));
        radioButtondisply->setChecked(true);

        gridLayout_6->addWidget(groupBox_7, 2, 0, 1, 1);

        groupBox_2 = new QGroupBox(tab_4);
        groupBox_2->setObjectName(QString::fromUtf8("groupBox_2"));
        groupBox_2->setMinimumSize(QSize(0, 160));
        groupBox_2->setMaximumSize(QSize(16777215, 160));
        gridLayout_5 = new QGridLayout(groupBox_2);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        label_4 = new QLabel(groupBox_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_5->addWidget(label_4, 2, 0, 1, 1);

        label_3 = new QLabel(groupBox_2);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_5->addWidget(label_3, 1, 0, 1, 1);

        radioButtonshowByteStretch = new QRadioButton(groupBox_2);
        radioButtonshowByteStretch->setObjectName(QString::fromUtf8("radioButtonshowByteStretch"));

        gridLayout_5->addWidget(radioButtonshowByteStretch, 0, 0, 1, 1);

        radioButtonshowMeanStretch = new QRadioButton(groupBox_2);
        radioButtonshowMeanStretch->setObjectName(QString::fromUtf8("radioButtonshowMeanStretch"));
        radioButtonshowMeanStretch->setChecked(true);

        gridLayout_5->addWidget(radioButtonshowMeanStretch, 0, 1, 1, 1);

        radioButtonshowSkylightStretch = new QRadioButton(groupBox_2);
        radioButtonshowSkylightStretch->setObjectName(QString::fromUtf8("radioButtonshowSkylightStretch"));
        radioButtonshowSkylightStretch->setChecked(false);

        gridLayout_5->addWidget(radioButtonshowSkylightStretch, 0, 2, 1, 1);

        doubleSpinBoxContrastUpFactor = new QDoubleSpinBox(groupBox_2);
        doubleSpinBoxContrastUpFactor->setObjectName(QString::fromUtf8("doubleSpinBoxContrastUpFactor"));
        doubleSpinBoxContrastUpFactor->setDecimals(1);
        doubleSpinBoxContrastUpFactor->setMinimum(-100.000000000000000);
        doubleSpinBoxContrastUpFactor->setSingleStep(0.100000000000000);
        doubleSpinBoxContrastUpFactor->setValue(3.000000000000000);

        gridLayout_5->addWidget(doubleSpinBoxContrastUpFactor, 1, 1, 1, 2);

        doubleSpinBoxContrastLowFactor = new QDoubleSpinBox(groupBox_2);
        doubleSpinBoxContrastLowFactor->setObjectName(QString::fromUtf8("doubleSpinBoxContrastLowFactor"));
        doubleSpinBoxContrastLowFactor->setDecimals(1);
        doubleSpinBoxContrastLowFactor->setMinimum(-100.000000000000000);
        doubleSpinBoxContrastLowFactor->setSingleStep(0.100000000000000);
        doubleSpinBoxContrastLowFactor->setValue(1.000000000000000);

        gridLayout_5->addWidget(doubleSpinBoxContrastLowFactor, 2, 1, 1, 2);

        comboBoxImageBitShow = new QComboBox(groupBox_2);
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->addItem(QString());
        comboBoxImageBitShow->setObjectName(QString::fromUtf8("comboBoxImageBitShow"));

        gridLayout_5->addWidget(comboBoxImageBitShow, 3, 1, 1, 2);

        label_54 = new QLabel(groupBox_2);
        label_54->setObjectName(QString::fromUtf8("label_54"));

        gridLayout_5->addWidget(label_54, 3, 0, 1, 1);


        gridLayout_6->addWidget(groupBox_2, 0, 0, 1, 1);

        groupBox_6 = new QGroupBox(tab_4);
        groupBox_6->setObjectName(QString::fromUtf8("groupBox_6"));
        groupBox_6->setMinimumSize(QSize(0, 65));
        groupBox_6->setMaximumSize(QSize(16777215, 65));
        lcdNumberDiskSpace = new QLCDNumber(groupBox_6);
        lcdNumberDiskSpace->setObjectName(QString::fromUtf8("lcdNumberDiskSpace"));
        lcdNumberDiskSpace->setGeometry(QRect(30, 30, 261, 25));
        lcdNumberDiskSpace->setMinimumSize(QSize(0, 15));
        lcdNumberDiskSpace->setMaximumSize(QSize(16777215, 25));
        lcdNumberDiskSpace->setStyleSheet(QString::fromUtf8("color: rgb(8, 52, 255);"));
        label_2 = new QLabel(groupBox_6);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(300, 30, 21, 21));
        QFont font;
        font.setPointSize(10);
        label_2->setFont(font);

        gridLayout_6->addWidget(groupBox_6, 5, 0, 1, 1);

        groupBox = new QGroupBox(tab_4);
        groupBox->setObjectName(QString::fromUtf8("groupBox"));
        groupBox->setMinimumSize(QSize(0, 240));
        groupBox->setMaximumSize(QSize(16777215, 240));
        label_44 = new QLabel(groupBox);
        label_44->setObjectName(QString::fromUtf8("label_44"));
        label_44->setGeometry(QRect(10, 30, 59, 21));
        lcdNumberTime = new QLCDNumber(groupBox);
        lcdNumberTime->setObjectName(QString::fromUtf8("lcdNumberTime"));
        lcdNumberTime->setGeometry(QRect(60, 30, 251, 25));
        QFont font1;
        font1.setPointSize(6);
        lcdNumberTime->setFont(font1);
        lcdNumberTime->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberTime->setDigitCount(23);
        label_46 = new QLabel(groupBox);
        label_46->setObjectName(QString::fromUtf8("label_46"));
        label_46->setGeometry(QRect(10, 90, 31, 21));
        label_47 = new QLabel(groupBox);
        label_47->setObjectName(QString::fromUtf8("label_47"));
        label_47->setGeometry(QRect(170, 90, 31, 21));
        label_48 = new QLabel(groupBox);
        label_48->setObjectName(QString::fromUtf8("label_48"));
        label_48->setGeometry(QRect(10, 120, 31, 21));
        label_50 = new QLabel(groupBox);
        label_50->setObjectName(QString::fromUtf8("label_50"));
        label_50->setGeometry(QRect(10, 150, 31, 21));
        label_51 = new QLabel(groupBox);
        label_51->setObjectName(QString::fromUtf8("label_51"));
        label_51->setGeometry(QRect(170, 150, 51, 21));
        label_52 = new QLabel(groupBox);
        label_52->setObjectName(QString::fromUtf8("label_52"));
        label_52->setGeometry(QRect(10, 60, 31, 21));
        label_53 = new QLabel(groupBox);
        label_53->setObjectName(QString::fromUtf8("label_53"));
        label_53->setGeometry(QRect(170, 60, 51, 21));
        lcdNumberGain = new QLCDNumber(groupBox);
        lcdNumberGain->setObjectName(QString::fromUtf8("lcdNumberGain"));
        lcdNumberGain->setGeometry(QRect(60, 60, 91, 25));
        lcdNumberGain->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberGain->setDigitCount(7);
        lcdNumberExptime = new QLCDNumber(groupBox);
        lcdNumberExptime->setObjectName(QString::fromUtf8("lcdNumberExptime"));
        lcdNumberExptime->setGeometry(QRect(220, 60, 91, 25));
        lcdNumberExptime->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberExptime->setDigitCount(7);
        lcdNumberAzimuth = new QLCDNumber(groupBox);
        lcdNumberAzimuth->setObjectName(QString::fromUtf8("lcdNumberAzimuth"));
        lcdNumberAzimuth->setGeometry(QRect(60, 90, 91, 25));
        lcdNumberAzimuth->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberAzimuth->setDigitCount(7);
        lcdNumberElevatio = new QLCDNumber(groupBox);
        lcdNumberElevatio->setObjectName(QString::fromUtf8("lcdNumberElevatio"));
        lcdNumberElevatio->setGeometry(QRect(220, 90, 91, 25));
        lcdNumberElevatio->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberElevatio->setDigitCount(7);
        lcdNumberLongitude = new QLCDNumber(groupBox);
        lcdNumberLongitude->setObjectName(QString::fromUtf8("lcdNumberLongitude"));
        lcdNumberLongitude->setGeometry(QRect(60, 120, 91, 25));
        lcdNumberLongitude->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberLongitude->setDigitCount(7);
        lcdNumberLatitude = new QLCDNumber(groupBox);
        lcdNumberLatitude->setObjectName(QString::fromUtf8("lcdNumberLatitude"));
        lcdNumberLatitude->setGeometry(QRect(220, 120, 91, 25));
        lcdNumberLatitude->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberLatitude->setDigitCount(7);
        lcdNumberAltitude = new QLCDNumber(groupBox);
        lcdNumberAltitude->setObjectName(QString::fromUtf8("lcdNumberAltitude"));
        lcdNumberAltitude->setGeometry(QRect(60, 150, 91, 25));
        lcdNumberAltitude->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberAltitude->setDigitCount(7);
        lcdNumberMistiming = new QLCDNumber(groupBox);
        lcdNumberMistiming->setObjectName(QString::fromUtf8("lcdNumberMistiming"));
        lcdNumberMistiming->setGeometry(QRect(220, 150, 91, 25));
        lcdNumberMistiming->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberMistiming->setDigitCount(7);
        lcdNumberElevatioZero = new QLCDNumber(groupBox);
        lcdNumberElevatioZero->setObjectName(QString::fromUtf8("lcdNumberElevatioZero"));
        lcdNumberElevatioZero->setGeometry(QRect(220, 180, 91, 25));
        lcdNumberElevatioZero->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberElevatioZero->setDigitCount(7);
        label_56 = new QLabel(groupBox);
        label_56->setObjectName(QString::fromUtf8("label_56"));
        label_56->setGeometry(QRect(170, 180, 51, 21));
        lcdNumberAzimuthZero = new QLCDNumber(groupBox);
        lcdNumberAzimuthZero->setObjectName(QString::fromUtf8("lcdNumberAzimuthZero"));
        lcdNumberAzimuthZero->setGeometry(QRect(60, 180, 91, 25));
        lcdNumberAzimuthZero->setStyleSheet(QString::fromUtf8("color: rgb(161, 161, 161);"));
        lcdNumberAzimuthZero->setDigitCount(7);
        label_57 = new QLabel(groupBox);
        label_57->setObjectName(QString::fromUtf8("label_57"));
        label_57->setGeometry(QRect(10, 180, 51, 21));
        label_49 = new QLabel(groupBox);
        label_49->setObjectName(QString::fromUtf8("label_49"));
        label_49->setGeometry(QRect(170, 120, 31, 21));
        checkBoxDATpowerstate = new QCheckBox(groupBox);
        checkBoxDATpowerstate->setObjectName(QString::fromUtf8("checkBoxDATpowerstate"));
        checkBoxDATpowerstate->setGeometry(QRect(40, 210, 85, 21));
        checkBoxDATsavefitsstate = new QCheckBox(groupBox);
        checkBoxDATsavefitsstate->setObjectName(QString::fromUtf8("checkBoxDATsavefitsstate"));
        checkBoxDATsavefitsstate->setGeometry(QRect(200, 210, 85, 21));
        checkBoxDATsavefitsstate->setCheckable(false);

        gridLayout_6->addWidget(groupBox, 6, 0, 1, 1);

        groupBox_18 = new QGroupBox(tab_4);
        groupBox_18->setObjectName(QString::fromUtf8("groupBox_18"));
        groupBox_18->setMinimumSize(QSize(0, 55));
        groupBox_18->setMaximumSize(QSize(16777215, 55));
        checkBoxAuxiliaryLine = new QCheckBox(groupBox_18);
        checkBoxAuxiliaryLine->setObjectName(QString::fromUtf8("checkBoxAuxiliaryLine"));
        checkBoxAuxiliaryLine->setGeometry(QRect(10, 20, 131, 31));

        gridLayout_6->addWidget(groupBox_18, 4, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_6->addItem(verticalSpacer, 7, 0, 1, 1);

        groupBox_8 = new QGroupBox(tab_4);
        groupBox_8->setObjectName(QString::fromUtf8("groupBox_8"));
        groupBox_8->setEnabled(true);
        groupBox_8->setMinimumSize(QSize(0, 65));
        groupBox_8->setMaximumSize(QSize(16777215, 65));
        checkBoxEleImageStab = new QCheckBox(groupBox_8);
        checkBoxEleImageStab->setObjectName(QString::fromUtf8("checkBoxEleImageStab"));
        checkBoxEleImageStab->setGeometry(QRect(10, 30, 99, 24));
        checkBoxImageEnhancement = new QCheckBox(groupBox_8);
        checkBoxImageEnhancement->setObjectName(QString::fromUtf8("checkBoxImageEnhancement"));
        checkBoxImageEnhancement->setGeometry(QRect(120, 30, 99, 24));

        gridLayout_6->addWidget(groupBox_8, 3, 0, 1, 1);

        tabWidget->addTab(tab_4, QString());
        tab_3 = new QWidget();
        tab_3->setObjectName(QString::fromUtf8("tab_3"));
        groupBox_27 = new QGroupBox(tab_3);
        groupBox_27->setObjectName(QString::fromUtf8("groupBox_27"));
        groupBox_27->setGeometry(QRect(10, 470, 327, 180));
        groupBox_27->setMinimumSize(QSize(0, 180));
        groupBox_27->setMaximumSize(QSize(16777215, 180));
        radioButtonModeTraditionXingxin = new QRadioButton(groupBox_27);
        radioButtonModeTraditionXingxin->setObjectName(QString::fromUtf8("radioButtonModeTraditionXingxin"));
        radioButtonModeTraditionXingxin->setGeometry(QRect(10, 30, 91, 21));
        radioButtonModeTraditionXingxin->setChecked(true);
        radioButtonModeTraditionZhixin = new QRadioButton(groupBox_27);
        radioButtonModeTraditionZhixin->setObjectName(QString::fromUtf8("radioButtonModeTraditionZhixin"));
        radioButtonModeTraditionZhixin->setGeometry(QRect(140, 30, 91, 21));
        radioButtonModeTraditionUp = new QRadioButton(groupBox_27);
        radioButtonModeTraditionUp->setObjectName(QString::fromUtf8("radioButtonModeTraditionUp"));
        radioButtonModeTraditionUp->setGeometry(QRect(10, 60, 91, 21));
        radioButtonModeTraditionDown = new QRadioButton(groupBox_27);
        radioButtonModeTraditionDown->setObjectName(QString::fromUtf8("radioButtonModeTraditionDown"));
        radioButtonModeTraditionDown->setGeometry(QRect(140, 60, 100, 21));
        radioButtonModeTraditionLeft = new QRadioButton(groupBox_27);
        radioButtonModeTraditionLeft->setObjectName(QString::fromUtf8("radioButtonModeTraditionLeft"));
        radioButtonModeTraditionLeft->setGeometry(QRect(10, 90, 100, 21));
        radioButtonModeTraditionRight = new QRadioButton(groupBox_27);
        radioButtonModeTraditionRight->setObjectName(QString::fromUtf8("radioButtonModeTraditionRight"));
        radioButtonModeTraditionRight->setGeometry(QRect(140, 90, 100, 21));
        radioButtonModeTraditionLeftUp = new QRadioButton(groupBox_27);
        radioButtonModeTraditionLeftUp->setObjectName(QString::fromUtf8("radioButtonModeTraditionLeftUp"));
        radioButtonModeTraditionLeftUp->setGeometry(QRect(10, 120, 100, 21));
        radioButtonModeTraditionLeftDown = new QRadioButton(groupBox_27);
        radioButtonModeTraditionLeftDown->setObjectName(QString::fromUtf8("radioButtonModeTraditionLeftDown"));
        radioButtonModeTraditionLeftDown->setGeometry(QRect(140, 120, 100, 21));
        radioButtonModeTraditionRightUp = new QRadioButton(groupBox_27);
        radioButtonModeTraditionRightUp->setObjectName(QString::fromUtf8("radioButtonModeTraditionRightUp"));
        radioButtonModeTraditionRightUp->setGeometry(QRect(10, 150, 100, 21));
        radioButtonModeTraditionRightDown = new QRadioButton(groupBox_27);
        radioButtonModeTraditionRightDown->setObjectName(QString::fromUtf8("radioButtonModeTraditionRightDown"));
        radioButtonModeTraditionRightDown->setGeometry(QRect(140, 150, 100, 21));
        groupBox_25 = new QGroupBox(tab_3);
        groupBox_25->setObjectName(QString::fromUtf8("groupBox_25"));
        groupBox_25->setGeometry(QRect(10, 74, 327, 60));
        groupBox_25->setMinimumSize(QSize(0, 60));
        groupBox_25->setMaximumSize(QSize(16777215, 60));
        radioButtonGuideModeTradition = new QRadioButton(groupBox_25);
        radioButtonGuideModeTradition->setObjectName(QString::fromUtf8("radioButtonGuideModeTradition"));
        radioButtonGuideModeTradition->setGeometry(QRect(10, 30, 92, 24));
        radioButtonGuideModeTradition->setChecked(true);
        radioButtonGuideModeSinglerod = new QRadioButton(groupBox_25);
        radioButtonGuideModeSinglerod->setObjectName(QString::fromUtf8("radioButtonGuideModeSinglerod"));
        radioButtonGuideModeSinglerod->setGeometry(QRect(140, 30, 91, 24));
        groupBox_26 = new QGroupBox(tab_3);
        groupBox_26->setObjectName(QString::fromUtf8("groupBox_26"));
        groupBox_26->setGeometry(QRect(10, 271, 327, 60));
        groupBox_26->setMinimumSize(QSize(0, 60));
        groupBox_26->setMaximumSize(QSize(16777215, 60));
        radioButtonTrackTradition = new QRadioButton(groupBox_26);
        radioButtonTrackTradition->setObjectName(QString::fromUtf8("radioButtonTrackTradition"));
        radioButtonTrackTradition->setGeometry(QRect(10, 30, 81, 21));
        radioButtonTrackTradition->setChecked(true);
        radioButtonTrackAI_1 = new QRadioButton(groupBox_26);
        radioButtonTrackAI_1->setObjectName(QString::fromUtf8("radioButtonTrackAI_1"));
        radioButtonTrackAI_1->setGeometry(QRect(190, 30, 100, 21));
        groupBox_28 = new QGroupBox(tab_3);
        groupBox_28->setObjectName(QString::fromUtf8("groupBox_28"));
        groupBox_28->setGeometry(QRect(10, 8, 327, 60));
        groupBox_28->setMinimumSize(QSize(0, 60));
        groupBox_28->setMaximumSize(QSize(16777215, 60));
        checkBoxDetect = new QCheckBox(groupBox_28);
        checkBoxDetect->setObjectName(QString::fromUtf8("checkBoxDetect"));
        checkBoxDetect->setGeometry(QRect(10, 30, 85, 21));
        groupBox_29 = new QGroupBox(tab_3);
        groupBox_29->setObjectName(QString::fromUtf8("groupBox_29"));
        groupBox_29->setGeometry(QRect(10, 140, 327, 125));
        groupBox_29->setMinimumSize(QSize(0, 125));
        groupBox_29->setMaximumSize(QSize(16777215, 125));
        spinBoxSetTrackGateSize = new QSpinBox(groupBox_29);
        spinBoxSetTrackGateSize->setObjectName(QString::fromUtf8("spinBoxSetTrackGateSize"));
        spinBoxSetTrackGateSize->setGeometry(QRect(80, 30, 121, 24));
        spinBoxSetTrackGateSize->setMaximum(2000);
        spinBoxSetTrackGateSize->setValue(1);
        label_24 = new QLabel(groupBox_29);
        label_24->setObjectName(QString::fromUtf8("label_24"));
        label_24->setGeometry(QRect(10, 30, 59, 21));
        label_25 = new QLabel(groupBox_29);
        label_25->setObjectName(QString::fromUtf8("label_25"));
        label_25->setGeometry(QRect(10, 54, 59, 31));
        spinBoxthresTradition = new QSpinBox(groupBox_29);
        spinBoxthresTradition->setObjectName(QString::fromUtf8("spinBoxthresTradition"));
        spinBoxthresTradition->setEnabled(false);
        spinBoxthresTradition->setGeometry(QRect(80, 60, 121, 24));
        spinBoxthresTradition->setMaximum(255);
        spinBoxthresTradition->setValue(127);
        checkBoxAutoThresTradition = new QCheckBox(groupBox_29);
        checkBoxAutoThresTradition->setObjectName(QString::fromUtf8("checkBoxAutoThresTradition"));
        checkBoxAutoThresTradition->setGeometry(QRect(220, 60, 85, 21));
        checkBoxAutoThresTradition->setChecked(true);
        label_26 = new QLabel(groupBox_29);
        label_26->setObjectName(QString::fromUtf8("label_26"));
        label_26->setGeometry(QRect(10, 84, 59, 31));
        spinBoxminSizeTradition = new QSpinBox(groupBox_29);
        spinBoxminSizeTradition->setObjectName(QString::fromUtf8("spinBoxminSizeTradition"));
        spinBoxminSizeTradition->setGeometry(QRect(80, 90, 121, 24));
        spinBoxminSizeTradition->setMaximum(100);
        spinBoxminSizeTradition->setValue(12);
        groupBox_30 = new QGroupBox(tab_3);
        groupBox_30->setObjectName(QString::fromUtf8("groupBox_30"));
        groupBox_30->setGeometry(QRect(10, 340, 327, 125));
        groupBox_30->setMinimumSize(QSize(0, 125));
        groupBox_30->setMaximumSize(QSize(16777215, 125));
        doubleSpinBoxTrackThresh_0 = new QDoubleSpinBox(groupBox_30);
        doubleSpinBoxTrackThresh_0->setObjectName(QString::fromUtf8("doubleSpinBoxTrackThresh_0"));
        doubleSpinBoxTrackThresh_0->setGeometry(QRect(90, 30, 213, 24));
        doubleSpinBoxTrackThresh_0->setSingleStep(0.010000000000000);
        spinBoxTrackThresh_3 = new QSpinBox(groupBox_30);
        spinBoxTrackThresh_3->setObjectName(QString::fromUtf8("spinBoxTrackThresh_3"));
        spinBoxTrackThresh_3->setGeometry(QRect(90, 90, 213, 24));
        doubleSpinBoxTrackThresh_1 = new QDoubleSpinBox(groupBox_30);
        doubleSpinBoxTrackThresh_1->setObjectName(QString::fromUtf8("doubleSpinBoxTrackThresh_1"));
        doubleSpinBoxTrackThresh_1->setGeometry(QRect(90, 60, 213, 24));
        doubleSpinBoxTrackThresh_1->setSingleStep(0.010000000000000);
        label_9 = new QLabel(groupBox_30);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(10, 30, 59, 21));
        label_28 = new QLabel(groupBox_30);
        label_28->setObjectName(QString::fromUtf8("label_28"));
        label_28->setGeometry(QRect(10, 60, 59, 21));
        label_29 = new QLabel(groupBox_30);
        label_29->setObjectName(QString::fromUtf8("label_29"));
        label_29->setGeometry(QRect(10, 90, 59, 21));
        tabWidget->addTab(tab_3, QString());
        tab_9 = new QWidget();
        tab_9->setObjectName(QString::fromUtf8("tab_9"));
        groupBox_19 = new QGroupBox(tab_9);
        groupBox_19->setObjectName(QString::fromUtf8("groupBox_19"));
        groupBox_19->setGeometry(QRect(10, 10, 321, 171));
        pushButtonImagePath = new QPushButton(groupBox_19);
        pushButtonImagePath->setObjectName(QString::fromUtf8("pushButtonImagePath"));
        pushButtonImagePath->setEnabled(true);
        pushButtonImagePath->setGeometry(QRect(10, 30, 131, 25));
        pushButtonImagePath->setMinimumSize(QSize(0, 15));
        pushButtonImagePath->setMaximumSize(QSize(16777215, 25));
        textEditImagePath = new QTextEdit(groupBox_19);
        textEditImagePath->setObjectName(QString::fromUtf8("textEditImagePath"));
        textEditImagePath->setGeometry(QRect(10, 70, 301, 41));
        pushButtonImageDisplayStart = new QPushButton(groupBox_19);
        pushButtonImageDisplayStart->setObjectName(QString::fromUtf8("pushButtonImageDisplayStart"));
        pushButtonImageDisplayStart->setGeometry(QRect(10, 130, 131, 23));
        pushButtonImageDisplayEnd = new QPushButton(groupBox_19);
        pushButtonImageDisplayEnd->setObjectName(QString::fromUtf8("pushButtonImageDisplayEnd"));
        pushButtonImageDisplayEnd->setGeometry(QRect(169, 130, 141, 23));
        groupBox_4 = new QGroupBox(tab_9);
        groupBox_4->setObjectName(QString::fromUtf8("groupBox_4"));
        groupBox_4->setGeometry(QRect(10, 190, 321, 161));
        label_6 = new QLabel(groupBox_4);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(10, 30, 31, 21));
        label_7 = new QLabel(groupBox_4);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(10, 60, 41, 21));
        label_8 = new QLabel(groupBox_4);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(10, 90, 59, 21));
        label_11 = new QLabel(groupBox_4);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(10, 120, 59, 21));
        lcdNumberMeanValue = new QLCDNumber(groupBox_4);
        lcdNumberMeanValue->setObjectName(QString::fromUtf8("lcdNumberMeanValue"));
        lcdNumberMeanValue->setEnabled(true);
        lcdNumberMeanValue->setGeometry(QRect(120, 30, 191, 23));
        lcdNumberMeanValue->setStyleSheet(QString::fromUtf8("color: rgb(8, 53, 255);"));
        lcdNumberMeanValue->setDigitCount(10);
        lcdNumberVariance = new QLCDNumber(groupBox_4);
        lcdNumberVariance->setObjectName(QString::fromUtf8("lcdNumberVariance"));
        lcdNumberVariance->setGeometry(QRect(120, 60, 191, 23));
        lcdNumberVariance->setDigitCount(10);
        lcdNumberMaxGrayValue = new QLCDNumber(groupBox_4);
        lcdNumberMaxGrayValue->setObjectName(QString::fromUtf8("lcdNumberMaxGrayValue"));
        lcdNumberMaxGrayValue->setGeometry(QRect(120, 90, 191, 23));
        lcdNumberMaxGrayValue->setDigitCount(10);
        lcdNumberMinGrayValue = new QLCDNumber(groupBox_4);
        lcdNumberMinGrayValue->setObjectName(QString::fromUtf8("lcdNumberMinGrayValue"));
        lcdNumberMinGrayValue->setGeometry(QRect(120, 120, 191, 23));
        lcdNumberMinGrayValue->setDigitCount(10);
        groupBox_5 = new QGroupBox(tab_9);
        groupBox_5->setObjectName(QString::fromUtf8("groupBox_5"));
        groupBox_5->setGeometry(QRect(10, 360, 321, 281));
        label_30 = new QLabel(groupBox_5);
        label_30->setObjectName(QString::fromUtf8("label_30"));
        label_30->setGeometry(QRect(10, 90, 59, 21));
        label_31 = new QLabel(groupBox_5);
        label_31->setObjectName(QString::fromUtf8("label_31"));
        label_31->setGeometry(QRect(10, 120, 59, 21));
        lcdNumberStartXY = new QLCDNumber(groupBox_5);
        lcdNumberStartXY->setObjectName(QString::fromUtf8("lcdNumberStartXY"));
        lcdNumberStartXY->setGeometry(QRect(120, 90, 191, 23));
        lcdNumberStartXY->setDigitCount(10);
        lcdNumberEndXY = new QLCDNumber(groupBox_5);
        lcdNumberEndXY->setObjectName(QString::fromUtf8("lcdNumberEndXY"));
        lcdNumberEndXY->setGeometry(QRect(120, 120, 191, 23));
        lcdNumberEndXY->setDigitCount(10);
        label_32 = new QLabel(groupBox_5);
        label_32->setObjectName(QString::fromUtf8("label_32"));
        label_32->setGeometry(QRect(10, 150, 59, 21));
        label_33 = new QLabel(groupBox_5);
        label_33->setObjectName(QString::fromUtf8("label_33"));
        label_33->setGeometry(QRect(10, 180, 59, 21));
        label_34 = new QLabel(groupBox_5);
        label_34->setObjectName(QString::fromUtf8("label_34"));
        label_34->setGeometry(QRect(10, 210, 59, 21));
        lcdNumberHorizontalDistance = new QLCDNumber(groupBox_5);
        lcdNumberHorizontalDistance->setObjectName(QString::fromUtf8("lcdNumberHorizontalDistance"));
        lcdNumberHorizontalDistance->setGeometry(QRect(120, 150, 191, 23));
        lcdNumberHorizontalDistance->setDigitCount(10);
        lcdNumberVerticalDistance = new QLCDNumber(groupBox_5);
        lcdNumberVerticalDistance->setObjectName(QString::fromUtf8("lcdNumberVerticalDistance"));
        lcdNumberVerticalDistance->setGeometry(QRect(120, 180, 191, 23));
        lcdNumberVerticalDistance->setDigitCount(10);
        lcdNumberRegionalArea = new QLCDNumber(groupBox_5);
        lcdNumberRegionalArea->setObjectName(QString::fromUtf8("lcdNumberRegionalArea"));
        lcdNumberRegionalArea->setGeometry(QRect(120, 210, 191, 23));
        lcdNumberRegionalArea->setDigitCount(10);
        checkBoxStartMeasurement = new QCheckBox(groupBox_5);
        checkBoxStartMeasurement->setObjectName(QString::fromUtf8("checkBoxStartMeasurement"));
        checkBoxStartMeasurement->setGeometry(QRect(10, 30, 121, 21));
        pushButtonDataEmpty = new QPushButton(groupBox_5);
        pushButtonDataEmpty->setObjectName(QString::fromUtf8("pushButtonDataEmpty"));
        pushButtonDataEmpty->setGeometry(QRect(10, 240, 301, 23));
        label_42 = new QLabel(groupBox_5);
        label_42->setObjectName(QString::fromUtf8("label_42"));
        label_42->setGeometry(QRect(10, 60, 59, 21));
        comboBoxMeasurementShape = new QComboBox(groupBox_5);
        comboBoxMeasurementShape->addItem(QString());
        comboBoxMeasurementShape->addItem(QString());
        comboBoxMeasurementShape->addItem(QString());
        comboBoxMeasurementShape->setObjectName(QString::fromUtf8("comboBoxMeasurementShape"));
        comboBoxMeasurementShape->setGeometry(QRect(120, 60, 191, 23));
        tabWidget->addTab(tab_9, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QString::fromUtf8("tab_5"));
        groupBox_31 = new QGroupBox(tab_5);
        groupBox_31->setObjectName(QString::fromUtf8("groupBox_31"));
        groupBox_31->setGeometry(QRect(10, 10, 321, 231));
        label_12 = new QLabel(groupBox_31);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(10, 100, 81, 21));
        label_36 = new QLabel(groupBox_31);
        label_36->setObjectName(QString::fromUtf8("label_36"));
        label_36->setGeometry(QRect(80, 100, 161, 21));
        label_37 = new QLabel(groupBox_31);
        label_37->setObjectName(QString::fromUtf8("label_37"));
        label_37->setGeometry(QRect(10, 130, 61, 21));
        pushButtonLOGO = new QPushButton(groupBox_31);
        pushButtonLOGO->setObjectName(QString::fromUtf8("pushButtonLOGO"));
        pushButtonLOGO->setGeometry(QRect(10, 30, 61, 61));
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/LOGO.jpg"), QSize(), QIcon::Normal, QIcon::Off);
        pushButtonLOGO->setIcon(icon);
        pushButtonLOGO->setIconSize(QSize(61, 61));
        pushButtonLOGO->setFlat(true);
        label_38 = new QLabel(groupBox_31);
        label_38->setObjectName(QString::fromUtf8("label_38"));
        label_38->setGeometry(QRect(80, 50, 131, 21));
        label_39 = new QLabel(groupBox_31);
        label_39->setObjectName(QString::fromUtf8("label_39"));
        label_39->setGeometry(QRect(80, 130, 231, 21));
        label_40 = new QLabel(groupBox_31);
        label_40->setObjectName(QString::fromUtf8("label_40"));
        label_40->setGeometry(QRect(10, 160, 61, 21));
        label_41 = new QLabel(groupBox_31);
        label_41->setObjectName(QString::fromUtf8("label_41"));
        label_41->setGeometry(QRect(80, 160, 231, 21));
        pushButtonURL = new QPushButton(groupBox_31);
        pushButtonURL->setObjectName(QString::fromUtf8("pushButtonURL"));
        pushButtonURL->setGeometry(QRect(20, 190, 271, 23));
        pushButtonURL->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 255);\n"
"text-decoration: underline;\n"
"font: 9pt \"Sans Serif\";"));
        pushButtonURL->setFlat(true);
        groupBox_32 = new QGroupBox(tab_5);
        groupBox_32->setObjectName(QString::fromUtf8("groupBox_32"));
        groupBox_32->setGeometry(QRect(10, 250, 321, 71));
        pushButtonSoftwareManual = new QPushButton(groupBox_32);
        pushButtonSoftwareManual->setObjectName(QString::fromUtf8("pushButtonSoftwareManual"));
        pushButtonSoftwareManual->setGeometry(QRect(80, 30, 151, 31));
        pushButtonSoftwareManual->setStyleSheet(QString::fromUtf8("font: 9pt \"Sans Serif\";\n"
"text-decoration: underline;\n"
"color: rgb(0, 0, 255);"));
        pushButtonSoftwareManual->setFlat(true);
        tabWidget->addTab(tab_5, QString());

        gridLayout->addWidget(tabWidget, 0, 0, 1, 1);


        retranslateUi(OnlineTuneDialog);

        tabWidget->setCurrentIndex(2);


        QMetaObject::connectSlotsByName(OnlineTuneDialog);
    } // setupUi

    void retranslateUi(QDialog *OnlineTuneDialog)
    {
        OnlineTuneDialog->setWindowTitle(QCoreApplication::translate("OnlineTuneDialog", "Online Tune Tool", nullptr));
        groupBox_34->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\347\233\270\346\234\272\347\212\266\346\200\201", nullptr));
        pushButtonCameraState->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\212\266\346\200\201\346\237\245\350\257\242", nullptr));
        groupBox_11->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\345\203\217\344\277\235\345\255\230", nullptr));
        label->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\240\274\345\274\217:", nullptr));
        comboBoxsaveimagestate->setItemText(0, QCoreApplication::translate("OnlineTuneDialog", "jpg", nullptr));
        comboBoxsaveimagestate->setItemText(1, QCoreApplication::translate("OnlineTuneDialog", "tiff", nullptr));
        comboBoxsaveimagestate->setItemText(2, QCoreApplication::translate("OnlineTuneDialog", "fits", nullptr));
        comboBoxsaveimagestate->setItemText(3, QCoreApplication::translate("OnlineTuneDialog", "raw", nullptr));

        pushButtonSaveImage->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\277\235\345\255\230\345\233\276\347\211\207", nullptr));
        pushButtonstartsaveimage->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\274\200\345\247\213\345\255\230\345\202\250", nullptr));
        pushButtonstopsaveimage->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\201\234\346\255\242\345\255\230\345\202\250", nullptr));
        labelsaveimage->setText(QCoreApplication::translate("OnlineTuneDialog", "0%", nullptr));
        groupBox_21->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\347\233\270\346\234\272", nullptr));
        comboBoxType->setItemText(0, QCoreApplication::translate("OnlineTuneDialog", "\346\234\252\351\200\211\346\213\251", nullptr));
        comboBoxType->setItemText(1, QCoreApplication::translate("OnlineTuneDialog", "\344\270\255\346\263\242\347\272\242\345\244\226", nullptr));
        comboBoxType->setItemText(2, QCoreApplication::translate("OnlineTuneDialog", "\351\225\277\346\263\242\347\272\242\345\244\226", nullptr));
        comboBoxType->setItemText(3, QCoreApplication::translate("OnlineTuneDialog", "\345\275\251\350\211\262\345\217\257\350\247\201\345\205\211", nullptr));
        comboBoxType->setItemText(4, QCoreApplication::translate("OnlineTuneDialog", "\344\270\255\346\263\242\350\277\236\347\273\255\345\217\230\347\204\246", nullptr));

        label_13->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\236\213\345\217\267", nullptr));
        labelCameraSize->setText(QString());
        groupBox_3->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\347\233\270\346\234\272\345\217\202\346\225\260\351\205\215\347\275\256", nullptr));
        lineEditResolutionW->setText(QCoreApplication::translate("OnlineTuneDialog", "1920", nullptr));
        label_15->setText(QCoreApplication::translate("OnlineTuneDialog", "CameraLink\345\267\245\344\275\234\346\250\241\345\274\217", nullptr));
        label_16->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\275\215\346\267\261", nullptr));
        label_5->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\210\206\350\276\250\347\216\207", nullptr));
        label_17->setText(QCoreApplication::translate("OnlineTuneDialog", "\351\200\232\351\201\223", nullptr));
        label_20->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\345\203\217\346\225\260\346\215\256\346\240\274\345\274\217", nullptr));
        label_10->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\256\275", nullptr));
        label_14->setText(QCoreApplication::translate("OnlineTuneDialog", "\351\253\230", nullptr));
        comboBoxCameraLinkMode->setItemText(0, QCoreApplication::translate("OnlineTuneDialog", "Base", nullptr));
        comboBoxCameraLinkMode->setItemText(1, QCoreApplication::translate("OnlineTuneDialog", "Medium", nullptr));
        comboBoxCameraLinkMode->setItemText(2, QCoreApplication::translate("OnlineTuneDialog", "Full", nullptr));

        lineEditResolutionH->setText(QCoreApplication::translate("OnlineTuneDialog", "1080", nullptr));
        comboBoxImageFormat->setItemText(0, QCoreApplication::translate("OnlineTuneDialog", "RGB", nullptr));

        radioButtonlive->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\274\200\345\247\213\351\207\207\351\233\206", nullptr));
        radioButtonunlive->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\201\234\346\255\242\351\207\207\351\233\206", nullptr));
        spinBoxImageBit->setSuffix(QCoreApplication::translate("OnlineTuneDialog", "bit", nullptr));
        spinBoxImageTap->setSuffix(QCoreApplication::translate("OnlineTuneDialog", "tap", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab), QCoreApplication::translate("OnlineTuneDialog", "\346\215\225\350\216\267", nullptr));
        groupBox_7->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\346\230\276\347\244\272\345\214\272\345\237\237", nullptr));
        radioButtondisplyLU->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\267\246\344\270\212\345\214\272\345\237\237", nullptr));
        radioButtondisplyLD->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\267\246\344\270\213\345\214\272\345\237\237", nullptr));
        radioButtondisplyRU->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\217\263\344\270\212\345\214\272\345\237\237", nullptr));
        radioButtondisplyRD->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\217\263\344\270\213\345\214\272\345\237\237", nullptr));
        radioButtondisplyC->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\255\345\277\203\345\214\272\345\237\237", nullptr));
        radioButtondisply->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\205\250\351\203\250\345\214\272\345\237\237", nullptr));
        groupBox_2->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\345\203\217\346\230\276\347\244\272\346\213\211\344\274\270", nullptr));
        label_4->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\213\351\231\220\345\217\202\346\225\260", nullptr));
        label_3->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\212\351\231\220\345\217\202\346\225\260", nullptr));
        radioButtonshowByteStretch->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\255\227\350\212\202\346\213\211\344\274\270", nullptr));
        radioButtonshowMeanStretch->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\235\207\345\200\274\346\213\211\344\274\270", nullptr));
        radioButtonshowSkylightStretch->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\244\251\345\205\211\350\203\214\346\231\257\346\213\211\344\274\270", nullptr));
        comboBoxImageBitShow->setItemText(0, QCoreApplication::translate("OnlineTuneDialog", "1-8", nullptr));
        comboBoxImageBitShow->setItemText(1, QCoreApplication::translate("OnlineTuneDialog", "2-9", nullptr));
        comboBoxImageBitShow->setItemText(2, QCoreApplication::translate("OnlineTuneDialog", "3-10", nullptr));
        comboBoxImageBitShow->setItemText(3, QCoreApplication::translate("OnlineTuneDialog", "4-11", nullptr));
        comboBoxImageBitShow->setItemText(4, QCoreApplication::translate("OnlineTuneDialog", "5-12", nullptr));
        comboBoxImageBitShow->setItemText(5, QCoreApplication::translate("OnlineTuneDialog", "6-13", nullptr));
        comboBoxImageBitShow->setItemText(6, QCoreApplication::translate("OnlineTuneDialog", "7-14", nullptr));
        comboBoxImageBitShow->setItemText(7, QCoreApplication::translate("OnlineTuneDialog", "8-15", nullptr));
        comboBoxImageBitShow->setItemText(8, QCoreApplication::translate("OnlineTuneDialog", "9-16", nullptr));

        label_54->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\255\227\350\212\202\351\225\277\345\272\246", nullptr));
        groupBox_6->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\347\243\201\347\233\230\347\251\272\351\227\264", nullptr));
        label_2->setText(QCoreApplication::translate("OnlineTuneDialog", "G", nullptr));
        groupBox->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\223\215\345\272\224\351\205\215\347\275\256\346\226\207\344\273\266\346\216\247\345\210\266\346\227\266\347\232\204\346\234\211\345\205\263\345\217\202\346\225\260", nullptr));
        label_44->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\227\266\347\273\237\346\227\266\351\227\264", nullptr));
        label_46->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\226\271\344\275\215", nullptr));
        label_47->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\277\257\344\273\260", nullptr));
        label_48->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\273\217\345\272\246", nullptr));
        label_50->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\265\267\346\213\224", nullptr));
        label_51->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\263\273\347\273\237\346\227\266\345\267\256", nullptr));
        label_52->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\242\236\347\233\212", nullptr));
        label_53->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\233\235\345\205\211\346\227\266\351\227\264", nullptr));
        label_56->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\277\257\344\273\260\351\233\266\347\202\271", nullptr));
        label_57->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\226\271\344\275\215\351\233\266\347\202\271", nullptr));
        label_49->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\272\254\345\272\246", nullptr));
        checkBoxDATpowerstate->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\224\265\346\272\220\347\212\266\346\200\201", nullptr));
        checkBoxDATsavefitsstate->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\255\230\345\233\276\347\212\266\346\200\201", nullptr));
        groupBox_18->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\346\230\276\347\244\272\350\276\205\345\212\251\347\272\277", nullptr));
        checkBoxAuxiliaryLine->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\255\345\277\203\345\215\201\345\255\227\350\276\205\345\212\251\347\272\277", nullptr));
        groupBox_8->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\345\203\217\345\244\204\347\220\206", nullptr));
        checkBoxEleImageStab->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\224\265\345\255\220\347\250\263\345\203\217", nullptr));
        checkBoxImageEnhancement->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\345\203\217\345\242\236\345\274\272", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QCoreApplication::translate("OnlineTuneDialog", "\346\230\276\347\244\272", nullptr));
        groupBox_27->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\350\267\237\350\270\252\345\217\202\346\225\260", nullptr));
        radioButtonModeTraditionXingxin->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\275\242\345\277\203", nullptr));
        radioButtonModeTraditionZhixin->setText(QCoreApplication::translate("OnlineTuneDialog", "\350\264\250\345\277\203", nullptr));
        radioButtonModeTraditionUp->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\212\350\276\271\347\274\230", nullptr));
        radioButtonModeTraditionDown->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\213\350\276\271\347\274\230", nullptr));
        radioButtonModeTraditionLeft->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\267\246\350\276\271\347\274\230", nullptr));
        radioButtonModeTraditionRight->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\217\263\350\276\271\347\274\230", nullptr));
        radioButtonModeTraditionLeftUp->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\267\246\344\270\212", nullptr));
        radioButtonModeTraditionLeftDown->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\267\246\344\270\213", nullptr));
        radioButtonModeTraditionRightUp->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\217\263\344\270\212", nullptr));
        radioButtonModeTraditionRightDown->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\217\263\344\270\213", nullptr));
        groupBox_25->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\350\257\206\345\210\253\346\250\241\345\274\217", nullptr));
        radioButtonGuideModeTradition->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\274\240\347\273\237", nullptr));
        radioButtonGuideModeSinglerod->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\215\225\346\235\206", nullptr));
        groupBox_26->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\350\267\237\350\270\252\346\250\241\345\274\217", nullptr));
        radioButtonTrackTradition->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\274\240\347\273\237\350\267\237\350\270\252", nullptr));
        radioButtonTrackAI_1->setText(QCoreApplication::translate("OnlineTuneDialog", "AI\350\267\237\350\270\252", nullptr));
        groupBox_28->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\210\235\345\247\213\345\214\226", nullptr));
        checkBoxDetect->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\212\237\350\203\275\345\220\257\345\212\250", nullptr));
        groupBox_29->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\344\274\240\347\273\237\350\257\206\345\210\253\345\217\202\346\225\260", nullptr));
        label_24->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\263\242\351\227\250\345\244\247\345\260\217", nullptr));
        label_25->setText(QCoreApplication::translate("OnlineTuneDialog", "\351\230\210     \345\200\274", nullptr));
        checkBoxAutoThresTradition->setText(QCoreApplication::translate("OnlineTuneDialog", "\350\207\252\351\200\202\345\272\224", nullptr));
        label_26->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\255\224\346\264\236\345\244\247\345\260\217", nullptr));
        groupBox_30->setTitle(QCoreApplication::translate("OnlineTuneDialog", "AI\350\267\237\350\270\252\345\217\202\346\225\260", nullptr));
        label_9->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\270\242\345\244\261\351\230\210\345\200\274", nullptr));
        label_28->setText(QCoreApplication::translate("OnlineTuneDialog", "\351\201\256\346\214\241\351\230\210\345\200\274", nullptr));
        label_29->setText(QCoreApplication::translate("OnlineTuneDialog", "\344\277\235\346\214\201\346\227\266\351\227\264", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QCoreApplication::translate("OnlineTuneDialog", "\350\257\206\345\210\253\350\267\237\350\270\252", nullptr));
        groupBox_19->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\210\235\345\247\213\345\214\226", nullptr));
        pushButtonImagePath->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\347\211\207\350\267\257\345\276\204\351\200\211\346\213\251", nullptr));
        pushButtonImageDisplayStart->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\347\211\207\345\244\204\347\220\206\345\274\200\345\247\213", nullptr));
        pushButtonImageDisplayEnd->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\347\211\207\345\244\204\347\220\206\347\273\223\346\235\237", nullptr));
        groupBox_4->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\237\272\346\234\254\345\217\202\346\225\260\345\210\206\346\236\220", nullptr));
        label_6->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\235\207\345\200\274", nullptr));
        label_7->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\240\207\345\207\206\345\267\256", nullptr));
        label_8->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\234\200\345\244\247\347\201\260\345\272\246\345\200\274", nullptr));
        label_11->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\234\200\345\260\217\347\201\260\345\272\246\345\200\274", nullptr));
        groupBox_5->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\346\265\213\351\207\217", nullptr));
        label_30->setText(QCoreApplication::translate("OnlineTuneDialog", "\350\265\267\345\247\213\344\275\215\347\202\271", nullptr));
        label_31->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\273\223\346\235\237\344\275\215\347\202\271", nullptr));
        label_32->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\260\264\345\271\263\350\267\235\347\246\273", nullptr));
        label_33->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\236\202\347\233\264\350\267\235\347\246\273", nullptr));
        label_34->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\233\264\347\272\277\350\267\235\347\246\273", nullptr));
        checkBoxStartMeasurement->setText(QCoreApplication::translate("OnlineTuneDialog", "\345\220\257\345\212\250\346\265\213\351\207\217\345\212\237\350\203\275", nullptr));
        pushButtonDataEmpty->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\225\260\346\215\256\346\270\205\347\251\272", nullptr));
        label_42->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\265\213\351\207\217\345\275\242\347\212\266", nullptr));
        comboBoxMeasurementShape->setItemText(0, QCoreApplication::translate("OnlineTuneDialog", "\347\233\264\347\272\277", nullptr));
        comboBoxMeasurementShape->setItemText(1, QCoreApplication::translate("OnlineTuneDialog", "\347\237\251\345\275\242", nullptr));
        comboBoxMeasurementShape->setItemText(2, QCoreApplication::translate("OnlineTuneDialog", "\345\234\206\345\275\242", nullptr));

        tabWidget->setTabText(tabWidget->indexOf(tab_9), QCoreApplication::translate("OnlineTuneDialog", "\345\233\276\347\211\207\345\210\206\346\236\220", nullptr));
        groupBox_31->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\345\205\263\344\272\216\350\275\257\344\273\266", nullptr));
        label_12->setText(QCoreApplication::translate("OnlineTuneDialog", "\350\275\257\344\273\266\346\211\200\346\234\211", nullptr));
        label_36->setText(QCoreApplication::translate("OnlineTuneDialog", "\302\2512024-2025", nullptr));
        label_37->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\211\210\346\234\254", nullptr));
        pushButtonLOGO->setText(QString());
        label_38->setText(QCoreApplication::translate("OnlineTuneDialog", "Orion CameraTool", nullptr));
        label_39->setText(QCoreApplication::translate("OnlineTuneDialog", "Linux aarch64 20230310 V1.0", nullptr));
        label_40->setText(QCoreApplication::translate("OnlineTuneDialog", "\347\216\257\345\242\203", nullptr));
        label_41->setText(QCoreApplication::translate("OnlineTuneDialog", "OpenCV4.6.0-CUDA11.4.239-YOLOV5", nullptr));
        pushButtonURL->setText(QCoreApplication::translate("OnlineTuneDialog", "http://www.cg-orion.com", nullptr));
        groupBox_32->setTitle(QCoreApplication::translate("OnlineTuneDialog", "\350\275\257\344\273\266\344\275\277\347\224\250\350\257\264\346\230\216", nullptr));
        pushButtonSoftwareManual->setText(QCoreApplication::translate("OnlineTuneDialog", "\346\211\223\345\274\200\350\275\257\344\273\266\344\275\277\347\224\250\346\211\213\345\206\214", nullptr));
        tabWidget->setTabText(tabWidget->indexOf(tab_5), QCoreApplication::translate("OnlineTuneDialog", "\345\270\256\345\212\251", nullptr));
    } // retranslateUi

};

namespace Ui {
    class OnlineTuneDialog: public Ui_OnlineTuneDialog {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ONLINETUNEDIALOG_H
