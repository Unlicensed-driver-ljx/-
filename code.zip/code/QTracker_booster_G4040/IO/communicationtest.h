#ifndef COMMUNICATIONTEST_H
#define COMMUNICATIONTEST_H

#include <QObject>

class CommunicationTest : public QObject
{
    Q_OBJECT
public:
    explicit CommunicationTest(QObject *parent = 0);

signals:

public slots:
};

#endif // COMMUNICATIONTEST_H
