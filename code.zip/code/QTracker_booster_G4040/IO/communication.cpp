#include "communication.h"
#include <QtMath>
#define PixelSize    22
#define FocusLength  154

typedef union {
    float ufloat;
    int  uInt;
}DataUnion;

Communication::Communication(QObject *parent) : QThread(parent)
{
    g_param = GlobalParameter::getInstance();
    m_bSend = false;
    xDegrees_back = 0;
    yDegrees_back = 0;
    m_processThread = new WorkerThread(this);
    stmp=new char[2881+4096*4096*2];
    memset(stmp,0,2880+4096*4096*2);
    m_processThread->init();
     qDebug()<<"Communication  Communication Communication";
     QTimer::singleShot(1000, this, [=]{
         uint32_t  cameraid, carid;
         cameraid = g_param->controlParam.CameraID;
         carid = g_param->controlParam.CarID;
         camera_id_set(cameraid);
         car_id_set(carid);
     });

     QTimer::singleShot(5000, this, [=]{
          uint32_t  cameraid, carid;
         cameraid = g_param->controlParam.CameraID;
         carid = g_param->controlParam.CarID;
         camera_id_set(cameraid);
         car_id_set(carid);
     });

     QTimer::singleShot(10000, this, [=]{
          uint32_t  cameraid, carid;
         cameraid = g_param->controlParam.CameraID;
         carid = g_param->controlParam.CarID;
         camera_id_set(cameraid);
         car_id_set(carid);
     });
}

Communication::~Communication()
{

    m_processThread->stopProcess();
    delete stmp;
    close();
}

bool Communication::init()
{
    //if(m_port_ttyS0->init("/dev/ttyUSB0", 115200) == false)
//    if(m_port_ttyUSB0->init("/dev/ttyUSB0", 230400) == false)//20200612yy
//    {
//        qDebug() << "m_port_ttyUSB0->init error";
//    }

    return true;
}

void Communication::close()
{
    //stopSendData();
    m_timer.stop();
    m_timer1.stop();

}

void Communication::startSendData()
{
    if (m_bSend == false)
    {
        m_bSend = true;
        start(QThread::NormalPriority);
    }
}

void Communication::stopSendData()
{
    m_bSend = false;
}

void Communication::sendSerialData()
{
    uint32_t statu;
    int32_t targetx, targety;
    statu = g_param->trackstatu;

    if (g_param->trackParam.state == TRACK&&(g_param->trackParam.objPosPix.x != 0&&g_param->trackParam.objPosPix.y != 0))
    {
        targetx = (g_param->trackParam.objPosPix.x - g_param->cameraconfigParam.ResolutionW / 2)*1000;
        targety = (g_param->cameraconfigParam.ResolutionH / 2 - g_param->trackParam.objPosPix.y)*1000;
    }
    else
    {
        targetx = 0;
        targety = 0;
    }

    if(g_param->serial_send_satrt == true)
    {
        serial_send_set(statu, targetx, targety);
    }

}


void Communication::checkTrackGate()
{
    Rect2d& gate = g_param->trackParam.trackGateRoi;
    if(gate.width <= 0)
    {
        gate.width = g_param->trackParam.trackGateSize.width;
    }
    if(gate.height <= 0)
    {
        gate.height = g_param->trackParam.trackGateSize.height;
    }

    if(gate.width > g_param->trackParam.trackGateSize.width)
    {
        gate.x += (gate.width - g_param->trackParam.trackGateSize.width) / 2;
        gate.width = g_param->trackParam.trackGateSize.width;
    }
    if(gate.height > g_param->trackParam.trackGateSize.height)
    {
        gate.y += (gate.height - g_param->trackParam.trackGateSize.height) / 2;
        gate.height = g_param->trackParam.trackGateSize.height;
    }


    if(gate.x < 0)
    {
        gate.x = 1;
    }
    if(gate.y < 0)
    {
        gate.y = 1;
    }

    if(gate.x + gate.width > g_param->cameraconfigParam.ResolutionW)
    {
        gate.width = g_param->cameraconfigParam.ResolutionW - gate.x - 2;
    }
    if(gate.y + gate.height > g_param->cameraconfigParam.ResolutionH)
    {
        gate.height = g_param->cameraconfigParam.ResolutionH - gate.y - 2;
    }
}



void Communication::readdatarun()
{
    qDebug()<<"AAAAAAAAAAAAAAAA"<<g_param->uart_recv_work;
    if(g_param->uart_recv_work == true)
    {
//        QDateTime t11 = QDateTime::currentDateTimeUtc();
//        QString shijian = t11.toString("yyyy-MM-dd hh:mm:ss.zzz");
//        qDebug()<<"shijian"<<shijian;
        int uartNum = g_param->controlParam.qSerialPort.toInt();
        char buf[64] = {0};
        uint32_t frame_len = g_param->controlParam.SerialPortdatalen;

        int val = uart_read(uartNum, buf, frame_len);
        if (val != frame_len)
        {
              qDebug()<<"uart read error" << val;
        }
        else
        {
            for (int i = 0; i < 64; i += 16)
            {
                for (int j = 0; j < 16; ++j)
                {
                    int num = i + j;
                    buffRevDataPC[num] = (unsigned char)buf[i + j];
                   QString str = QString("0x%1").arg(buffRevDataPC[num],0,16);
                    qDebug()<<"str"<<num<<str;
                }
            }
        }
        if(buffRevDataPC[0] == 0x90 && buffRevDataPC[1] == 0xEB)
        {
            switch (buffRevDataPC[8])
            {
            case 0x01:
                g_param->pccontrolparam.TrackingState = true;

                short2char kk;
                kk.aa[1] = buffRevDataPC[10];
                kk.aa[0] = buffRevDataPC[9];
                g_param->pccontrolparam.TrackingPointX = kk.q16 + g_param->cameraconfigParam.ResolutionW/2;
                kk.aa[1] = buffRevDataPC[12];
                kk.aa[0] = buffRevDataPC[11];
                g_param->pccontrolparam.TrackingPointY = kk.q16 + g_param->cameraconfigParam.ResolutionH/2;

                g_param->displayParam.mouseClickPos.x = g_param->pccontrolparam.TrackingPointX;
                g_param->displayParam.mouseClickPos.y = g_param->pccontrolparam.TrackingPointY;
                g_param->trackParam.trackGateRoi.x = g_param->pccontrolparam.TrackingPointX - g_param->trackParam.trackGateSize.width/2;
                g_param->trackParam.trackGateRoi.y = g_param->pccontrolparam.TrackingPointY - g_param->trackParam.trackGateSize.height/2;
                g_param->trackParam.trackGateRoi.width = g_param->trackParam.trackGateSize.width;
                g_param->trackParam.trackGateRoi.height = g_param->trackParam.trackGateSize.height;
                checkTrackGate();

                g_param->detect_flag = true;
                g_param->trackParam.state = TRACK;
                g_param->trackParam.bTrackTradition = false;
                qDebug()<<"start tracking:"<<g_param->pccontrolparam.TrackingPointX<<","<<g_param->pccontrolparam.TrackingPointY;
                break;
            case 0x02:
                g_param->pccontrolparam.TrackingState = false;
                g_param->detect_flag = false;
                g_param->trackParam.bAutoDetect2Track = false;
                g_param->trackParam.state = DETECT;
                g_param->trackstatu = 0;
                g_param->yolo_res.boxes.clear();
                g_param->yolo_res.classNamesID.clear();
                g_param->yolo_res.classNamesVec.clear();
                g_param->yolo_res.prob.clear();
                qDebug()<<"end tracking";
                break;
            case 0x03:
                g_param->pccontrolparam.EleImageStab = true;
                qDebug()<<"start EleImageStab...";
                break;
            case 0x04:
                g_param->pccontrolparam.EleImageStab = false;
                qDebug()<<"end EleImageStab...";
                break;
            case 0x05:
                g_param->pccontrolparam.ImageEnhancement = true;
                qDebug()<<"start ImageEnhancement...";
                break;
            case 0x06:
                g_param->pccontrolparam.ImageEnhancement = false;
                qDebug()<<"end ImageEnhancement...";
                break;
            case 0x07:
                g_param->pccontrolparam.SetGate = true;
                qDebug()<<"set gate...";
                break;
            case 0x08:
                g_param->pccontrolparam.SetTrackGate = true;
                qDebug()<<"set the tracking gate size mode...";
                if(buffRevDataPC[9] == 0x01)
                {
                    g_param->pccontrolparam.TrackGateSize = 1;
                    qDebug()<<"fixed gate";
                }
                else if(buffRevDataPC[9] == 0x02)
                {
                    g_param->pccontrolparam.TrackGateSize = 2;
                    qDebug()<<"follow by focal length";
                }

                break;
            case 0x0E:
                if(buffRevDataPC[9] == 0x00)
                {
                    g_param->pccontrolparam.CrossSilkDisplay = true;
                    qDebug()<<"start cross silk display...";
                }
                else
                {
                    g_param->pccontrolparam.CrossSilkDisplay = false;
                    qDebug()<<"end cross silk display";
                }
                break;
            case 0x0F:
                if(buffRevDataPC[9] == 0x00)
                {
                    g_param->pccontrolparam.CharacterDisplay = true;
                    qDebug()<<"start character display...";
                }
                else
                {
                    g_param->pccontrolparam.CharacterDisplay = false;
                    qDebug()<<"end character display";
                }
                break;
            case 0x10:
                g_param->detect_flag = true;

                g_param->pccontrolparam.TargetDetectState = true;
                g_param->trackParam.bAutoDetect2Track = false;
                g_param->trackParam.state = DETECT;
                g_param->servoXXTParam.guideMode = 0;

                g_param->trackParam.trackGateSize = cv::Size2d(1280, 1280);
                g_param->trackParam.bChangeTrackGateSize = true;

                g_param->yolo_res.boxes.clear();
                g_param->yolo_res.classNamesID.clear();
                g_param->yolo_res.classNamesVec.clear();
                g_param->yolo_res.prob.clear();
                qDebug()<<"start target detec state...";
                break;
            case 0x11:
                g_param->detect_flag = false;
                g_param->trackParam.bAutoDetect2Track = false;
                g_param->trackParam.state = DETECT;

                g_param->pccontrolparam.TargetDetectState = false;
                qDebug()<<"end target detec state";
                break;
            case 0x12:
                qDebug()<<"set gate position turn...";
                if(buffRevDataPC[9] == 0x01)
                {
                    g_param->pccontrolparam.GatePositionTurn = 1;
                }
                else if(buffRevDataPC[9] == 0x02)
                {
                    g_param->pccontrolparam.GatePositionTurn = 2;
                }
                else if(buffRevDataPC[10] == 0x01)
                {
                    g_param->pccontrolparam.GatePositionTurn = 3;
                }
                else if(buffRevDataPC[10] == 0x02)
                {
                    g_param->pccontrolparam.GatePositionTurn = 4;
                }
                g_param->trackParam.bChangeTrackGateSize = true;
                break;
            case 0x13:
                qDebug()<<"set tracking point...";
                if(buffRevDataPC[9] == 0x00)
                {
                    g_param->pccontrolparam.TrackingPoint = 1;

                }
                else if(buffRevDataPC[9] == 0x01)
                {
                    g_param->pccontrolparam.TrackingPoint = 2;
                    g_param->trackParam.modeValueTradition = 1;
                }
                else if(buffRevDataPC[9] == 0x02)
                {
                    g_param->pccontrolparam.TrackingPoint = 3;
                }
                break;
            default:
//                g_param->pccontrolparam.TrackingState = false;
//                g_param->pccontrolparam.TrackingPointX = 0;
//                g_param->pccontrolparam.TrackingPointY = 0;
//                g_param->pccontrolparam.EleImageStab = false;
//                g_param->pccontrolparam.ImageEnhancement = false;
//                g_param->pccontrolparam.SetGate = false;
//                g_param->pccontrolparam.GateSize = 0;
//                g_param->pccontrolparam.SetTrackGate = false;
//                g_param->pccontrolparam.TrackGateSize = 0;
//                g_param->pccontrolparam.CrossSilkDisplay = false;
//                g_param->pccontrolparam.CharacterDisplay = false;
//                g_param->pccontrolparam.TargetDetectState = false;
//                g_param->pccontrolparam.GatePositionTurn = 0;
//                g_param->pccontrolparam.TrackingPoint = 0;
                break;
            }
            if(g_param->pccontrolparam.SetGate == true)
            {
                switch (buffRevDataPC[9])
                {
                case 0x01:
                    g_param->pccontrolparam.GateSize = 1;
                    g_param->trackParam.trackGateSize = cv::Size2d(g_param->trackParam.trackGateSize.width + g_param->controlParam.GateVariableStep, g_param->trackParam.trackGateSize.height + g_param->controlParam.GateVariableStep);
                    qDebug()<<"gate get bigger";
                    break;
                case 0x02:
                    g_param->pccontrolparam.GateSize = 2;
                    g_param->trackParam.trackGateSize = cv::Size2d(g_param->controlParam.GateBig, g_param->controlParam.GateBig);
                    qDebug()<<"gate get big";
                    break;
                case 0x03:
                    g_param->pccontrolparam.GateSize = 3;
                    g_param->trackParam.trackGateSize = cv::Size2d(g_param->controlParam.GateMedium, g_param->controlParam.GateMedium);
                    qDebug()<<"gate get medium";
                    break;
                case 0x04:
                    g_param->pccontrolparam.GateSize = 4;
                    g_param->trackParam.trackGateSize = cv::Size2d(g_param->controlParam.GateSmall, g_param->controlParam.GateSmall);
                    qDebug()<<"gate get small";
                    break;
                case 0x05:
                    g_param->pccontrolparam.GateSize = 5;
                    g_param->trackParam.trackGateSize = cv::Size2d(g_param->trackParam.trackGateSize.width - g_param->controlParam.GateVariableStep, g_param->trackParam.trackGateSize.height - g_param->controlParam.GateVariableStep);
                    qDebug()<<"gate get smaller";
                    break;
                default:
                    g_param->pccontrolparam.GateSize = 1;
                    break;
                }
                g_param->trackParam.bChangeTrackGateSize = true;
                g_param->pccontrolparam.SetGate = false;
            }
            bool ok;
            g_param->pccontrolparam.VisibleLightFocalLength = double((QString("0x%1").arg(((buffRevDataPC[15]<<16)|(buffRevDataPC[14]<<8)|buffRevDataPC[13]),0,16)).toInt(&ok,16))/100.00;
            g_param->pccontrolparam.MediumWaveInfraredFocalLength = double((QString("0x%1").arg(((buffRevDataPC[18]<<16)|(buffRevDataPC[17]<<8)|buffRevDataPC[16]),0,16)).toInt(&ok,16))/100.00;
            g_param->pccontrolparam.MediumWaveFocalLength = double((QString("0x%1").arg(((buffRevDataPC[21]<<16)|(buffRevDataPC[20]<<8)|buffRevDataPC[19]),0,16)).toInt(&ok,16))/100.00;
            g_param->pccontrolparam.LongWaveFocalLength = double((QString("0x%1").arg(((buffRevDataPC[24]<<16)|(buffRevDataPC[23]<<8)|buffRevDataPC[22]),0,16)).toInt(&ok,16))/100.00;
            g_param->pccontrolparam.ang_azimuth = double((QString("0x%1").arg(((buffRevDataPC[28]<<24)|(buffRevDataPC[27]<<16)|(buffRevDataPC[26]<<8)|buffRevDataPC[25]),0,16)).toInt(&ok,16))/10000.00;
            g_param->pccontrolparam.ang_elevatio = double((QString("0x%1").arg(((buffRevDataPC[32]<<24)|(buffRevDataPC[31]<<16)|(buffRevDataPC[30]<<8)|buffRevDataPC[29]),0,16)).toInt(&ok,16))/10000.00;
            memset(buffRevDataPC,0,100);

            sendSerialData();

        }

    }
}

WorkerThread::WorkerThread(Communication *pComm)
{
    g_param = GlobalParameter::getInstance();
    m_pComm = pComm;
    m_bProcessing = false;
}
WorkerThread::~WorkerThread()
{
    stopProcess();
    g_param->saveimageWaitCondition.wakeAll();
    msleep(10);
}
void WorkerThread::init()
{
    m_bProcessing = true;
    start();
}
void WorkerThread::stopProcess()
{
    m_bProcessing = false;
}
void WorkerThread::run()
{
    while (m_bProcessing)
    {
        m_pComm->readdatarun();

        //msleep(15);
    }
}
