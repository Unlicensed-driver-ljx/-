#ifndef SERIALPORT_H
#define SERIALPORT_H

#include <QObject>
#include <QThread>
#include <QSerialPort>
#include <QByteArray>
#include <QDebug>
#include <QDataStream>


class SerialPort : public QObject
{
    Q_OBJECT
public:
    explicit SerialPort(QObject *parent = 0);
    ~SerialPort();
    bool init(QString port, qint32 baud);
    void close();
    bool isOpen();
public slots:
    void handleData();
    void writeData(const char* data, qint64 len);
signals:
    void recvData(QByteArray data);
private:
    QThread* m_thread;
    QSerialPort* m_port;
    QString m_name;
    qint32 m_baud;
    bool m_bInit;
};

#endif // SERIALPORT_H
