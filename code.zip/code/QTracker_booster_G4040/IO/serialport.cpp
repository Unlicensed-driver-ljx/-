#include "serialport.h"

SerialPort::SerialPort(QObject *parent) : QObject(parent)
{
    m_thread = new QThread();
    m_port = new QSerialPort();
}

SerialPort::~SerialPort()
{
    m_port->close();
    m_port->deleteLater();
    //m_thread->terminate();
    //m_thread->quit();
    //m_thread->wait();
    QThread::msleep(10);
    //m_thread->deleteLater();
}

bool SerialPort::init(QString port, qint32 baud)
{
    m_name = port;
    m_baud = baud;
    m_port->setPortName(m_name);
    m_port->setBaudRate(m_baud);
    m_port->setDataBits(QSerialPort::Data8);
    m_port->setStopBits(QSerialPort::OneStop);
    m_port->setParity(QSerialPort::NoParity);
    m_port->setFlowControl(QSerialPort::NoFlowControl);
    if(m_port->open(QIODevice::ReadWrite) == false)
    {
        m_bInit = false;
//        qDebug() << m_name << "open failed";
        return false;
    }
    /*QByteArray data = m_port->readAll();
    if(data.isEmpty() == true)
    {
        qDebug() << m_name << "read null data";
    }
    emit recvData(data);*/
    /// test
    //qDebug() << m_name << "recv data:" << data;
    connect(m_port, SIGNAL(readyRead()), this, SLOT(handleData()), Qt::QueuedConnection);
    //this->moveToThread(m_thread);
    //m_port->moveToThread(m_thread);
    //m_thread->start();
    qDebug() << m_name << "open success, baud" << m_baud;
    m_bInit = true;
    return true;
}

void SerialPort::close()
{
    if(m_port != NULL)
    {
        m_port->close();
    }
}

bool SerialPort::isOpen()
{
    if(m_port == NULL)
    {
        return false;
    }
    else
    {
        return m_port->isOpen();
    }
}

void SerialPort::handleData()
{
    QByteArray data = m_port->readAll();
    if(data.isEmpty() == true)
    {
        qDebug() << m_name << "read null data";
        return;
    }
    emit recvData(data);
    /// test
    //qDebug() << m_name << "recv data:" << data;
    //qDebug() << m_name << "recv data:" << str22;
}

void SerialPort::writeData(const char* data, qint64 len)
{
    qint64 res = m_port->write(data, len);
    if(res != len)
    {
        qDebug() << m_name << "write data error:" << res;
    }
}


