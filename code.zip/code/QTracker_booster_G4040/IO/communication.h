#ifndef COMUNICATION_H
#define COMUNICATION_H

#include <QObject>
#include <QDebug>
#include <QTimer>
#include "serialport.h"
#include "Tool/GlobalParameter.h"
#include "Camera/g400camera.h"
#include <opencv2/imgproc/imgproc_c.h>
#include <algorithm>

#include <QThread>

class WorkerThread;

class Communication : public QThread
{
    Q_OBJECT

    union short2char{
        qint16 q16;
        char   aa[2];
    };

public:
    explicit Communication(QObject *parent = 0);
    ~Communication();
    bool init();
    void close();
    void startSendData();
    void stopSendData();
    void sendSerialData();
    void checkTrackGate();
    char buffRevDataPC[100] = {0};
public slots:
    void readdatarun();
protected:
    GlobalParameter* g_param;
private:
    char *stmp;
    bool m_bSend;
    float xDegrees_back;
    float yDegrees_back;
    QTimer m_timer;
    QTimer m_timer1;
    QTimer m_timer2;
    G400Camera* m_g400_camera;
    double exposure;
    int ri;
    QString fitsname,date,time,datename;
    QMutex m_mutex_CC;
    bool b_read_data = true;

    WorkerThread*      m_processThread;
};

class WorkerThread : public QThread
{
    Q_OBJECT
public:
    WorkerThread(Communication* pComm);
    ~WorkerThread();
    void init();
    void stopProcess();
    bool m_bProcessing;
protected:
    void run() Q_DECL_OVERRIDE;
    GlobalParameter* g_param;
private:
    Communication* m_pComm;

};

#endif // COMUNICATION_H
