#include "communicationtest.h"

CommunicationTest::CommunicationTest(QObject *parent) : QObject(parent)
{

}
