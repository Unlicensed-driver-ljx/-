#include "tcpworker.h"

void TcpWorker::initTcp()
{
//    Send_tmp = new char[1920*1080*3];
    TCP_server = new QTcpServer();
    TCP_connectSocket = nullptr;
    m_globalparameter=GlobalParameter::getInstance();
    if (TCP_server->listen(QHostAddress::Any, m_globalparameter->controlParam.m_TCPTuPort))
    {
        connect(TCP_server, &QTcpServer::newConnection, this, &TcpWorker::slot_newconnect);
        qDebug()<< "TCP server Listen is OK";
    }
    else
    {
       qDebug()<< "TCP network send open error";
    }
}

void TcpWorker::slot_newconnect()
{
    if (TCP_server->hasPendingConnections())  //
    {
        TCP_connectSocket = TCP_server->nextPendingConnection(); //
        qDebug()<<("client login!"); //
        connect(TCP_connectSocket, SIGNAL(readyRead()), this, SLOT(slot_recvmessage()));
        m_bSendTcp = true;
    }
}
void TcpWorker::slot_recvmessage()
{
    if (TCP_connectSocket != nullptr)
    {
        QByteArray array = TCP_connectSocket->readAll();
        if(array.data()[0] == 'c')
        {
            m_bSendTcp = false;
            qDebug()<<"AAAA recv tcp Message";
            QTimer::singleShot(1000,this,&TcpWorker::slot_disconnect);
        }
    }
}

void TcpWorker::slot_disconnect()
{
     qDebug()<<"AAAA disconnect is enter";
    if (TCP_connectSocket != nullptr)
    {
        TCP_connectSocket->close();
        TCP_connectSocket->deleteLater();
        TCP_connectSocket=nullptr;
    }
}


void TcpWorker::slot_sendmessage()
{
    if( false == m_bSendTcp)
        return;
    if (TCP_connectSocket != nullptr)
    {
        skip_count++;
        int len = 128;
        int len_c = 64;
        QString time;
        if(skip_count >= m_globalparameter->adjFps){
            if(m_globalparameter->cameraconfigParam.ImageBit > 8)
            {
                Mat means, stddevs;
                meanStdDev(m_globalparameter->TcpImage, means, stddevs);
                double upper_bound = means.at<double>(0) + 3*stddevs.at<double>(0);
                double lower_bound = means.at<double>(0) - 3*stddevs.at<double>(0);
                Mat small = Mat::zeros(m_globalparameter->cameraconfigParam.ResolutionH, m_globalparameter->cameraconfigParam.ResolutionW, CV_8UC1);
                contrastStretchSendMatrix(m_globalparameter->TcpImage,small,upper_bound,lower_bound);
                small.copyTo(SendMat);
            }
            else
            {
//                bool ook;
//                QString yearhex = QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,13),2,16,QLatin1Char('0')) + QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,12),2,16,QLatin1Char('0'));
//                QString year = QString::number(yearhex.toInt(&ook,16));
//                QString mouth = QString::number((int)m_globalparameter->TcpImage.at<uchar>(0,14));
//                QString day = QString::number((int)m_globalparameter->TcpImage.at<uchar>(0,15));
//                QString hour = QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,16),2,16,QLatin1Char('0'));
//                QString minute = QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,17),2,16,QLatin1Char('0'));
//                QString s = QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,18),2,16,QLatin1Char('0'));
//                QString mshex = QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,20),2,16,QLatin1Char('0')) + QString("%1").arg((int)m_globalparameter->TcpImage.at<uchar>(0,19),2,16,QLatin1Char('0'));
//                QString ms = (QString::number(mshex.toInt(&ook,16))).mid(0,2);
//                time = year + "-" + mouth + "-" + day + " " + hour + ":" + minute + ":" + s + "." + ms;

                m_globalparameter->TcpImage.copyTo(SendMat);
            }
            if(m_globalparameter->pccontrolparam.ImageEnhancement == true)
            {
                filter2D(SendMat, SendMat, CV_8UC1, kernel);
            }
            drawTrackBox(SendMat);
            if(m_globalparameter->pccontrolparam.CrossSilkDisplay == true)
            {
                cv::line(SendMat,cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2 - len, m_globalparameter->cameraconfigParam.ResolutionH / 2),cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2 - len_c, m_globalparameter->cameraconfigParam.ResolutionH / 2),cv::Scalar(65535),1);
                cv::line(SendMat,cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2 + len_c, m_globalparameter->cameraconfigParam.ResolutionH / 2),cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2 + len, m_globalparameter->cameraconfigParam.ResolutionH / 2),cv::Scalar(65535),1);
                cv::line(SendMat,cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2, m_globalparameter->cameraconfigParam.ResolutionH / 2 - len),cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2, m_globalparameter->cameraconfigParam.ResolutionH / 2 - len_c),cv::Scalar(65535),1);
                cv::line(SendMat,cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2, m_globalparameter->cameraconfigParam.ResolutionH / 2 + len_c),cv::Point(m_globalparameter->cameraconfigParam.ResolutionW / 2, m_globalparameter->cameraconfigParam.ResolutionH / 2 + len),cv::Scalar(65535),1);
            }
            if(m_globalparameter->pccontrolparam.CharacterDisplay == true)
            {
                putText(SendMat,m_globalparameter->DisplayTime.toStdString(),Point(m_globalparameter->controlParam.DisplayChararcterPositionX,m_globalparameter->controlParam.DisplayChararcterPositionY),FONT_HERSHEY_SIMPLEX,0.7,Scalar(65535),2,4);
            }
//            if(m_globalparameter->cameraconfigParam.DisplayImageTap != 3)
//            {
//               cv::cvtColor(SendMat, SendMat, COLOR_GRAY2RGB);
//            }
            if(m_globalparameter->pccontrolparam.TrackingState == false)
            {
                drawDetectBox(SendMat);
            }
            QByteArray arrayKK;
            int sendSize = SendMat.cols*SendMat.rows*SendMat.elemSize();
            arrayKK.resize(sendSize);
            memcpy(arrayKK.data(),SendMat.data,sendSize);
//        TCP_connectSocket->write(QString("size=%1").arg(m_globalparameter->cameraconfigParam.ResolutionW*m_globalparameter->cameraconfigParam.ResolutionH).toLocal8Bit());
//            if (TCP_connectSocket == nullptr)
//                return;
//            TCP_connectSocket->waitForReadyRead();
            qDebug()<<"TTTTTTTTTTTTTTTTTTTTTTTTTTt  Tcp sendSize = "<<sendSize;
            TCP_connectSocket->write(arrayKK);
//            if (TCP_connectSocket == nullptr)
//                return;
//            TCP_connectSocket->waitForReadyRead();
            skip_count=0;
        }
    }
}


void TcpWorker::contrastStretchSendMatrix(Mat mat16,Mat& mat8,double upper_bound,double lower_bound)
{
    if(upper_bound <= lower_bound)
    {
        double tmp = upper_bound;
        lower_bound = upper_bound;
        upper_bound = tmp;
    }
    if(lower_bound < 0)
    {
        lower_bound = 0;
    }
    if(upper_bound > 65535)
    {
        upper_bound = 65535;
    }

    for(int j = 0; j < m_globalparameter->cameraconfigParam.ResolutionH-1; j++)
    {
        for(int i = 0; i < m_globalparameter->cameraconfigParam.ResolutionW-1; i++)
        {
            if(mat16.at<ushort>(j,i) < lower_bound)
            {
                mat8.at<uchar>(j,i) = 0;
            }
            else if(mat16.at<ushort>(j,i) > upper_bound)
            {
                mat8.at<uchar>(j,i) = 255;
            }
            else
            {
                mat8.at<uchar>(j,i) = (uchar)((mat16.at<ushort>(j,i) - lower_bound) * 255.0 / (upper_bound - lower_bound + 0.0000001));
            }
        }

    }
}

void TcpWorker::drawTrackBox(Mat frame)
{
    if (m_globalparameter->trackParam.state == TRACK)
    {
        rectangle(frame,m_globalparameter->trackParam.trackGateRoi,cv::Scalar(65535),1,8);
    }
}

void TcpWorker::drawDetectBox(Mat frame)
{
    if(m_globalparameter->detect_flag == true)
    {
        if(m_globalparameter->yolo_res.boxes.size() <= 0)
        {
            return;
        }
        if(frame.channels() == 4)
        {
            cvtColor(frame, frame, COLOR_BGRA2BGR);
        }
        double fontScale = 0.5;
        int thickniss = 1;
        if(m_globalparameter->displayParam.imgSize.width < 800)
        {
            fontScale = 0.5;
            thickniss = 1;
         }
        else
        {
            fontScale = 0.9;
            thickniss = 2;
         }
         int baseLine = 0;
        for(size_t i=0;i < m_globalparameter->yolo_res.boxes.size();i++)
        {
            if(i >= m_globalparameter->yolo_res.classNamesID.size() || i >= m_globalparameter->yolo_res.prob.size())
            {
                qDebug() << "detection sync";
                break;
            }
            int offset = m_globalparameter->yolo_res.classNamesID[i]*123457 % 80;
            float red = 255*get_color(2,offset,80);
            float green = 255*get_color(1,offset,80);
            float blue = 255*get_color(0,offset,80);

            rectangle(frame,m_globalparameter->yolo_res.boxes[i],Scalar(blue,green,red),thickniss);

            string label_prob, label, label_id;
            if(m_globalparameter->yolo_res.classNamesID[i] >= (int)m_globalparameter->yolo_res.classNamesVec.size())
            {
                label = "unknow";
            }
            else
            {
                label_prob = format("%.2f", m_globalparameter->yolo_res.prob[i]);
                label = string(m_globalparameter->yolo_res.classNamesVec[m_globalparameter->yolo_res.classNamesID[i]]) + ":" + label_prob;
                Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, fontScale, thickniss, &baseLine);
                putText(frame, label, Point(m_globalparameter->yolo_res.boxes[i].x + m_globalparameter->yolo_res.boxes[i].width - labelSize.width, m_globalparameter->yolo_res.boxes[i].y - labelSize.height - 2),
                        FONT_HERSHEY_SIMPLEX,fontScale, Scalar(red, blue, green),thickniss);
            }

            label_id = format("%i", i+1 );
            putText(frame, label_id, Point(m_globalparameter->yolo_res.boxes[i].x, m_globalparameter->yolo_res.boxes[i].y + getTextSize(label_id, FONT_HERSHEY_SIMPLEX, fontScale, thickniss, &baseLine).height + 2),
                    FONT_HERSHEY_SIMPLEX, fontScale, Scalar(red, blue, green),thickniss);
        }
    }
    else
    {
        m_globalparameter->yolo_res.boxes.clear();
        m_globalparameter->yolo_res.classNamesID.clear();
        m_globalparameter->yolo_res.classNamesVec.clear();
        m_globalparameter->yolo_res.prob.clear();
    }

}

float TcpWorker::get_color(int c, int x, int max)
{
    float colors[6][3] = { {1,0,1}, {0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0} };
    float ratio = ((float)x/max)*5;
    int i = floor(ratio);
    int j = ceil(ratio);
    ratio -= i;
    float r = (1-ratio) * colors[i][c] + ratio*colors[j][c];
    return r;
}
