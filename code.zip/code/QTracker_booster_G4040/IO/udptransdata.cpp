#include "udptransdata.h"
unsigned char UDPTransData::sendBuffer[74] = {};

UDPTransData::UDPTransData(QObject *parent)
    : QObject(parent)
{
    g_param = GlobalParameter::getInstance();
    m_udpSocket = new QUdpSocket(this);
    connect(m_udpSocket,SIGNAL(readyRead()),this,SLOT(ReceiveText()));
    m_xingTuAddr = QHostAddress(g_param->controlParam.udpAddr);
    m_xingTuPort = g_param->controlParam.m_UDPTuPort;
    m_sendTimer = new QTimer(this);
    connect(m_sendTimer,SIGNAL(timeout()),this,SLOT(sendOurMessage()));
    sendBuffer[0] = 0x80;
    sendBuffer[1] = 0x25;
    sendBuffer[2] = 0x85;
    sendBuffer[7] = 0x00;
    sendBuffer[8] = 0x40;
    sendBuffer[9] = 0x00;
    sendBuffer[10] = 0x7E;
    sendBuffer[23] = 0x00;
    sendBuffer[73] = 0xE7;
}

UDPTransData::~UDPTransData()
{

}
void UDPTransData::changeUdpAddress(QString udpAddress)
{
    m_xingTuAddr = QHostAddress(udpAddress);
}

bool UDPTransData::initUDPPort()
{
    m_udpSocket->abort();
//    QHostAddress addr = QHostAddress("10.0.28.7");
    QHostAddress addr = QHostAddress(g_param->controlParam.lAddr);
    bool rel = m_udpSocket->bind(addr, g_param->controlParam.m_lUDPTuPort);
//    bool rel = m_udpSocket->bind(addr, 29681);
    if(rel)
    {
       qDebug()<<"udp bind success!";
       m_sendTimer->start(100);
    }
    else
    {
       qDebug()<<"udp bind failed!";
       qDebug()<<m_udpSocket->error();
    }
    return rel;
}

void UDPTransData::isSendMessage(bool isSend)
{
    if (isSend)
    {
        m_sendTimer->start(100);
    }
    else
    {
        m_sendTimer->stop();
    }
}
void UDPTransData::disConnectMachineLearning()
{
    m_udpSocket->abort();
}
void UDPTransData::ReceiveText()
{
    while (m_udpSocket->hasPendingDatagrams()) {
        QByteArray buffer;
        int len = m_udpSocket->pendingDatagramSize();
        buffer.resize(len);
        m_udpSocket->readDatagram(buffer.data(), len);
        qDebug()<<"buffer.data()"<<buffer.data();
        //int tx,ty,bx,by;
        unsigned short int tempU16;
        //unsigned int tempInt;
        int aAngle,eAngle;
        unsigned char rec[4];
        if(12 == len)
        {
            if (0x7F == (unsigned char)buffer[0] && 0xF7 == (unsigned char)buffer[11])
            {
                switch((unsigned char)buffer[1])
                {
                   case 0x01:
                       //tempU16 = unsigned char(buffer[9])+ unsigned char(buffer[10])*256;
                       emit moveT210Step((unsigned char)buffer[8],tempU16/10.0);
                    break;
                   case 0x02:
                       rec[0] = (unsigned char)buffer[3];
                       rec[1] = (unsigned char)buffer[4];
                       rec[2] = (unsigned char)buffer[5];
                       rec[3] = (unsigned char)buffer[6];
                       memcpy(&aAngle,rec,4);
                       rec[0] = (unsigned char)buffer[7];
                       rec[1] = (unsigned char)buffer[8];
                       rec[2] = (unsigned char)buffer[9];
                       rec[3] = (unsigned char)buffer[10];
                       memcpy(&eAngle,rec,4);
                       emit moveT2102Pos(aAngle/100.0,eAngle/100.0);
                    break;
                   case 0x03:
                        emit changeT210mode((unsigned char)buffer[10]);
                    break;

                   case 0x21:
                         emit XXTFocusStep((unsigned char)buffer[10]);
                       break;
                   case 0x22:
                        // tempU16 = unsigned char(buffer[9])+ unsigned char(buffer[10])*256;
                         emit XXTZoom(tempU16);
                       break;
                   case 0x23:
                          emit XXTZoomStep((unsigned char)buffer[10]);
                       break;

                   case 0x41:
                        emit changeDspObjectProperty((unsigned char)buffer[10]);
                       break;

                   case 0x61:
                         emit laserOpenClose((unsigned char)buffer[10]);
                       break;
                   case 0x62:
                          emit laserCurrent((unsigned char)buffer[10]);
                       break;
                   case 0x63:
                        // tempU16 =  unsigned char(buffer[9])+ unsigned char(buffer[10])*256;
                          emit laserMotorPos(tempU16);
                       break;
                    default:
                       break;
                }

            }

        }
    }
}

void UDPTransData::sendOurMessage()
{
    ///0~4294967295
    QByteArray arr;
    QString hex = QString("%1").arg(counter,8,16,QLatin1Char('0'));
    arr[0] = hex.mid(0,2).toInt(nullptr,16);
    arr[1] = hex.mid(2,2).toInt(nullptr,16);
    arr[2] = hex.mid(4,2).toInt(nullptr,16);
    arr[3] = hex.mid(6,2).toInt(nullptr,16);
    sendBuffer[3] = arr.at(3);
    sendBuffer[4] = arr.at(2);
    sendBuffer[5] = arr.at(1);
    sendBuffer[6] = arr.at(0);
    if(counter<4294967295)
    {
        counter = counter + 1;
    }
    else
    {
        counter = 0;
    }

    ///expouse
    int exp = g_param->expouse*1000;
    QByteArray arr2;
    QString exphex = QString("%1").arg(exp,6,16,QLatin1Char('0'));
    arr2[0] = exphex.mid(0,2).toInt(nullptr,16);
    arr2[1] = exphex.mid(2,2).toInt(nullptr,16);
    arr2[2] = exphex.mid(4,2).toInt(nullptr,16);
    sendBuffer[13] = arr2.at(2);
    sendBuffer[14] = arr2.at(1);
    sendBuffer[15] = arr2.at(0);

    ///disk remaining space
    QStorageInfo dirFress;
    QByteArray arr3;
    dirFress.setPath("/home/nvidia/hdd");
    unsigned int FreeStoreSize  = dirFress.bytesAvailable()/1024/1024/50;
    QString FreeSize = QString("%1").arg(FreeStoreSize,6,16,QLatin1Char('0'));
    arr3[0] = FreeSize.mid(0,2).toInt(nullptr,16);
    arr3[1] = FreeSize.mid(2,2).toInt(nullptr,16);
    arr3[2] = FreeSize.mid(4,2).toInt(nullptr,16);
    sendBuffer[17] = arr3.at(2);
    sendBuffer[18] = arr3.at(1);
    sendBuffer[19] = arr3.at(0);
    //qDebug()<<"space"<<FreeStoreSize;

    ///TrackSate
    if (g_param->trackParam.state == TRACK)
    {
        int index = g_param->trackParam.modeValueTradition;
        switch(index)
        {
        case 0:
            sendBuffer[29] = 0x02;
            break;
        case 1:
            sendBuffer[29] = 0x01;
            break;
        case 2:
            sendBuffer[29] = 0x42;
            break;
        case 3:
            sendBuffer[29] = 0x46;
            break;
        case 4:
            sendBuffer[29] = 0x40;
            break;
        case 5:
            sendBuffer[29] = 0x44;
            break;
        case 6:
            sendBuffer[29] = 0x41;
            break;
        case 7:
            sendBuffer[29] = 0x07;
            break;
        case 8:
            sendBuffer[29] = 0x43;
            break;
        case 9:
            sendBuffer[29] = 0x45;
            break;
        default:
            sendBuffer[29] = 0x02;
            break;
        }
    }
    else
    {
        sendBuffer[29] = 0x00;
    }


    ///mubiao1sate/tuobaliang
    if (g_param->trackParam.state == TRACK&&(g_param->trackParam.objPosPix.x != 0&&g_param->trackParam.objPosPix.y != 0))
    {
        sendBuffer[30] = 0x01;
        int xx = (g_param->trackParam.objPosPix.x - 320)*100;
        if(xx < 0)
        {
            sendBuffer[31] = 0x01;
            xx = (320 - g_param->trackParam.objPosPix.x)*100;
        }
        else
        {
            sendBuffer[31] = 0x00;
        }
        QString xxx = QString("%1").arg(xx,4,16,QLatin1Char('0'));
        sendBuffer[32] = xxx.mid(2,2).toInt(nullptr,16);
        sendBuffer[33] = xxx.mid(0,2).toInt(nullptr,16);
        int yy = (608 - g_param->trackParam.objPosPix.y)*100;
        if(yy < 0)
        {
            sendBuffer[34] = 0x01;
            yy = (g_param->trackParam.objPosPix.y - 608)*100;
        }
        else
        {
            sendBuffer[34] = 0x00;
        }
        QString yyy = QString("%1").arg(yy,4,16,QLatin1Char('0'));
        sendBuffer[35] = yyy.mid(2,2).toInt(nullptr,16);
        sendBuffer[36] = yyy.mid(0,2).toInt(nullptr,16);

        int ww = g_param->trackParam.trackGateRoi.width;
        QString www = QString("%1").arg(ww,2,16,QLatin1Char('0'));
        sendBuffer[52] = www.mid(0,2).toInt(nullptr,16);
        int hh = g_param->trackParam.trackGateRoi.height;
        QString hhh = QString("%1").arg(hh,2,16,QLatin1Char('0'));
        sendBuffer[53] = hhh.mid(0,2).toInt(nullptr,16);
    }
    else
    {
        sendBuffer[30] = 0x00;
        sendBuffer[31] = 0x00;
        sendBuffer[32] = 0x00;
        sendBuffer[33] = 0x00;
        sendBuffer[34] = 0x00;
        sendBuffer[35] = 0x00;
        sendBuffer[36] = 0x00;
        sendBuffer[52] = 0x00;
        sendBuffer[53] = 0x00;
    }

    int size = m_udpSocket->writeDatagram((const char*)sendBuffer,74,m_xingTuAddr,m_xingTuPort);
    //qDebug()<<"send data ok! data size : "<< size;

}
