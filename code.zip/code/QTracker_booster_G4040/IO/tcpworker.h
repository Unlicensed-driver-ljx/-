#ifndef TCPWORKER_H
#define TCPWORKER_H

#include "opencv2/opencv.hpp"
#include "Tool/GlobalParameter.h"
#include "Camera/g400camera.h"

#include <QMainWindow>
#include <QList>
#include <QMessageBox>
#include <iostream>
#include <QCloseEvent>
#include <QDateTime>
#include <QTimer>
#include <QtMath>
#include <QUdpSocket>
#include <QTcpServer>
#include <QTcpSocket>
#include <QtConcurrent/QtConcurrent>
#include <QScreen>
#include <QDesktopWidget>
#include <QApplication>
#include <QRect>
#include <QtConcurrent>
#include <QFuture>

class TcpWorker : public QObject
{
    Q_OBJECT

public slots:
    void initTcp();
    void slot_newconnect();
    void slot_sendmessage();
    void slot_recvmessage(); //
    void slot_disconnect(); //
    void contrastStretchSendMatrix(Mat mat16,Mat& mat8,double upper_bound,double lower_bound);
    void drawDetectBox(Mat frame);
    void drawTrackBox(Mat frame);
    float get_color(int c, int x, int max);

signals:
    void resultReady(const QString &result);

private:
    QTcpServer* TCP_server; //QTcpServer
    QTcpSocket* TCP_connectSocket;
    bool m_bSendTcp= false;
    int skip_count = 0;
    int adjFps = 10;
    char *Send_tmp;
    cv::Mat SendMat;
    GlobalParameter* m_globalparameter;

    cv::Mat kernel = (Mat_<float>(3, 3) << 0, -1, 0, 0, 5, 0, 0, -1, 0);
};

#endif // TCPWORKER_H
