#ifndef UDPTRANSDATA_H
#define UDPTRANSDATA_H
#include <QObject>
#include <QUdpSocket>
#include <QHostAddress>
#include <QTimer>
#include <QStorageInfo>

#include "Tool/GlobalParameter.h"

class UDPTransData: public QObject
{
    Q_OBJECT
public:
    UDPTransData(QObject *parent=NULL);
    ~UDPTransData();
    void isSendMessage(bool isSend);
    void disConnectMachineLearning();
    void changeUdpAddress(QString udpAddress);
     static unsigned char sendBuffer[74];

signals:
     void moveT210Step(int direction,float step);
     void moveT2102Pos(float aAngle,float eAngle);
     void changeT210mode(int controlMode);
     void XXTFocusStep(int BackOrForward);
     void XXTZoom(int zoomPos);
     void XXTZoomStep(int backOrForward);
     void changeDspObjectProperty(int objectProperty);
     void laserOpenClose(int openClose);
     void laserCurrent(int current);
     void laserMotorPos(int motorPos);
public slots:
    void ReceiveText();
    void sendOurMessage();
    bool initUDPPort();
private:
   QUdpSocket *m_udpSocket;
   QTimer     *m_sendTimer;
   GlobalParameter* g_param;

   QHostAddress m_xingTuAddr;
   int    m_xingTuPort;
   unsigned int counter = 0;
   unsigned int counter1 = 0;
   int ppp;

};
#endif // UDPTRANSDATA_H
