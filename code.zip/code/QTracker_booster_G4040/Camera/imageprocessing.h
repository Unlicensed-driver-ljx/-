#ifndef IMAGEPROCESSING_H
#define IMAGEPROCESSING_H

#include <QObject>
#include <QDir>
#include <QFile>
#include <QString>
#include <QTimer>
#include <QDataStream>
#include <QDateTime>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/time.h>
#include <unistd.h>
#include <QImage>
#include <QStorageInfo>
#include "camerabase.h"
#include "opencv2/opencv.hpp"
#include "opencv2/core.hpp"
#include <QtMath>
/*
 *  NECESSARY INCLUDES:
 */
#include <stdio.h>		// c library
#include <signal.h>		// c library
#include <stdlib.h>		// c library
#include <stdarg.h>		// c library
#include <unistd.h>		// c library
#include <limits.h>		// c library

class ImageProcessing : public CameraBase
{
public:
    ImageProcessing();
    ~ImageProcessing();
    bool init();
    void close();
    void startCapture();
    void stopCapture();
    bool readCurrentFrame();

protected:
    void run();
private:
    bool contrastStretch(float up_factor, float low_factor, bool para);
    ushort DataTransfer(const ushort indata);

    bool WriteFitsFile(char *str_filename,int nW,int nH,int bingmode[4],double expTime,int obsTime[7],double obsPos[4],double ObsInf[9],double dbIXY[2],ushort *lpDif,bool bStandard);
private:
    Mat m_mono16;
    Mat m_mono16_scale;
    Mat m_mono8;
    Mat m_rgb8;
    Mat m_mono16_bkd;
    Mat m_mono16_bin;
    Mat m_mono8_jd;
    Mat m_rgb_jd;
    Mat m_mono16bkd1;
    Mat m_mono16bkd2;
    Mat m_mono16bkd;
    QImage image;

    int m_img_width; /// image size
    int m_img_height;
    bool m_store_RemoverFPN_once;
    bool m_store_FPN_OK;
    double exposure;
    int v = 6;
    bool ready_START = false;
    int meanbkdnum = 0;
    double weight = 1;

    double time_fps_counter = 0;
    double totalFramefps = 0;
    bool bRefreshTime;
    bool m_bCapture = false;

    QTimer *timerSoftTriggerInc;
};

#endif // IMAGEPROCESSING_H
