#include "imageprocessing.h"

ImageProcessing::ImageProcessing()
{
    m_img_width = g_param->displayParam.VS_size.width;
    m_img_height = g_param->displayParam.VS_size.height;

    m_mono16 = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16_bkd = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16_scale = Mat::zeros(m_img_height,m_img_width,CV_16UC1);
    m_mono8 = Mat::zeros(m_img_height,m_img_width,CV_8UC1);
    m_mono16_bin = Mat::zeros(g_param->Width/2,g_param->Height/2,CV_16UC1);
    m_mono16bkd = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16bkd1 = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16bkd2 = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
}

ImageProcessing::~ImageProcessing()
{
    close();
}

bool ImageProcessing::init()
{
    return true;
}

void ImageProcessing::close()
{
    stopCapture();
    msleep(10);
}

void ImageProcessing::startCapture()
{
    m_img_width = g_param->displayParam.VS_size.width;
    m_img_height = g_param->displayParam.VS_size.height;

    m_mono16 = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16_bkd = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16_scale = Mat::zeros(m_img_height,m_img_width,CV_16UC1);
    m_mono8 = Mat::zeros(m_img_height,m_img_width,CV_8UC1);
    m_mono16_bin = Mat::zeros(g_param->Width/2,g_param->Height/2,CV_16UC1);
    m_mono16bkd = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16bkd1 = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    m_mono16bkd2 = Mat::zeros(g_param->Width,g_param->Height,CV_16UC1);
    if(m_bCapture == false)
    {
        m_bCapture = true;
        start(QThread::NormalPriority);
    }
}

void ImageProcessing::stopCapture()
{
    m_bCapture = false;
    g_param->EstimateGather = false;
    g_param->b_showBackgroundMap = true;
    g_param->MeanValue = "0";
    g_param->Variance = "0";
    g_param->MaxGrayValue = "0";
    g_param->MinGrayValue = "0";
}

bool ImageProcessing::readCurrentFrame()
{
    msleep(10);
    if(g_param->LoadPath.right(3) == "tif")
    {
        m_mono16 = cv::imread(g_param->LoadPath.toLatin1().data(),cv::IMREAD_UNCHANGED);
    }
    if(m_mono16.empty())
    {
        g_param->b_showBackgroundMap = true;
        return false;
    }
    else
    {
        g_param->Height = m_mono16.rows;
        g_param->Width = m_mono16.cols;
        if(g_param->m_store_bkd_once == true)
        {
            if(meanbkdnum < g_param->MeanBackgroundFps)
            {
                weight = (double)1/(g_param->MeanBackgroundFps - meanbkdnum);
                meanbkdnum ++;
                m_mono16bkd1 = m_mono16.clone();
                addWeighted(m_mono16bkd1,weight,m_mono16bkd2,1-weight,0,m_mono16bkd);
                m_mono16bkd2 = m_mono16bkd.clone();
            }
            else
            {
                meanbkdnum = 0;
                QDir dir;
                if(!dir.exists("/home/pi/Pictures"))
                {
                    dir.mkdir("/home/pi/Pictures");
                }
                QString path = QString("/home/pi/Pictures/%1.tif").arg("bkdtiff");
                cv::imwrite(path.toLatin1().data(),m_mono16bkd);
                qDebug()<<"save bkdimage in"<<path;
                g_param->m_store_bkd_once = false;
            }

        }
        if(g_param->m_remove_bkd == true)
        {
            QString path = QString("/home/pi/Pictures/%1.tif").arg("bkdtiff");
            m_mono16_bkd = imread(path.toLatin1().data(),cv::IMREAD_UNCHANGED);
            cv::absdiff(m_mono16, m_mono16_bkd, m_mono16);
        }
        /// resize
        Mat bb;
        int x,y,w,h;
        int index = g_param->focus;
        switch(index)
        {
        case 0: /// NoScaling
            x = 0;
            y = 0;
            w = g_param->Width-1;
            h = g_param->Height-1;
            break;
        case 1: /// Centre
            x = g_param->Width/4;
            y = g_param->Height/4;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 2: /// UpperLeft
            x = 0;
            y = 0;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 3: /// UpperRight
            x = g_param->Width/2;
            y = 0;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 4: /// LowerLeft
            x = 0;
            y = g_param->Height/2;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 5: /// LowerRight
            x = g_param->Width/2;
            y = g_param->Height/2;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        default: /// NoScaling
            x = 0;
            y = 0;
            w = g_param->Width-1;
            h = g_param->Height-1;
            break;
        }
        cv::Rect rect(x,y,w,h);
        bb = m_mono16(rect);
        cv::resize(bb, m_mono16_scale, Size(m_img_width, m_img_height));
        ///GrayVal
        if(g_param->m_LeftButton == true)
        {
            g_param->grayval = (int)m_mono16_scale.at<ushort>(g_param->displayParam.mouseClickPos.y,g_param->displayParam.mouseClickPos.x);
        }
        if(g_param->flag_mat == true &&  g_param->flag_copyover == false)
        {
            g_param->flag_stop = true;
            g_param->current_date = g_param->current_date2;
            g_param->current_time = g_param->current_time2;
            m_mono16.copyTo(g_param->m16);
            g_param->flag_copyover = true;
            g_param->flag_mat = false;
        }
        g_param->flag_stop = false;
    }
    return true;
}

void ImageProcessing::run()
{
    bRefreshTime = true;
    while(true == m_bCapture )
    {
        if(bRefreshTime == true)
        {
            time_fps_counter = cv::getTickCount();
        }
        if(readCurrentFrame() == true)
        {
            g_param->EstimateGather = true;
            bRefreshTime = true;
            if(m_mono16_scale.empty() || m_mono16_scale.cols <= 0 || m_mono16_scale.rows <= 0)
            {
                qDebug() << "InfraredCamera::run m_mono16 size error";
                continue;
            }
            g_param->EstimateGather = true;
            g_param->b_showBackgroundMap = false;
            g_param->show = g_param->controlParam.ShowImage;
            if(g_param->bShowBit == false)
            {
                if(g_param->bShowSkyRight == false)
                {
                    contrastStretch(g_param->displayParam.IR_up_factor, g_param->displayParam.IR_low_factor,false);
                    if(m_mono8.empty())
                    {
                        qDebug() << "InfraredCamera::run m_mono8 size error";
                        continue;
                    }
                    cv::cvtColor(m_mono8, m_rgb8, COLOR_GRAY2BGR);
                    g_param->imageProcessQueue_VS.enqueue(m_rgb8);
                    m_rgb8.copyTo(g_param->imageDisplay);
                }
                else
                {
                    contrastStretch(g_param->displayParam.IR_up_factor, g_param->displayParam.IR_low_factor,true);
                    if(m_mono8.empty())
                    {
                        qDebug() << "InfraredCamera::run m_mono8 size error";
                        continue;
                    }
                    cv::cvtColor(m_mono8, m_rgb8, COLOR_GRAY2BGR);
                    g_param->imageProcessQueue_VS.enqueue(m_rgb8);
                    m_rgb8.copyTo(g_param->imageDisplay);
                }

            }
            else
            {
                double ratio = qPow(0.5,g_param->i_setImageBitShow);
                m_mono16_scale.convertTo(m_mono8_jd,CV_8UC1,ratio);
                cv::cvtColor(m_mono8_jd, m_rgb8, COLOR_GRAY2BGR);
                m_rgb8.copyTo(g_param->imageDisplay);
                g_param->imageProcessQueue_VS.enqueue(m_rgb8);

            }

            ///Histogram
            const int channels[] = { 0 };
            int dims = 1;
            const int histSize[] = { 256 };
            float pranges[] = { 0, 255 };
            const float* ranges[] = { pranges };
            calcHist(&m_rgb8, 1, channels, Mat(), g_param->hist, dims, histSize, ranges, true, false);
        }
        else
        {
            bRefreshTime = false;
            continue;
        }
        time_fps_counter = cv::getTickCount() - time_fps_counter;
        totalFramefps = (cv::getTickFrequency() / time_fps_counter);
        g_param->camerafps = totalFramefps;
    }
    stopCapture();
}

bool ImageProcessing::contrastStretch(float up_factor, float low_factor, bool para)
{
    Mat means, stddevs;
    double max = 0;
    double min = 65535;
    double upper_bound;
    double lower_bound;
    float fScale = 1.0;
    meanStdDev(m_mono16_scale, means, stddevs);
    g_param->MeanValue = QString::number(means.at<double>(0));
    g_param->Variance = QString::number(stddevs.at<double>(0));

    if(para == false)
    {
        upper_bound = means.at<double>(0) + up_factor*stddevs.at<double>(0);
        lower_bound = means.at<double>(0) - low_factor*stddevs.at<double>(0);
    }
    else
    {
        upper_bound = means.at<double>(0) + up_factor*stddevs.at<double>(0);
        lower_bound = means.at<double>(0) + low_factor*stddevs.at<double>(0);
        fScale = (float)224./(upper_bound-lower_bound);
    }

    //qDebug() << upper_bound << ", " << lower_bound;


    if(upper_bound <= lower_bound)
    {
        double tmp = upper_bound;
        lower_bound = upper_bound;
        upper_bound = tmp;
    }
    if(lower_bound < 0)
    {
        lower_bound = 0;
    }
    if(upper_bound > 65535)
    {
        upper_bound = 65535;
    }
    if(para == false)
    {
        for(int j = 0; j < m_img_height; j++)
        {
            for(int i = 0; i < m_img_width; i++)
            {
                if(m_mono16_scale.at<ushort>(j,i) > max)
                {
                    max = m_mono16_scale.at<ushort>(j,i);
                }
                if(m_mono16_scale.at<ushort>(j,i) < min)
                {
                    min = m_mono16_scale.at<ushort>(j,i);
                }
                if(m_mono16_scale.at<ushort>(j,i) < lower_bound)
                {
                    m_mono8.at<uchar>(j,i) = 0;
                }
                else if(m_mono16_scale.at<ushort>(j,i) > upper_bound)
                {
                    m_mono8.at<uchar>(j,i) = 255;
                }
                else
                {
                    m_mono8.at<uchar>(j,i) = (uchar)((m_mono16_scale.at<ushort>(j,i) - lower_bound) * 255.0 / (upper_bound - lower_bound + 0.0000001));
                }
            }
        }
    }
    else
    {
        for(int j = 0; j < m_img_height; j++)
        {
            for(int i = 0; i < m_img_width; i++)
            {
                if(m_mono16_scale.at<ushort>(j,i) > max)
                {
                    max = m_mono16_scale.at<ushort>(j,i);
                }
                if(m_mono16_scale.at<ushort>(j,i) < min)
                {
                    min = m_mono16_scale.at<ushort>(j,i);
                }
                if(m_mono16_scale.at<ushort>(j,i) < lower_bound)
                {
                    m_mono8.at<uchar>(j,i) = 32;
                }
                else if(m_mono16_scale.at<ushort>(j,i) > upper_bound)
                {
                    m_mono8.at<uchar>(j,i) = 255;
                }
                else
                {
                    m_mono8.at<uchar>(j,i) = 32+(uchar)((m_mono16_scale.at<ushort>(j,i) - lower_bound) * fScale);
                }
            }
        }
    }
    g_param->MaxGrayValue = QString::number(max);
    g_param->MinGrayValue = QString::number(min);

    return true;

}

