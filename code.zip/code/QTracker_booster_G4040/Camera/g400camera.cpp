#include "g400camera.h"

G400Camera::G400Camera()
{   
    m_img_width = g_param->displayParam.VS_size.width;
    m_img_height = g_param->displayParam.VS_size.height;

    m_mono16 = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16_bkd = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16_scale = Mat::zeros(m_img_height,m_img_width,CV_16UC1);
    m_mono8 = Mat::zeros(m_img_height,m_img_width,CV_8UC1);
    m_mono16_bin = Mat::zeros(g_param->Height/2,g_param->Width/2,CV_16UC1);
    m_mono8_jd = Mat::zeros(m_img_height,m_img_width,CV_8UC1);
    m_mono16bkd = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16bkd1 = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16bkd2 = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);

}

G400Camera::~G400Camera()
{
    if(NULL != g_param->framebuffer)
    {
        delete g_param->framebuffer;
        g_param->framebuffer = NULL;
    }
    close();

}

bool G400Camera::init()
{
    _width = g_param->cameraconfigParam.ResolutionW;
    _height = g_param->cameraconfigParam.ResolutionH;
    g_param->Width = g_param->cameraconfigParam.ResolutionW;
    g_param->Height = g_param->cameraconfigParam.ResolutionH;
    uint32_t taps = g_param->cameraconfigParam.ImageTap;
    uint32_t bits = g_param->cameraconfigParam.ImageBit;
    uint32_t mode;
    qDebug()<<"_width"<<_width<<"_height"<<_height<<"taps"<<taps<<"bits"<<bits;
    switch (g_param->cameraconfigParam.CameraLinkMode)
    {
    case 0:
        mode = 0x0;
        break;
    case 1:
        mode = 0x1;
        break;
    case 2:
        mode = 0x2;
        break;
    default:
        break;
    }
    uint32_t num = 4;
    _bytes_per_pixel = (bits == 8 ? 1 : 2);
    camera_cam_size = _width*_height*_bytes_per_pixel*taps;
    GetCameraParam(_width, _height, taps, bits, mode, num);
    g_param->serial_send_satrt = true;

    return true;
}

void G400Camera::close()
{
    stopCapture();
    closecameralink_recv();
    xdma_app_stop();

}

void G400Camera::startCapture()
{
    m_mono16 = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16_bkd = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16_scale = Mat::zeros(m_img_height,m_img_width,CV_16UC1);
    m_mono8 = Mat::zeros(m_img_height,m_img_width,CV_8UC1);
    m_mono16_bin = Mat::zeros(g_param->Height/2,g_param->Width/2,CV_16UC1);
    m_mono8_jd = Mat::zeros(m_img_height,m_img_width,CV_8UC1);
    m_mono16bkd = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16bkd1 = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    m_mono16bkd2 = Mat::zeros(g_param->Height,g_param->Width,CV_16UC1);
    g_param->imageDisplay = NULL;

    capture_proc();
    m16count = _width*_height;
    uart_port_init(0,g_param->controlParam.TestCameraBaud);
    uart_port_init(g_param->controlParam.qSerialPort.toInt(),115200);
    g_param->uart_recv_work = true;

    if(m_bCapture == false)
    {
        m_bCapture = true;
        start(QThread::NormalPriority);
    }

}

void G400Camera::stopCapture()
{
    m_bCapture = false;
}

bool G400Camera::readCurrentFrame()
{
    if(outputImageState() == rev_ImageState)
    {
        return false;
    }
    rev_ImageState = outputImageState();
    _buf = outputMat();
    if(_buf == NULL)
    {
        qDebug() << "G400Camrea::readCurrentFrame mono16_raw NULL";
        return false;
    }
    bufToRGB();
    if(g_param->Width == 0 || g_param->Height == 0)
    {
        return false;
    }

    if(g_param->Width < curMat.cols || g_param->Width == curMat.cols)
    {
        /// resize
        Mat bb;
        int x,y,w,h;
        int index = g_param->focus;
        switch(index)
        {
        case 0: /// NoScaling
            x = 0;
            y = 0;
            w = g_param->Width;
            h = g_param->Height;
            break;
        case 1: /// Centre
            x = g_param->Width/4;
            y = g_param->Height/4;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 2: /// UpperLeft
            x = 0;
            y = 0;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 3: /// UpperRight
            x = g_param->Width/2;
            y = 0;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 4: /// LowerLeft
            x = 0;
            y = g_param->Height/2;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        case 5: /// LowerRight
            x = g_param->Width/2;
            y = g_param->Height/2;
            w = g_param->Width/2;
            h = g_param->Height/2;
            break;
        default: /// NoScaling
            x = 0;
            y = 0;
            w = g_param->Width;
            h = g_param->Height;
            break;
        }
        cv::Rect rect(x,y,w,h);
        bb = curMat(rect);
        cv::resize(bb, curMat_scale, Size(m_img_width, m_img_height));
    }
    else
    {
        cv::resize(curMat, curMat_scale, Size(m_img_width, m_img_height));
    }

    ///GrayVal
    if(g_param->m_LeftButton == true)
    {
        g_param->grayval = (int)curMat_scale.at<ushort>(g_param->displayParam.mouseClickPos.y,g_param->displayParam.mouseClickPos.x);
    }
    if(g_param->flag_mat == true &&  g_param->flag_copyover == false)
    {
        g_param->flag_stop = true;
        g_param->current_date = g_param->current_date2;
        g_param->current_time = g_param->current_time2;
        curMat.copyTo(g_param->m16);
        g_param->flag_copyover = true;
        g_param->flag_mat = false;
    }
    g_param->flag_stop = false;

    return true;
}


void G400Camera::ControlConfigFile_zhang()
{

    FILE *fp;
    char tmp[100];
    char Tem[4];
    char Hum[4];
    char Fix[2];
    char Short_exp[2];
    char Long_exp[2];
    char Press[4];
    char AZeroErr[4];
    char EZeroErr[4];
    unsigned char Hz[1];
    int size = 0;
    //char *ar;
    QString str;
    QString path2 = "/home/pi/hdd/IMAGE/CCD_CONTROL.DAT";
    //QString path2 = "/home/pi/hdd/CCD_CONTROL.DAT";
    QStorageInfo dirFress;
    dirFress.setPath("/home/pi/hdd");
    g_param->FreeStoreSize = dirFress.bytesAvailable()/1024/1024/1024;

    if(!QFile(path2).exists())
    {
        qDebug() << path2 << " file load error!";
        return;
    }
    else
    {
        fp = fopen(path2.toLatin1(),"rb");
        if(fp!=NULL)
        {
            //qDebug()<<"control";
            //fseek(fp,0,SEEK_END);
            //size = ftell(fp);
            //rewind(fp);
            //ar = (char*)malloc(sizeof(char)*size);
            fread(tmp,1,89,fp);
            fclose(fp);
            //QFile::remove(path2);
            //str = G400Camera::ByteArrayToHexString(tmp);
            if(tmp[0]== 0xef)
            {
                if(tmp[1] == 0x01)
                {
                    g_param->struct_ccd_control_in.bCCDPowerOn = true;
                    //qDebug()<<"poweron";
                }
                else
                {
                    g_param->struct_ccd_control_in.bCCDPowerOn = false;
                    //qDebug()<<"poweroff";
                }
                if(g_param->FreeStoreSize<1)
                {
                    g_param->struct_ccd_control_in.bAcquireImage = false;
                    g_param->debugParam.bSaveRawFileOnceGrab = false;
                    g_param->savefitsimage = false;
                }
                else
                {
                    if(g_param->b_savefits == true)
                    {
                        g_param->struct_ccd_control_in.bAcquireImage = true;
                        g_param->debugParam.bSaveRawFileOnceGrab = true;
                    }
                    else
                    {
                        if(tmp[2] == 0x01)
                        {
                            g_param->struct_ccd_control_in.bAcquireImage = true;
                            g_param->debugParam.bSaveRawFileOnceGrab = true;
                            if(g_param->savefitsimage == false)
                            {
                                g_param->sign_saveIPD = true;
                            }
                            g_param->savefitsimage = true;
                        }
                        else
                        {
                            g_param->struct_ccd_control_in.bAcquireImage = false;
                            g_param->debugParam.bSaveRawFileOnceGrab = false;
                            g_param->savefitsimage = false;
                        }
                    }
                }

                if(tmp[5] == 0x01)
                {
                    g_param->struct_ccd_control_in.bShortAndLongExp = true;
                }
                else
                {
                    g_param->struct_ccd_control_in.bShortAndLongExp = false;
                }

                Hz[0] = tmp[8];
                g_param->struct_ccd_control_in.nImageFreq =*((unsigned char*)Hz);
                //qDebug()<<"g_param->struct_ccd_control_in.nImageFreq"<<g_param->struct_ccd_control_in.nImageFreq;
                //g_param->struct_ccd_control_in.nImageFreq = tmp[8];
                g_param->hz = QString::number(g_param->struct_ccd_control_in.nImageFreq);

                g_param->struct_ccd_control_in.nMBBH = tmp[13]+tmp[14]*256+tmp[15]*256*256+tmp[16]*256*256*256;
                /*if(g_param->struct_ccd_control_in.nMBBH == 0)
                {
                    g_param->flag_save = false;
                }
                else
                {
                    g_param->flag_save = true;
                }*/
                g_param->struct_ccd_control_in.nPass = tmp[17];
                g_param->struct_ccd_control_in.nSHBH = tmp[18]+tmp[19]*256;

                Tem[0] = tmp[26];
                Tem[1] = tmp[27];
                Tem[2] = tmp[28];
                Tem[3] = tmp[29];
                g_param->struct_ccd_control_in.fTemperature = *((float*)Tem);
                Hum[0] = tmp[30];
                Hum[1] = tmp[31];
                Hum[2] = tmp[32];
                Hum[3] = tmp[33];
                g_param->struct_ccd_control_in.fHumidity = *((float*)Hum);
                Press[0] = tmp[34];
                Press[1] = tmp[35];
                Press[2] = tmp[36];
                Press[3] = tmp[37];
                g_param->struct_ccd_control_in.fPressure = *((float*)Press);
                if(g_param->struct_ccd_control_in.bShortAndLongExp == true)
                {
                    Short_exp[0] = tmp[22];
                    Short_exp[1] = tmp[23];
                    g_param->struct_ccd_control_in.nShortExpTime = *((short*)Short_exp);
                    g_param->short_exp = (QString::number(g_param->struct_ccd_control_in.nShortExpTime) + "000").toInt();
                    Long_exp[0] = tmp[24];
                    Long_exp[1] = tmp[25];
                    g_param->struct_ccd_control_in.nLongExptime = *((short*)Long_exp);
                    g_param->long_exp = (QString::number(g_param->struct_ccd_control_in.nLongExptime) + "000").toInt();
                }
                else
                {
                    Fix[0] = tmp[20];
                    Fix[1] = tmp[21];
                    g_param->struct_ccd_control_in.nFixExptime = *((short*)Fix);
                    int mm = QString::number(g_param->struct_ccd_control_in.nFixExptime).toInt();
                    g_param->exp = (QString::number(g_param->struct_ccd_control_in.nFixExptime) + "000").toInt();
                    if(g_param->b_USBCamera == true)
                    {
                        if(g_param->usbexp != g_param->exp && g_param->setusbcameraexpok == true)
                        {
                            g_param->setusbcameraexpok = false;
                            g_param->usbexp = g_param->exp;
                            g_param->expouse = mm;
                            g_param->expose_ipd = mm;

                        }
                    }


                }
                if(tmp[38] != 0x00)
                {
                    if(g_param->b_G4040Camera == true)
                    {
                        g_param->gain_index = QString::number(tmp[38]).toInt()-1;
                        if(g_param->gain_index >= 16)
                        {
                            g_param->gain_index = 16;
                        }
                        if(g_param->gain != g_param->gain_index)
                        {
                            g_param->gain = g_param->gain_index;
                        }
                    }
                    else if(g_param->b_USBCamera == true)
                    {
                        g_param->gain_index = QString::number(tmp[38]).toInt();
                        if(usbgain != g_param->gain_index && g_param->setusbcameragainok == true)
                        {
                            g_param->setusbcameragainok = false;
                            usbgain = g_param->gain_index;

                        }
                    }
                    else if(g_param->b_G400Camera == true)
                    {
                        g_param->gain_index = QString::number(tmp[38]).toInt()-1;
                        if(g_param->gain_index >= 6)
                        {
                            g_param->gain_index = 6;
                        }
                        if(g_param->gain != g_param->gain_index)
                        {
                            g_param->gain = g_param->gain_index;
                        }
                    }


                }
                AZeroErr[0] = tmp[39];
                AZeroErr[1] = tmp[40];
                AZeroErr[2] = tmp[41];
                AZeroErr[3] = tmp[42];
                g_param->struct_ccd_control_in.fAZeroError = *((float*)AZeroErr);
                //qDebug()<<"AZeroErrAZeroErrAZeroErrAZeroErrAZeroErr"<<g_param->struct_ccd_control_in.fAZeroError;
                EZeroErr[0] = tmp[43];
                EZeroErr[1] = tmp[44];
                EZeroErr[2] = tmp[45];
                EZeroErr[3] = tmp[46];
                g_param->struct_ccd_control_in.fEZeroError = *((float*)EZeroErr);
                //qDebug()<<"EZeroErrEZeroErrEZeroErrEZeroErrEZeroErr"<<g_param->struct_ccd_control_in.fEZeroError;
                return;
            }
        }
        else
        {
            qDebug()<<"null control";
            return;
        }
    }

}
void G400Camera::WriteCameraLog(QString information)
{
    QString pathtxt = QString( "/home/pi/hdd/%1.txt").arg("Camera Log");
    QFile file(pathtxt);
    if(file.open(QFile::WriteOnly|QFile::Append))
    {
        QTextStream in(&file);
        QDateTime date_time = QDateTime::currentDateTimeUtc();
        QString getCPUTickCount = date_time.toString("yyyy-MM-dd hh:mm:ss.zzz");
        in<<"\n"<<getCPUTickCount<<"\t"<<information;
    }
}

void G400Camera::run()
{
    bRefreshTime = true;
    while(true == m_bCapture )
    {
        if(bRefreshTime == true)
        {
            time_fps_counter = cv::getTickCount();
        }
        if(readCurrentFrame() == true)
        {
            g_param->EstimateGather = true;
            bRefreshTime = true;
            if(curMat_scale.empty() || curMat_scale.cols <= 0 || curMat_scale.rows <= 0)
            {
                qDebug() << "Camera::run curMat_scale size error";
                continue;
            }
            if(g_param->savejpg == true||g_param->startsavejpg == true)
            {
                QDir dir;
                if(!dir.exists("/home/orangepi/hdd/Pictures"))
                {
                    dir.mkdir("/home/orangepi/hdd/Pictures");
                }
                QString path = QString("/home/orangepi/hdd/Pictures/%1.jpg").arg(cv::getCPUTickCount());
                cv::imwrite(path.toLatin1().data(), g_param->imageDisplay);
                g_param->savejpg = false;
            }
            if(g_param->savetiff == true||g_param->startsavetiff == true)
            {
                QDir dir;
                if(!dir.exists("/home/orangepi/hdd/Pictures"))
                {
                    dir.mkdir("/home/orangepi/hdd/Pictures");
                }
                QString path = QString("/home/orangepi/hdd/Pictures/%1.tif").arg(cv::getCPUTickCount());
                cv::imwrite(path.toLatin1().data(), curMat);
                g_param->savetiff = false;
            }
            if(g_param->saveraw == true||g_param->startsaveraw == true)
            {
                QDir dir;
                if(!dir.exists("/home/orangepi/hdd/Pictures"))
                {
                    dir.mkdir("/home/orangepi/hdd/Pictures");
                }
                ushort* rawdata = (ushort*)(curMat.data);
                QString path = QString("/home/orangepi/hdd/Pictures/%1.raw").arg(cv::getCPUTickCount());
                QByteArray p = path.toLatin1();
                char* Path = p.data();
                FILE *fp;
                fp = fopen(Path,"wb");
                if(fp!=NULL)
                {
                    fwrite(rawdata,sizeof(ushort),g_param->Width*g_param->Height,fp);
                }
                g_param->saveraw = false;
            }
            g_param->show = g_param->controlParam.ShowImage;
            if(g_param->cameraconfigParam.ImageBit > 8)
            {
                if(g_param->bShowBit == false)
                {
                    if(g_param->bShowSkyRight == false)
                    {
                        contrastStretch(g_param->displayParam.IR_up_factor, g_param->displayParam.IR_low_factor,false);
                        if(m_mono8.empty())
                        {
                            qDebug() << "InfraredCamera::run m_mono8 size error";
                            continue;
                        }
                        cv::cvtColor(m_mono8, m_rgb8, COLOR_GRAY2RGB);
                        if(g_param->b_ImageEnhancement == true)
                        {
                            filter2D(m_rgb8, m_rgb8, CV_8UC1, kernel);
                        }
                        g_param->imageProcessQueue_VS.enqueue(m_rgb8);
                        m_rgb8.copyTo(g_param->imageDisplay);
                    }
                    else
                    {
                        contrastStretch(g_param->displayParam.IR_up_factor, g_param->displayParam.IR_low_factor,true);
                        if(m_mono8.empty())
                        {
                            qDebug() << "InfraredCamera::run m_mono8 size error";
                            continue;
                        }
                        cv::cvtColor(m_mono8, m_rgb8, COLOR_GRAY2RGB);
                        if(g_param->b_ImageEnhancement == true)
                        {
                            filter2D(m_rgb8, m_rgb8, CV_8UC1, kernel);
                        }
                        g_param->imageProcessQueue_VS.enqueue(m_rgb8);
                        m_rgb8.copyTo(g_param->imageDisplay);
                    }

                }
                else
                {
                    double ratio = qPow(0.5,g_param->i_setImageBitShow);
                    m_mono16_scale.convertTo(m_mono8_jd,CV_8UC1,ratio);
                    cv::cvtColor(m_mono8_jd, m_rgb8, COLOR_GRAY2RGB);
                    if(g_param->b_ImageEnhancement == true)
                    {
                        filter2D(m_rgb8, m_rgb8, CV_8UC1, kernel);
                    }
                    m_rgb8.copyTo(g_param->imageDisplay);
                    g_param->imageProcessQueue_VS.enqueue(m_rgb8);
                }

            }
            else
            {
                if(g_param->cameraconfigParam.ImageTap == 1||g_param->cameraconfigParam.ImageTap == 2)
                {
                    cv::cvtColor(curMat_scale, m_rgb8, COLOR_GRAY2RGB);
                    if(g_param->b_ImageEnhancement == true)
                    {
                        filter2D(m_rgb8, m_rgb8, CV_8UC1, kernel);
                    }
                    m_rgb8.copyTo(g_param->imageDisplay);
                    g_param->imageProcessQueue_VS.enqueue(m_rgb8);
                }
                else
                {
                    if(g_param->b_ImageEnhancement == true)
                    {
                        filter2D(curMat_scale, curMat_scale, CV_8UC1, kernel);
                    }
                    curMat_scale.copyTo(g_param->imageDisplay);
                    g_param->imageProcessQueue_VS.enqueue(curMat_scale);
                }

            }

        }
        else
        {
            bRefreshTime = false;
            continue;
        }
        time_fps_counter = cv::getTickCount() - time_fps_counter;
        totalFramefps = (cv::getTickFrequency() / time_fps_counter);
        g_param->camerafps = totalFramefps;

    }
    stopCapture();
}

void G400Camera::calcHistHistogram(Mat Img)
{
    const int channels[] = { 0 };
    int dims = 1;
    const int histSize[] = { 256 };
    float pranges[] = { 0, 255 };
    const float* ranges[] = { pranges };
    calcHist(&Img, 1, channels, Mat(), g_param->hist, dims, histSize, ranges, true, false);
}

bool G400Camera::contrastStretch(float up_factor, float low_factor, bool para)
{
    Mat means, stddevs;
    double upper_bound;
    double lower_bound;
    float fScale = 1.0;
    meanStdDev(curMat_scale, means, stddevs);
    if(para == false)
    {
        upper_bound = means.at<double>(0) + up_factor*stddevs.at<double>(0);
        lower_bound = means.at<double>(0) - low_factor*stddevs.at<double>(0);
    }
    else
    {
        upper_bound = means.at<double>(0) + up_factor*stddevs.at<double>(0);
        lower_bound = means.at<double>(0) + low_factor*stddevs.at<double>(0);
        fScale = (float)224./(upper_bound-lower_bound);
    }


    if(upper_bound <= lower_bound)
    {
        double tmp = upper_bound;
        lower_bound = upper_bound;
        upper_bound = tmp;
    }
    if(lower_bound < 0)
    {
        lower_bound = 0;
    }
    if(upper_bound > 65535)
    {
        upper_bound = 65535;
    }
    if(para == false)
    {
        for(int j = 0; j < m_img_height; j++)
        {
            for(int i = 0; i < m_img_width; i++)
            {
                if(curMat_scale.at<ushort>(j,i) < lower_bound)
                {
                    m_mono8.at<uchar>(j,i) = 0;
                }
                else if(curMat_scale.at<ushort>(j,i) > upper_bound)
                {
                    m_mono8.at<uchar>(j,i) = 255;
                }
                else
                {
                    m_mono8.at<uchar>(j,i) = (uchar)((curMat_scale.at<ushort>(j,i) - lower_bound) * 255.0 / (upper_bound - lower_bound + 0.0000001));
                }
            }
        }
    }
    else
    {
        for(int j = 0; j < m_img_height; j++)
        {
            for(int i = 0; i < m_img_width; i++)
            {
                if(curMat_scale.at<ushort>(j,i) < lower_bound)
                {
                    m_mono8.at<uchar>(j,i) = 32;
                }
                else if(curMat_scale.at<ushort>(j,i) > upper_bound)
                {
                    m_mono8.at<uchar>(j,i) = 255;
                }
                else
                {
                    m_mono8.at<uchar>(j,i) = 32+(uchar)((curMat_scale.at<ushort>(j,i) - lower_bound) * fScale);
                }
            }
        }
    }
    return true;

}

void G400Camera::yuv420ToRGB()
{
    std::vector<unsigned char> buffer(camera_cam_size);
    unsigned char* uc_ptr = static_cast<unsigned char*>(_buf);
    buffer.assign(uc_ptr,uc_ptr+camera_cam_size);

    int image_width = g_param->cameraconfigParam.ResolutionW;
    int image_height = g_param->cameraconfigParam.ResolutionH;

    cv::Mat y_plane(image_height + image_height / 2, image_width, CV_8UC1);
    cv::Mat u_plane(image_height / 2, image_width / 2, CV_8UC1);
    cv::Mat v_plane(image_height / 2, image_width / 2, CV_8UC1);
    cv::Mat reshaped_u(image_height / 4, image_width, CV_8UC1);
    cv::Mat reshaped_v(image_height / 4, image_width , CV_8UC1);

    int numThreads = 4;
    int chunk_size = image_height / numThreads;
    for (int t = 0; t < numThreads; ++t)
    {
        int start_row = t * chunk_size;
        int end_row = (t == numThreads - 1) ? image_height : start_row + chunk_size;
        for (int i = start_row; i < end_row; i++)
        {
            for (int j = 0; j < image_width / 2; j++)
            {
                y_plane.at<uchar>(i, j * 2) = buffer[(i * image_width / 2 + j) * 3];
                y_plane.at<uchar>(i, j * 2 + 1) = buffer[(i * image_width / 2 + j) * 3 + 1];
            }
        }
    }
    chunk_size = image_height / (2 * numThreads);
    for (int t = 0; t < numThreads; ++t)
    {
        int start_row = t * chunk_size;
        int end_row = (t == numThreads - 1) ? (image_height / 2) : (start_row + chunk_size);
        for (int i = start_row; i < end_row; i++)
        {
                for (int j = 0; j < image_width / 2; j++)
                {
                    u_plane.at<uchar>(i, j) = buffer[(i * image_width / 2 + j) * 6 + 2];
                    v_plane.at<uchar>(i, j) = buffer[(i * image_width / 2 + j) * 6 + 5];
                }
            }
    }
    chunk_size = (image_height / 4) / numThreads;
    for (int t = 0; t < numThreads; ++t)
    {
        int start_row = t * chunk_size;
        int end_row = (t == numThreads - 1) ? (image_height / 4) : (start_row + chunk_size);
        for (int i = start_row; i < end_row; ++i)
        {
            for (int j2 = 0; j2 < image_width / 2; ++j2)
            {
                reshaped_u.at<uchar>(i, j2 * 2) = u_plane.at<uchar>(i * 2, j2);
                reshaped_u.at<uchar>(i, j2 * 2 + 1) = u_plane.at<uchar>(i * 2 + 1, j2);
            }
        }
    }
    for (int t = 0; t < numThreads; ++t)
    {
        int start_row = t * chunk_size;
        int end_row = (t == numThreads - 1) ? (image_height / 4) : (start_row + chunk_size);
        for (int i = start_row; i < end_row; ++i)
        {
            for (int j2 = 0; j2 < image_width / 2; ++j2)
            {
                reshaped_v.at<uchar>(i, j2 * 2) = v_plane.at<uchar>(i * 2, j2);
                reshaped_v.at<uchar>(i, j2 * 2 + 1) = v_plane.at<uchar>(i * 2 + 1, j2);
            }
        }
    }

    cv::Mat yuv_image = y_plane;
    cv::Mat uv_image(image_height / 2, image_width, CV_8UC1);
    cv::vconcat(reshaped_u, reshaped_v, uv_image);
    uv_image.copyTo(yuv_image(cv::Rect(0, image_height, image_width, image_height / 2)));
    cv::cvtColor(yuv_image, curMat, cv::COLOR_YUV2BGR_I420);
}

void G400Camera::bufToRGB()
{
    bool ook;
    QString yearhex = QString("%1").arg(static_cast<uchar>(_buf[13]),2,16,QLatin1Char('0')) + QString("%1").arg(static_cast<uchar>(_buf[12]),2,16,QLatin1Char('0'));
    QString year = QString::number(yearhex.toInt(&ook,16));
    QString mouth = QString::number(static_cast<uchar>(_buf[14]));
    QString day = QString::number(static_cast<uchar>(_buf[15]));
    QString hour = QString("%1").arg(static_cast<uchar>(_buf[16]),2,16,QLatin1Char('0'));
    QString minute = QString("%1").arg(static_cast<uchar>(_buf[17]),2,16,QLatin1Char('0'));
    QString s = QString("%1").arg(static_cast<uchar>(_buf[18]),2,16,QLatin1Char('0'));
    QString mshex = QString("%1").arg(static_cast<uchar>(_buf[20]),2,16,QLatin1Char('0')) + QString("%1").arg(static_cast<uchar>(_buf[19]),2,16,QLatin1Char('0'));
    QString ms = (QString::number(mshex.toInt(&ook,16))).mid(0,2);
    g_param->DisplayTime = year + "-" + mouth + "-" + day + " " + hour + ":" + minute + ":" + s + "." + ms;

    //qDebug()<<"g_param->DisplayTime"<<g_param->DisplayTime;
    if(g_param->cameraconfigParam.ImageBit > 8)
    {
        ushort *m16buf = new ushort[m16count];
        for(int i = 0; i < m16count - 1; i ++)
        {
            m16buf[i] = static_cast<ushort>((_buf[i * 2 + 1] << 8) | _buf[i * 2]);
        }
        g_param->cameraconfigParam.DisplayImageTap = 1;
        cv::Mat ImageMat(g_param->cameraconfigParam.ResolutionH,g_param->cameraconfigParam.ResolutionW,CV_16UC1,m16buf);
        ImageMat.copyTo(curMat);
        delete m16buf;
    }
    else
    {
        if(g_param->cameraconfigParam.ImageTap == 1 || g_param->cameraconfigParam.ImageTap == 2)
        {
            g_param->cameraconfigParam.DisplayImageTap = 1;
            cv::Mat ImageMat(g_param->cameraconfigParam.ResolutionH,g_param->cameraconfigParam.ResolutionW,CV_8UC1,_buf);
            ImageMat.copyTo(curMat);
        }
        else if(g_param->cameraconfigParam.ImageTap == 3)
        {
            g_param->cameraconfigParam.DisplayImageTap = 3;
            cv::Mat ImageMat(g_param->cameraconfigParam.ResolutionH,g_param->cameraconfigParam.ResolutionW,CV_8UC3,_buf);
            ImageMat.copyTo(curMat);

        }
    }
    if(g_param->b_EleImageStab == true || g_param->pccontrolparam.EleImageStab == true)
    {
        curMat.copyTo(ImageMatS);
        if(ImageCount > 1)
        {
            curMat = ImageStabilization(prevImageS, curMat);
        }
        else
        {
            ImageCount ++;
        }
        ImageMatS.copyTo(prevImageS);
    }
    if(g_param->controlParam.TCPOPEN == true)
    {
        curMat.copyTo(g_param->TcpImage);
        emit SignalGrabData();
    }
}

vector<Trajectory> cumsum(vector<TransformParam> &transforms)
{
    vector<Trajectory> trajectory;
    double a = 0;
    double x = 0;
    double y = 0;

    if(ImageCount > 500)
    {
        n = 1;
    }
    else
    {
        ImageCount ++;
        n = 0;
    }
    for(size_t i = n; i < transforms.size()-n; i++)
    {
        x += transforms[i].dx;
        y += transforms[i].dy;
        a += transforms[i].da;
        trajectory.push_back(Trajectory(x, y, a));
    }
    return trajectory;
}

vector<Trajectory> smooth(vector<Trajectory> &trajectory, int radius)
{
    vector<Trajectory> smoothed_trajectory;
    for(size_t i = 0; i < trajectory.size(); i ++)
    {
        double sum_x = 0;
        double sum_y = 0;
        double sum_a = 0;
        int count = 0;
        for(int j = -radius; j <= radius; j ++)
        {
            if(i + j >= 0 && i + j < trajectory.size())
            {
                sum_x += trajectory[i + j].x;
                sum_y += trajectory[i + j].y;
                sum_a += trajectory[i + j].a;

                count ++;
            }
        }
        double avg_a = sum_a / count;
        double avg_x = sum_x / count;
        double avg_y = sum_y / count;

        smoothed_trajectory.push_back(Trajectory(avg_x, avg_y, avg_a));
    }
    return smoothed_trajectory;
}

void fixBorder(cv::Mat &frame_stabilized)
{
    Mat T = getRotationMatrix2D(Point2f(frame_stabilized.cols / 2, frame_stabilized.rows / 2), 0, 1.04);
    warpAffine(frame_stabilized, frame_stabilized, T, frame_stabilized.size());
}
vector<TransformParam> transforms;
cv::Mat ImageStabilization(cv::Mat InputprevImage, cv::Mat InputcurrImage)
{
    cv::Mat curr_gray;
    cv::Mat prev_gray;
    cv::cvtColor(InputprevImage, prev_gray, cv::COLOR_RGB2GRAY);
    //vector<TransformParam> transforms;
    //cv::Mat last_T;
    vector<Point2f> prev_pts, curr_pts;

    goodFeaturesToTrack(prev_gray, prev_pts, 200, 0.01, 30);

    cv::cvtColor(InputcurrImage, curr_gray, cv::COLOR_RGB2GRAY);
    vector<uchar> status;
    vector<float> err;
    //qDebug()<<"prev_gray"<<prev_gray.cols<<prev_gray.rows<<"curr_gray"<<curr_gray.cols<<curr_gray.rows;
    calcOpticalFlowPyrLK(prev_gray, curr_gray, prev_pts, curr_pts, status, err);
    auto prev_it = prev_pts.begin();
    auto curr_it = curr_pts.begin();
    for(size_t k = 0; k < status.size(); k ++)
    {
        if(status[k])
        {
            prev_it ++;
            curr_it ++;
        }
        else
        {
            prev_it = prev_pts.erase(prev_it);
            curr_it = curr_pts.erase(curr_it);
        }
    }
    cv::Mat T = estimateRigidTransform(prev_pts, curr_pts, false);
    if(T.data == NULL)
    {
        return InputcurrImage;
        ImageCount = 1;
        //last_T.copyTo(T);
    }
    //T.copyTo(last_T);
    double dx = T.at<double>(0,2);
    double dy = T.at<double>(1,2);
    double da = atan2(T.at<double>(1,0), T.at<double>(0,0));
    transforms.push_back(TransformParam(dx, dy, da));
    vector<Trajectory> trajectory = cumsum(transforms);
    vector<Trajectory> smoothed_trajectory = smooth(trajectory, SMOOTHING_RADIUS);
    vector<TransformParam> transforms_smooth;
    int L = transforms.size() - 1;
    for(size_t i = 0; i < transforms.size(); i++)
    {
        double diff_x = smoothed_trajectory[i].x - trajectory[i].x;
        double diff_y = smoothed_trajectory[i].y - trajectory[i].y;
        double diff_a = smoothed_trajectory[i].a - trajectory[i].a;

        double dx = transforms[i].dx + diff_x;
        double dy = transforms[i].dy + diff_y;
        double da = transforms[i].da + diff_a;

        transforms_smooth.push_back(TransformParam(dx, dy, da));
        //qDebug()<<"diff_x"<<diff_x<<"diff_y"<<diff_y<<"diff_a"<<diff_a<<"dx"<<dx<<"dy"<<dy<<"da"<<da;
    }
    cv::Mat TT(2, 3, CV_64F);
    cv::Mat frame_stabilized, frame_out;
    transforms_smooth[L].getTransform(TT);
    //qDebug()<<"-----"<<transforms_smooth[L].dx<<transforms_smooth[L].dy<<transforms_smooth[L].da;
    warpAffine(InputcurrImage, frame_stabilized, TT, InputcurrImage.size());
    fixBorder(frame_stabilized);

    //hconcat(InputcurrImage, frame_stabilized, frame_out);
    return frame_stabilized;
}

