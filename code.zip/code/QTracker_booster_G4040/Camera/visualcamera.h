#ifndef VISUALCAMERA_H
#define VISUALCAMERA_H

#include <QObject>
#include "camerabase.h"
#include "opencv2/opencv.hpp"
#include "opencv2/core.hpp"
#include "Tool/GlobalParameter.h"

//const int DEV_VIDEO_ID = 6;

class VisualCamera : public CameraBase
{
public:
    VisualCamera();
    ~VisualCamera();
    // QThread interface
protected:
    void run();

    // CameraBase interface
public:
    bool init();
    void close();
    void startCapture();
    void stopCapture();
private:
    bool readCurrentFrame();

private:
    Mat m_rgb8;
    int m_img_height;
    int m_img_width;

    VideoCapture m_cap;
};

#endif // VISUALCAMERA_H
