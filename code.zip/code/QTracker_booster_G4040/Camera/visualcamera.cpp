#include "visualcamera.h"

VisualCamera::VisualCamera()
{
    m_img_width = g_param->displayParam.VS_size.width;
    m_img_height = g_param->displayParam.VS_size.height;

    //m_rgb8 = Mat::zeros(m_img_height,m_img_width,CV_8UC3);
    //g_param->imageCapture = m_rgb8;
}

VisualCamera::~VisualCamera()
{
    close();
    quit();
    wait();
    deleteLater();
}

void VisualCamera::run()
{
//    double time_profile_counter = 0;
    while(true == m_bCapture)
    {
//      time_profile_counter = cv::getCPUTickCount();
        if(readCurrentFrame() == true)
        {
            if(m_rgb8.empty() || m_rgb8.cols <= 0 || m_rgb8.rows <= 0)
            {
                qDebug() << "VisualCamera::run size error";
                continue;
            }


            if(g_param->displayParam.imgSource == VISUAL)
            {
                //m_rgb8.copyTo(g_param->imageDisplay);
                //g_param->imageDetectQueue.enqueue(m_rgb8);
            }
            else
            {
                m_rgb8.copyTo(g_param->imageDisplay_small);
            }

            g_param->imageProcessQueue_VS.enqueue(m_rgb8);
//            g_param->debugParam.inputCount++;
//          qDebug() << "Read: "  << g_param->debugParam.inputCount;
//          time_profile_counter = cv::getCPUTickCount() - time_profile_counter;
//          qDebug() << " FPS: " <<  1000 * (cvGetTickFrequency() * 1000) / time_profile_counter << endl;
        }
    }
    stopCapture();
}

bool VisualCamera::init()
{
    close();
    if(m_cap.isOpened() == true)
    {
        qDebug() << "VisualCamera not release";
        m_cap.release();
    }

    if (m_cap.open(g_param->displayParam.VS_cam_port) == false)
    {
        return false;
    }
    else
    {
        m_cap.set(CAP_PROP_FOURCC, cv::VideoWriter::fourcc('M', 'J', 'P', 'G'));
        m_cap.set(CAP_PROP_FRAME_WIDTH, m_img_width);
        m_cap.set(CAP_PROP_FRAME_HEIGHT, m_img_height);
        //m_cap.set(CV_CAP_PROP_FPS, 30);

        qDebug() <<"USB Camera width: "<<m_cap.get(CAP_PROP_FRAME_WIDTH) <<", height: " << m_cap.get(CAP_PROP_FRAME_HEIGHT);

        //g_param->displayParam.imgSize.width =  m_cap.get(CV_CAP_PROP_FRAME_WIDTH);
        //g_param->displayParam.imgSize.height =  m_cap.get(CV_CAP_PROP_FRAME_HEIGHT);

        return true;
    }
}

void VisualCamera::close()
{
    stopCapture();
    msleep(20);
    m_cap.release();
    //terminate();
}

void VisualCamera::startCapture()
{
    if(m_bCapture == false)
    {
        m_bCapture = true;
        start(QThread::NormalPriority);
    }
}

void VisualCamera::stopCapture()
{
    m_bCapture = false;
}

bool VisualCamera::readCurrentFrame()
{
    if(m_cap.isOpened() == true && m_bCapture == true)
    {
        try{
            m_cap >> m_rgb8;
        }
        catch(cv::Exception e)
        {
            qDebug() << "VisualCamera::readCurrentFrame() " << e.what();
            return false;
        }

        if (m_rgb8.rows <= 0 || m_rgb8.cols <= 0 || m_rgb8.empty())
        {
            qDebug() << "readCurrentFrame::readFrame invalid size";
            return false;
        }
        else
        {
            return true;
        }
    }
    else
    {
        return false;
    }
}

