#include "detectortradition.h"

DetectorTradition::DetectorTradition(QObject *parent) : QObject(parent)
{
     g_param = GlobalParameter::getInstance();

}

DetectorTradition::~DetectorTradition()
{

}

bool DetectorTradition::init()
{
    return true;
}

void DetectorTradition::setTheshold(double thresValue, int minSize)
{
    m_thresValue = thresValue;
    m_minSize = minSize;
}

void DetectorTradition::detect(Mat &frame)
{
    Mat frame_det = frame.clone();
    if(frame_det.empty())
    {
        qDebug() << "DetectorYoloGPU::detect frame_det.empty";
        return;
    }

    // 二值化
    Mat gray, binary;
    cvtColor(frame, gray, COLOR_BGR2GRAY);

    if(g_param->trackParam.bAutoThresTrad)
    {
        g_param->threstradV = threshold(gray, binary, 0, 255, THRESH_OTSU);
        //qDebug()<<"g_param->threstradV---------------------------"<<g_param->threstradV;
    }
    else
    {
        g_param->threstradV = m_thresValue;
        threshold(gray, binary, m_thresValue, 255, THRESH_BINARY);
    }

    //开运算、闭运算
    Mat k = getStructuringElement(MORPH_RECT, Size(m_minSize, m_minSize), Point(-1, -1));
    morphologyEx(binary, binary, MORPH_OPEN, k);
    morphologyEx(binary, binary, MORPH_CLOSE, k);

    //计算连通域
    Mat labels = Mat::zeros(frame.size(), CV_32S);
    Mat stats, centroids;
    int num_labels = connectedComponentsWithStats(binary, labels, stats, centroids, 8, 4);
   // qDebug() <<"tradition num is :"<<num_labels;
    m_mutex.lock();
    m_res.boxes.clear();
    m_res.classNamesID.clear();
    m_res.prob.clear();

    for (int i = 1; i < num_labels; i++)
    {
       // int className = 1024;
        Vec2d pt = centroids.at<Vec2d>(i, 0);
        int x = stats.at<int>(i, CC_STAT_LEFT);
        int y = stats.at<int>(i, CC_STAT_TOP);
        int width = stats.at<int>(i, CC_STAT_WIDTH);
        int height = stats.at<int>(i, CC_STAT_HEIGHT);
        int area = stats.at<int>(i, CC_STAT_AREA);

        m_res.boxes.push_back(Rect(x, y, width, height));
        //qDebug()<<"x:"<<x<<"y:"<<y<<"width:"<<width<<"height:"<<height;
        m_res.classNamesID.push_back(6666);
        m_res.prob.push_back(area);
    }

    /// sort by area
        int count = m_res.prob.size();
        for(int i = 0; i < count - 1; i++)
        {
            for(int j = 0; j < count - 1 - i; ++j)
            {
                if(m_res.prob[j] < m_res.prob[j + 1])
                {
                    float t_prob = 0;
                    t_prob = m_res.prob[j];
                    m_res.prob[j] = m_res.prob[j + 1];
                    m_res.prob[j + 1] = t_prob;

                    Rect t_box = Rect(0,0,0,0);
                    t_box = m_res.boxes[j];
                    m_res.boxes[j] = m_res.boxes[j + 1];
                    m_res.boxes[j + 1] = t_box;

                    int t_classNamesID = 0;
                    t_classNamesID = m_res.classNamesID[j];
                    m_res.classNamesID[j] = m_res.classNamesID[j + 1];
                    m_res.classNamesID[j + 1] = t_classNamesID;
                }
            }
        }

        /// remove redundant data
         if(count > m_max_num)
         {
             m_res.boxes.erase(m_res.boxes.begin() + m_max_num, m_res.boxes.end());
             m_res.classNamesID.erase(m_res.classNamesID.begin() + m_max_num, m_res.classNamesID.end());
             m_res.prob.erase(m_res.prob.begin() + m_max_num, m_res.prob.end());
         }
         m_mutex.unlock();
}

void DetectorTradition::getDetectResult(DetectResult &res)
{
    m_mutex.lock();
    res.boxes.clear();
    res.classNamesID.clear();
    res.prob.clear();
    res.classNamesVec.clear();

    res.classNamesID.assign(m_res.classNamesID.begin(), m_res.classNamesID.end());
    res.prob.assign(m_res.prob.begin(), m_res.prob.end());
    res.classNamesVec.assign(m_res.classNamesVec.begin(), m_res.classNamesVec.end());
    res.boxes.assign(m_res.boxes.begin(), m_res.boxes.end());
    m_mutex.unlock();
}

void DetectorTradition::setMaxOutputNum(uint n)
{
    m_max_num = n;
}
