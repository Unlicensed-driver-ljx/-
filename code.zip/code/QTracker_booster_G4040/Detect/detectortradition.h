#ifndef DETECTORTRADITION_H
#define DETECTORTRADITION_H

#include <QObject>
#include <opencv2/opencv.hpp>
#include "Tool/GlobalParameter.h"
using namespace cv;
class DetectorTradition : public QObject
{
    Q_OBJECT
public:
    explicit DetectorTradition(QObject *parent = nullptr);
    ~DetectorTradition();
    bool init();

    void setTheshold(double thresValue,int minSize= 10);
    void detect(Mat &frame);
    void getDetectResult(DetectResult& res);
    void setMaxOutputNum(uint n);

private:
    GlobalParameter* g_param;
    double m_thresValue;
    int m_minSize;

    DetectResult m_res;
    uint m_max_num; /// 20190807 wangzy
    QMutex m_mutex;

};

#endif // DETECTORTRADITION_H
