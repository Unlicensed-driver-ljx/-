#ifndef DETECTORYOLOGPU_H
#define DETECTORYOLOGPU_H
#include <QObject>
#include <opencv2/opencv.hpp>
#include <opencv2/dnn.hpp>
#include <iostream>
#include <string>
#include <fstream>
#include <QDebug>
#include <QThread>
#include <QMutex>
#include <QFile>
#include <QtAlgorithms>
//#include "darknet.h"
#include "Tool/GlobalParameter.h"
#include "yolox.h"

using namespace std;
using namespace cv;

//struct DetectResult
//{
//    vector<string> classNamesVec;
//    vector<cv::Rect> boxes;
//    vector<int> classNamesID;
//    vector<float> prob;
//};

class DetectorYoloGPU : public QThread
{
public:
    DetectorYoloGPU();
    ~DetectorYoloGPU();
    bool init();
    void close();
    void startDetect();
    void stopDetect();

    void setTheshold(float conf, float nms, int classesNum = 80);
    void detect(Mat& frame);
    void getDetectResult(DetectResult& res);

    void setMaxOutputNum(uint n); /// 20190807 wangzy only output n high prob targets
protected:
    void run();
private:
    void imgConvert(const cv::Mat& img, float* dst);
    bool checkFile(QString path);
private:
    GlobalParameter* g_param;
    bool m_bDetect;
    float m_confThreshold;
    float m_nmsThreshold;
    int m_classes_num;
    QString m_cfg_path;
    QString m_weight_path;
    QString m_name_path;

    //network* m_net;
    Mat m_rgb_img;
    //shared_ptr<image_t>  detImg; /// input yolo format
   // detection *m_dets;
    yolox* detector;

    DetectResult m_res;
    uint m_max_num; /// 20190807 wangzy
    QMutex m_mutex;
};

#endif // DETECTORYOLOGPU_H
