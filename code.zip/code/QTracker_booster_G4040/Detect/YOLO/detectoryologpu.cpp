#include "detectoryologpu.h"
#include <sys/time.h>
DetectorYoloGPU::DetectorYoloGPU()
{
    g_param = GlobalParameter::getInstance();
    m_bDetect = false;
    m_confThreshold = 0.3f;
    m_nmsThreshold = 0.2f;
    m_classes_num = 80;
    m_max_num = 1000;
    detector = NULL;

}

DetectorYoloGPU::~DetectorYoloGPU()
{
    close();
     qDebug()<<"DetectorYoloGPU is end";
}

bool DetectorYoloGPU::init()
{
/***
    m_cfg_path = "./cfg/detect.cfg";
    m_weight_path = "./cfg/detect.weights";
  //  m_cfg_path = "./cfg/yolov4.cfg";
   // m_weight_path = "./cfg/yolov4.weights";
    m_name_path = "./cfg/detect.names";

    if(!checkFile(m_cfg_path) || !checkFile(m_weight_path) || !checkFile(m_name_path))
    {
        return false;
    }
****/
    m_name_path = "./cfg/detect.names";
    ifstream classNamesFile(m_name_path.toLatin1().data());//标签文件coco有80类
    if (classNamesFile.is_open())
    {
        string className = "";
        while (getline(classNamesFile, className))
            m_res.classNamesVec.push_back(className);
    }
    //detector = new Detector(m_cfg_path.toLatin1().data(), m_weight_path.toLatin1().data(), 0);

    detector = new yolox("./cfg/yolox_s.onnx", 0.3, 0.6);
    //detector = new yolox("/home/pi/hdd/main/CAMERACONTROL/cfg/yolox_s.onnx", 0.6, 0.6);
    return true;
}

void DetectorYoloGPU::close()
{
    stopDetect();
    msleep(20);
 //   free_network(m_net);
    if(NULL != detector)
    {
        delete detector;
        detector = NULL;
    }

}

void DetectorYoloGPU::startDetect()
{
    if (m_bDetect == false)
    {
        m_bDetect = true;
        start(QThread::NormalPriority);
    }
}

void DetectorYoloGPU::stopDetect()
{
    m_bDetect = false;
}

void DetectorYoloGPU::setTheshold(float conf, float nms, int classesNum)
{
    if(conf >= 0)
    {
        m_confThreshold = conf;
    }
    if(nms >= 0)
    {
        m_nmsThreshold = nms;
    }
    if(classesNum > 0)
    {
        m_classes_num = classesNum;
    }
}

void DetectorYoloGPU::detect(Mat &frame)
{
    m_mutex.lock();

 //   struct timeval tv1,tv2;
 //   gettimeofday(&tv1, NULL);

    Mat frame_det = frame.clone();
    if(frame_det.empty())
    {
        qDebug() << "DetectorYoloGPU::detect frame_det.empty";
        return;
    }

//   detImg = detector->mat_to_image_resize(frame_det);
   vector<bbox_t> outs = detector->detect(frame_det);

     m_res.boxes.clear();
    m_res.classNamesID.clear();
    m_res.prob.clear();

    //qDebug()<<outs.size();

    for (int i = 0; i < outs.size(); i++)
    {

        int className;
        float prob;
        prob = outs[i].prob;
        if(prob < g_param->trackParam.detect_conf)
        {
            continue;
        }
            int left = outs[i].x;
            int right = (outs[i].x + outs[i].w);
            int top = outs[i].y;
            int bot = (outs[i].y + outs[i].h);
           // qDebug()<<left<<";"<<right<<";"<<top<<";"<<bot;

            if (left < 0)
                left = 0;
            if (right > frame.cols - 1)
                right = frame.cols - 1;
            if (top < 0)
                top = 0;
            if (bot > frame.rows - 1)
                bot = frame.rows - 1;


            className = outs[i].obj_id;

            if(g_param->trackParam.detect_type == 1)
            {
                m_res.boxes.push_back(Rect(left, top, fabs(left - right), fabs(top - bot)));
                m_res.classNamesID.push_back(className);
                m_res.prob.push_back(prob);
            }
            else if(g_param->trackParam.detect_type == 2)
            {
                if(className == 0)
                {
                    m_res.boxes.push_back(Rect(left, top, fabs(left - right), fabs(top - bot)));
                    m_res.classNamesID.push_back(className);
                    m_res.prob.push_back(prob);
                }
            }
            else if(g_param->trackParam.detect_type == 3)
            {
                if(className == 2 || className == 5 || className == 7)
                {
                    m_res.boxes.push_back(Rect(left, top, fabs(left - right), fabs(top - bot)));
                    m_res.classNamesID.push_back(className);
                    m_res.prob.push_back(prob);
                }
            }
            else if(g_param->trackParam.detect_type == 4)
            {
                if(className == 4 || className == 14 || className == 33)
                {
                    m_res.boxes.push_back(Rect(left, top, fabs(left - right), fabs(top - bot)));
                    m_res.classNamesID.push_back(className);
                    m_res.prob.push_back(prob);
                }
            }
            else if(g_param->trackParam.detect_type == 5)
            {
                if(className == 0 || className == 2 || className == 5 || className == 7 || className == 4 || className == 14 || className == 33)
                {
                    m_res.boxes.push_back(Rect(left, top, fabs(left - right), fabs(top - bot)));
                    m_res.classNamesID.push_back(className);
                    m_res.prob.push_back(prob);
                }
            }

    }

    /// sort by prob
    int count = m_res.prob.size();
    for(int i = 0; i < count - 1; i++)
    {
        for(int j = 0; j < count - 1 - i; ++j)
        {
            if(m_res.prob[j] < m_res.prob[j + 1])
            {
                float t_prob = 0;
                t_prob = m_res.prob[j];
                m_res.prob[j] = m_res.prob[j + 1];
                m_res.prob[j + 1] = t_prob;

                Rect t_box = Rect(0,0,0,0);
                t_box = m_res.boxes[j];
                m_res.boxes[j] = m_res.boxes[j + 1];
                m_res.boxes[j + 1] = t_box;

                int t_classNamesID = 0;
                t_classNamesID = m_res.classNamesID[j];
                m_res.classNamesID[j] = m_res.classNamesID[j + 1];
                m_res.classNamesID[j + 1] = t_classNamesID;
            }
        }
    }
    /// remove redundant data
    if(count > m_max_num)
    {
        m_res.boxes.erase(m_res.boxes.begin() + m_max_num, m_res.boxes.end());
        m_res.classNamesID.erase(m_res.classNamesID.begin() + m_max_num, m_res.classNamesID.end());
        m_res.prob.erase(m_res.prob.begin() + m_max_num, m_res.prob.end());
    }
    /// remove overlap
    count = m_res.boxes.size();
    QList<int> r_list;
    r_list.clear();
    for(int i = 0; i < count; i++)
    {
        for(int j = 0; j < count; j++)
        {
            if(i == j) continue;
            if( m_res.boxes[j].contains(Point(m_res.boxes[i].x, m_res.boxes[i].y)) &&
                    m_res.boxes[j].contains(Point(m_res.boxes[i].x + m_res.boxes[i].width, m_res.boxes[i].y + m_res.boxes[i].height)))
            {
                if(!r_list.contains(i))
                {
                    r_list.append(i);
                    break;
                }
            }
        }
    }
    qSort(r_list.begin(), r_list.end(), qGreater<int>());
    for(int i = 0; i < r_list.size(); i++)
    {
        m_res.boxes.erase(m_res.boxes.begin()+r_list.at(i));
        m_res.classNamesID.erase(m_res.classNamesID.begin()+r_list.at(i));
        m_res.prob.erase(m_res.prob.begin()+r_list.at(i));
    }
    /// sort by pos
    count = m_res.boxes.size();
    for(int i = 0; i < count - 1; i++)
    {
        for(int j = 0; j < count - 1 - i; ++j)
        {
            if(m_res.boxes[j].x > m_res.boxes[j + 1].x)
            {
                float t_prob = 0;
                t_prob = m_res.prob[j];
                m_res.prob[j] = m_res.prob[j + 1];
                m_res.prob[j + 1] = t_prob;

                Rect t_box = Rect(0,0,0,0);
                t_box = m_res.boxes[j];
                m_res.boxes[j] = m_res.boxes[j + 1];
                m_res.boxes[j + 1] = t_box;

                int t_classNamesID = 0;
                t_classNamesID = m_res.classNamesID[j];
                m_res.classNamesID[j] = m_res.classNamesID[j + 1];
                m_res.classNamesID[j + 1] = t_classNamesID;
            }
        }
    }
//    //结束计时
//    gettimeofday(&tv2, NULL);
//    //计算用时
//    long long T = (tv2.tv_sec - tv1.tv_sec) * 1000 + (tv2.tv_usec - tv1.tv_usec) / 1000;
//   // cout << T << "ms" <<endl;
    m_mutex.unlock();
}


void DetectorYoloGPU::getDetectResult(DetectResult &res)
{
    m_mutex.lock();
    res.boxes.clear();
    res.classNamesID.clear();
    res.prob.clear();
    res.classNamesVec.clear();

    res.classNamesID.assign(m_res.classNamesID.begin(), m_res.classNamesID.end());
    res.prob.assign(m_res.prob.begin(), m_res.prob.end());
    res.classNamesVec.assign(m_res.classNamesVec.begin(), m_res.classNamesVec.end());
    res.boxes.assign(m_res.boxes.begin(), m_res.boxes.end());
    m_mutex.unlock();
}

void DetectorYoloGPU::setMaxOutputNum(uint n)
{
    m_max_num = n;
}

void DetectorYoloGPU::run()
{
    double time_profile_counter = 0;
    Mat frame;
    while(m_bDetect == true)
    {
        time_profile_counter = cv::getCPUTickCount();
        if (g_param->imageDetectQueue.isEmpty())
        {
            msleep(1);
            continue;
        }
        frame = g_param->imageDetectQueue.dequeue();
        detect(frame);
        getDetectResult(g_param->yolo_res);
        time_profile_counter = cv::getCPUTickCount() - time_profile_counter;
        if(g_param->trackParam.state == DETECT)
        {
            frame.copyTo(g_param->imageDisplay);
        }
        //frame.copyTo(g_param->imageDisplay);
        //g_param->imageDisplayQueue.enqueue(frame);

        //g_param->debugParam.processFPS = 1000 * (cvGetTickFrequency() * 1000) / time_profile_counter;
    }
    stopDetect();
}

void DetectorYoloGPU::imgConvert(const Mat &img, float *dst)
{
    uchar *data = img.data;
    int h = img.rows;
    int w = img.cols;
    int c = img.channels();

    for(int k= 0; k < c; ++k)
    {
        for(int i = 0; i < h; ++i)
        {
            for(int j = 0; j < w; ++j)
            {
                dst[k*w*h+i*w+j] = data[(i*w + j)*c + k]/255.0;
            }
        }
    }
}



bool DetectorYoloGPU::checkFile(QString path)
{
    if(!QFile(path).exists())
    {
        qDebug() << path << " file load error!";
        return false;
    }
    else
    {
        return true;
    }
}

