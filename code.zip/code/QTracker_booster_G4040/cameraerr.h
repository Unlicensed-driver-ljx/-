#ifndef CAMERAERR_H
#define CAMERAERR_H

#include <QWidget>

namespace Ui {
class CameraErr;
}

class CameraErr : public QWidget
{
    Q_OBJECT

public:
    explicit CameraErr(QWidget *parent = nullptr);
    ~CameraErr();

private:
    Ui::CameraErr *ui;
};

#endif // CAMERAERR_H
