#ifndef FASTTRACK_H
#define FASTTRACK_H

#include <QObject>
#include <QThread>
#include <iostream>
#include <opencv2/tracking.hpp>
#include "Detect/YOLO/detectoryologpu.h"
#include "Tool/GlobalParameter.h"
#include <QtConcurrent>
#include <QFuture>


#include "Detect/detectortradition.h"

using namespace std;
class WorkerFasttrackThread;

enum TRACK_PRIORITY
{
    TRACKHIGH = 0, /// do nothing
    TRACKMID = 1, /// ����ʶ���׶�
    TRACKLOW = 2, /// �ջ�����
    TRACKIDLE = 3, /// ��������
};

class FastTrack : public QThread
{
    Q_OBJECT

public:
    FastTrack(QObject *parent = NULL);
    ~FastTrack();

    bool init();
    void close();
    void startTrack();
    void stopTrack();
    Point2f Centroid();
     void trackComSend();
     void continueTrack();
signals:
    void gaoSuTriggerSig();

private:
    void detect();
    void track();
    void trackTradition();
    void predict();

    void detectTradition();

    void manualIntervention();
    void checkTargetAvailable();
    void checkTrackGate();
    void computeCentriod();
    void changeTrackGate();

    void triggerConditon();
protected:
    void run();
private:
    GlobalParameter* g_param;
    bool m_bTrack;
    Mat m_frame;
    long m_loop_track;
    double m_thresh[2]; /// m_thresh[0]: lost ; m_thresh[1]: occlude
    int m_occlude_time; /// 20190717 wangzy
    int m_count_lost;
    int m_count_occlude;

    TrackerDaSiamRPN::Params params;
    cv::Ptr<Tracker>  m_tracker;

    //cv::TrackerKCF::Params paramskcf;

    //eco::ECO m_eco;
//    ECOTracker m_eco;
//    eco::EcoParameters m_parameters;
    DetectorTradition m_detTradition;

    DetectorYoloGPU m_yolo;
    DetectResult m_last_yolo_res;

    Mat m_roi_init; /// 20190823 wangzy

    //高速触发条件
    bool m_bCondition1;
    bool m_bCondition2;
    bool m_bCondition3;
    int m_triggerNum1;
    int m_triggerNum2;
    int m_triggerNum3;

    int m_autoTrackNum1;
    int m_autoTrackNum2;
    int m_autoTrackNum3;
    TRACK_PRIORITY m_trackPriority;
    WorkerFasttrackThread*      m_processThread;
    cv::Rect resultkcf;
    bool m_bkcfIsUpdate;

};



class WorkerFasttrackThread : public QThread
{
    Q_OBJECT
 public:
    WorkerFasttrackThread(FastTrack* fastTrack);
    ~WorkerFasttrackThread();
    void init();
    void stopProcess();
    bool m_bProcessing;
 protected:
    void run() Q_DECL_OVERRIDE;
private:
    FastTrack* m_pFastTrack;

};

#endif // FASTTRACK_H
