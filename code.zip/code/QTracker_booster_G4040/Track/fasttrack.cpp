#include "fasttrack.h"
#include <sys/time.h>
#include <QDebug>
FastTrack::FastTrack(QObject *parent)
    : QThread(parent)
{
    g_param = GlobalParameter::getInstance();
    m_bTrack = false;
    m_loop_track = 0;
    m_count_lost = 0;
    m_count_occlude = 0;

    m_thresh[0] = g_param->trackParam.thresh_lost;
    m_thresh[1] = g_param->trackParam.thresh_occlude;
    m_occlude_time = g_param->trackParam.occlude_time;

    m_tracker = NULL;

    m_bCondition1 = false;
    m_bCondition2 = false;
    m_bCondition3 = false;
    m_triggerNum1 = 0;
    m_triggerNum2 = 0;
    m_triggerNum3 = 0;

    m_autoTrackNum1 = 0;
    m_autoTrackNum2 = 0;
    m_autoTrackNum3 = 0;
    m_trackPriority = TRACKIDLE;
    m_processThread = new WorkerFasttrackThread(this);
    m_bkcfIsUpdate = true;
}

FastTrack::~FastTrack()
{
     m_processThread->stopProcess();
    close();
    quit();
    wait();
    deleteLater();
}

bool FastTrack::init()
{
    close();

    m_loop_track = 0;
    m_count_lost = 0;
    m_count_occlude = 0;

    /// kcf
    if(g_param->trackParam.use_scale == true)
    {
        qDebug() <<"Tracker is DasiamRPN";
        //m_tracker = new kcf::KCFTracker(true, true, true, true);
        std::string model = "./cfg/dasiamrpn_model.onnx";
        std::string kernel_r1 = "./cfg/dasiamrpn_kernel_r1.onnx";
        std::string kernel_cls1 = "./cfg/dasiamrpn_kernel_cls1.onnx";
        params.model = model;
        params.kernel_r1 = kernel_r1;
        params.kernel_cls1 = kernel_cls1;
        params.backend = dnn::DNN_BACKEND_CUDA;
        params.target = dnn::DNN_TARGET_CUDA;
        m_tracker = TrackerDaSiamRPN::create(params);
    }
    else
    {
        qDebug() <<"Tracker is KCF1";
        m_tracker = cv::TrackerKCF::create();
    }
    //m_tracker->setTrainThresh(g_param->trackParam.thresh_occlude);


    m_yolo.init();
    m_yolo.setTheshold(g_param->trackParam.thresh_conf, g_param->trackParam.thresh_nms);
    m_yolo.setMaxOutputNum(g_param->trackParam.detect_num);

    m_detTradition.setTheshold(g_param->trackParam.thresValueTrad);
    m_detTradition.setMaxOutputNum(g_param->trackParam.detect_num);

////    m_yolo.startDetect();
////    m_parameters.useDeepFeature = false;
////    m_parameters.useHogFeature = true;
////    m_parameters.useColorspaceFeature = false;
////    m_parameters.useCnFeature = true;
////    m_parameters.useIcFeature = true;
////    m_parameters.learning_rate = 0.01;
////    m_parameters.projection_reg = 5e-7;
////    m_parameters.init_CG_iter = 10 * 20;
////    m_parameters.CG_forgetting_rate = 60;
////    m_parameters.precond_reg_param = 0.2;
////    m_parameters.reg_window_edge = 4e-3;
//    m_parameters.search_area_scale = 3.5;
//    m_parameters.max_score_threshhold = g_param->trackParam.thresh_lost;
////    m_parameters.min_image_sample_size = 64*64;
//    m_parameters.use_scale_filter = false;
//    m_parameters.number_of_scales = 1;
//    m_parameters.scale_step = 1.01f;
//    m_parameters.useCnFeature = false;
//    m_parameters.cn_features.fparams.tablename = "/home/nvidia/wangzy/QTracker_boost/Track/eco/look_tables/CNnorm.txt";

    return true;
}

void FastTrack::close()
{
    stopTrack();
    //terminate();
    if(m_tracker != NULL)
    {
        delete m_tracker;
        m_tracker = NULL;
    }
}

void FastTrack::startTrack()
{
    if (m_bTrack == false)
    {
        m_bTrack = true;
        start(QThread::NormalPriority);
    }
}

void FastTrack::stopTrack()
{
    m_bTrack = false;
}

void FastTrack::detect()
{
    if(m_frame.empty() || m_frame.cols <=0 || m_frame.rows <= 0)
    {
        cout << "FastTrack::detect() error input frame" << endl;
        return;
    }

    m_yolo.detect(m_frame);
    m_yolo.getDetectResult(g_param->yolo_res);
    m_yolo.getDetectResult(m_last_yolo_res);
    g_param->debugParam.detectNum = g_param->yolo_res.boxes.size();

    /// score pos
    float max_conf = 0;
    for(size_t i = 0; i < g_param->yolo_res.prob.size();i++)
    {
        if(max_conf < g_param->yolo_res.prob[i])
        {
            max_conf = g_param->yolo_res.prob[i];
        }
    }
    g_param->trackParam.psr = max_conf;


    /// detect to track
    if(g_param->trackParam.bAutoDetect2Track == true)
    {
        Rect box;
        TRACK_PRIORITY curPriority = TRACKIDLE;
        bool bTrack = false;
        for(unsigned int ii = 0; ii <m_last_yolo_res.classNamesID.size();ii++)
        {
            int ObjIndex = m_last_yolo_res.classNamesID[ii];
            if(ObjIndex == g_param->trackParam.autoTrackIndex1)
            {
                m_autoTrackNum1 = m_autoTrackNum1+1;
                if(m_autoTrackNum1 > g_param->trackParam.autoTrackNum1-1)
                {
                    qDebug()<<"enter TrackNum1";
                    box = m_last_yolo_res.boxes[ii];
                    bTrack = true;
                    curPriority = TRACKHIGH;
                    break;
                }
            }
            else if(ObjIndex == g_param->trackParam.autoTrackIndex2)
            {
                m_autoTrackNum2 = m_autoTrackNum2+1;
                if(m_autoTrackNum2 > g_param->trackParam.autoTrackNum2-1)
                {
                    if(curPriority>TRACKMID)
                    {
                        box = m_last_yolo_res.boxes[ii];
                        bTrack = true;
                        curPriority = TRACKMID;
                       // break;
                    }
                }
            }
            else if(ObjIndex == g_param->trackParam.autoTrackIndex3)
            {
                m_autoTrackNum3 = m_autoTrackNum3+1;
                if(m_autoTrackNum3 > g_param->trackParam.autoTrackNum3-1)
                {
                    if(curPriority>TRACKLOW)
                    {
                        box = m_last_yolo_res.boxes[ii];
                        curPriority = TRACKLOW;
                        bTrack = true;
                       // break;
                    }
                }
            }
        }
       // <<"aaa";//


        if(bTrack)
        {
            //qDebug()<<"aaa:"<<QString::fromStdString(g_param->yolo_res.classNamesVec[ObjIndex]);

            if(g_param->trackParam.state == DETECT)
            {
                g_param->trackParam.trackGateRoi = box;
                g_param->trackParam.state = TRACK;
                g_param->debugParam.detectNum = 1;
                qDebug()<<"IF Condition"<<g_param->trackParam.trackGateRoi.width;
            }
            else if(g_param->trackParam.state == TRACK &&  curPriority< m_trackPriority)
            {
                m_loop_track = 0;
                g_param->trackParam.trackGateRoi = box;
                g_param->debugParam.detectNum = 1;
            }

            m_autoTrackNum1 = 0;
            m_autoTrackNum2 = 0;
            m_autoTrackNum3 = 0;
            m_trackPriority = curPriority;

            if(false == g_param->debugParam.bTrackAndDetect)
            {
                   g_param->yolo_res.boxes.clear();
                   g_param->yolo_res.classNamesID.clear();
                   g_param->yolo_res.classNamesVec.clear();
                   g_param->yolo_res.prob.clear();
            }

        }
    }
}

void FastTrack::track()
{
    /// choose method
    switch (g_param->trackParam.method)
    {
    case TRACK_KCF_HC:

        break;
    case TRACK_KCF:
        if (m_loop_track == 0)
        {
            /// 20190823 wangzy
            qDebug()<< "aaaaaa"<<g_param->trackParam.trackGateRoi.x<<"y"<<g_param->trackParam.trackGateRoi.y
                    <<"w:"<<g_param->trackParam.trackGateRoi.width<<"h"<<g_param->trackParam.trackGateRoi.height;
            if(g_param->trackParam.use_scale == false)
            {
                qDebug()<<"Tracker is KCF";
                m_tracker = cv::TrackerKCF::create();

            }
            m_tracker->init(m_frame, g_param->trackParam.trackGateRoi);
            qDebug()<<"++++++++++++++++++1";
 /****
            if(m_tracker->init(m_frame, g_param->trackParam.trackGateRoi) == true)
            {
                m_roi_init = m_frame(g_param->trackParam.trackGateRoi);
                qDebug()<<"Init"<<g_param->trackParam.trackGateRoi.width;
                qDebug()<<"KCF is Initial";
            }
            else
            {
                g_param->trackParam.state = DETECT;
                m_processThread->stopProcess();
                m_bkcfIsUpdate = true;
                cout << "track init error, try again" << endl;
            }
  ****/
        }
        else
        {
            if(m_bkcfIsUpdate)
            {   Rect recttemp;
                //g_param->trackParam.trackGateRoi = m_tracker->update(m_frame);  //kcf
                //m_tracker->update(m_frame,g_param->trackParam.trackGateRoi);     //dasiamrpn
                m_tracker->update(m_frame,recttemp);
                g_param->trackParam.trackGateRoi=recttemp;
                //g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
                //g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
                //trackComSend(m_frame,g_param->trackParam.trackGateRoi);
                //resultkcf = g_param->trackParam.trackGateRoi;
            }

            //trackComSend();
                if(false == m_processThread->m_bProcessing)
                {
                    m_processThread->init();
                }

        }
        break;
    case TRACK_ECO_HC:
//        if (m_loop_track == 0)
//        {
//            /// must be init
//            m_eco.init(m_frame, g_param->trackParam.trackGateRoi, m_parameters);
//        }
//        else
//        {
//            g_param->trackParam.trackGateRoi = m_eco.update(m_frame);
//            g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
//            g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
//        }
        break;
    default:
        break;
    }
    switch (g_param->trackParam.modeValueTradition) {
    case 0:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        break;
    case 1:
        g_param->trackParam.objPosPix.x = Centroid().x;
        g_param->trackParam.objPosPix.y = Centroid().y;
        break;
    case 2:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y;
        break;
    case 3:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height;
        break;
    case 4:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        break;
    case 5:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        break;
    case 6:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x ;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y ;
        break;
    case 7:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height;
        break;
    case 8:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y;
        break;
    case 9:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height;
        break;
    default:
        g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
        g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
        break;
    }
    resultkcf = g_param->trackParam.trackGateRoi;
}

void FastTrack::trackTradition()
{

  //  qDebug()<<"Enter Track x:" <<g_param->trackParam.trackGateRoi.x << "y:" <<g_param->trackParam.trackGateRoi.y <<"w:" <<g_param->trackParam.trackGateRoi.width << "h:" <<g_param->trackParam.trackGateRoi.height;
    int xx = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width/2;
    int yy = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height/2;
    double dis = 100000000;
    int trackIndex = -1;

    //传统跟踪,寻求最近连通域
    m_detTradition.setTheshold(g_param->trackParam.thresValueTrad,g_param->trackParam.minSizeTrad);
    m_detTradition.detect(m_frame);
    m_detTradition.getDetectResult(m_last_yolo_res);

    if(m_last_yolo_res.boxes.size() == 0) //find failed
    {
        g_param->trackParam.state = DETECT;
    }

    if(m_last_yolo_res.boxes.size() > 0)
    {
        for(size_t i = 0; i < m_last_yolo_res.boxes.size();i++)
        {
            //if(m_last_yolo_res.boxes[i].contains(cv::Point(xx,yy)))
            //{
                double xk = m_last_yolo_res.boxes[i].x + m_last_yolo_res.boxes[i].width/2;
                double yk = m_last_yolo_res.boxes[i].y + m_last_yolo_res.boxes[i].height/2;
                double disXK = (xk-xx)*(xk-xx) + (yk-yy)*(yk-yy);
                //int prob = m_last_yolo_res.prob[i];
                //qDebug()<<"g_param->threstradV---------------------------"<<g_param->threstradV;
                //qDebug()<<"m_last_yolo_res.prob[i]"<<m_last_yolo_res.prob[0];
                if(disXK < dis)
                {
                    dis = disXK;
                    trackIndex = i;
                }
                //qDebug()<<"disXK"<<disXK;

            //}
        }
//        if(dis > 80000)
//        {
//            trackIndex = -1;
//        }
        //qDebug()<<"trackIndex" <<trackIndex;
        if(-1 == trackIndex) //find failed
        {
            g_param->trackParam.state = DETECT;
        }
        else
        {
            g_param->trackParam.trackGateRoi  = m_last_yolo_res.boxes[trackIndex];
            switch (g_param->trackParam.modeValueTradition) {
            case 0:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
                break;
            case 1:
                g_param->trackParam.objPosPix.x = Centroid().x;
                g_param->trackParam.objPosPix.y = Centroid().y;
                break;
            case 2:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y;
                break;
            case 3:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height;
                break;
            case 4:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
                break;
            case 5:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
                break;
            case 6:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x ;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y ;
                break;
            case 7:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height;
                break;
            case 8:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y;
                break;
            case 9:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height;
                break;
            default:
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
                break;
            }
            resultkcf = g_param->trackParam.trackGateRoi;
            //qDebug()<<"Tradition Track:"<< g_param->trackParam.objPosPix.x <<"y:" <<g_param->trackParam.objPosPix.y;
        }
    }

//        if(m_bkcfIsUpdate)
//        {
//            g_param->trackParam.trackGateRoi = m_tracker->update(m_frame);
//            g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
//            g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
//            //trackComSend(m_frame,g_param->trackParam.trackGateRoi);
//            resultkcf = g_param->trackParam.trackGateRoi;
//        }

//        //trackComSend();
//            if(false == m_processThread->m_bProcessing)
//            {
//                m_processThread->init();
//            }

}

Point2f FastTrack::Centroid()
{
    vector<Moments> mu(1);
    vector<Point2f> mc(1);
    int Centroid_x = g_param->trackParam.trackGateRoi.x;
    int Centroid_y = g_param->trackParam.trackGateRoi.y;
    int Centroid_w = g_param->trackParam.trackGateRoi.width;
    int Centroid_h = g_param->trackParam.trackGateRoi.height;
    if(Centroid_x<0) Centroid_x = 0;
    if(Centroid_y<0) Centroid_y = 0;
    int temA = (Centroid_y+Centroid_h)> m_frame.size().height-1?(m_frame.size().height-1):(Centroid_y+Centroid_h);
    int temB = (Centroid_x+Centroid_w)> m_frame.size().width-1?(m_frame.size().width-1):(Centroid_x+Centroid_w);
    cv::Mat ROI = m_frame(cv::Range(Centroid_y,temA),cv::Range(Centroid_x,temB));
    cv::Mat ROI1;
    if(ROI.empty())
    {
        return Point2d(0,0);
    }
    cv::cvtColor(ROI, ROI, cv::COLOR_BGR2GRAY);
    if(g_param->trackParam.bTrackTradition == false)
    {
        g_param->threstradV = threshold(ROI,ROI1,0,255,THRESH_OTSU);
    }
    threshold(ROI,ROI,g_param->threstradV,255,THRESH_TOZERO);
    mu[0] = moments(ROI,false);
    mc[0] = Point2d(mu[0].m10/mu[0].m00+Centroid_x,mu[0].m01/mu[0].m00+Centroid_y);
//    qDebug()<<"Centroid().x"<<mc[0].x;
//    qDebug()<<"Centroid().y"<<mc[0].y;
    return mc[0];
}
void FastTrack::predict()
{

}

void FastTrack::detectTradition()
{
    if(m_frame.empty() || m_frame.cols <=0 || m_frame.rows <= 0)
    {
        cout << "FastTrack::detect() error input frame" << endl;
        return;
    }
    m_detTradition.setTheshold(g_param->trackParam.thresValueTrad,g_param->trackParam.minSizeTrad);
    m_detTradition.detect(m_frame);
    m_detTradition.getDetectResult(g_param->yolo_res);
    m_detTradition.getDetectResult(m_last_yolo_res);
    g_param->debugParam.detectNum = g_param->yolo_res.boxes.size();

    if(g_param->trackParam.bAutoDetect2Track == true)
    {
        Rect box;
        if(m_last_yolo_res.boxes.size()>0)
        {
            box = m_last_yolo_res.boxes[0];
            if(g_param->trackParam.state == DETECT)
            {
                g_param->trackParam.trackGateRoi = box;
                g_param->trackParam.state = TRACK;
                m_loop_track = 0;
                g_param->debugParam.detectNum = 1;
                qDebug()<<"Track Tradition Auto";
                g_param->yolo_res.boxes.clear();

               // g_param->trackParam.bAutoDetect2Track = false;
            }
        }
    }

}

void FastTrack::manualIntervention()
{
    /// 响应操作指令，优先级最高
    if (g_param->trackParam.bManualSelect == true)
    {
        g_param->trackParam.bManualSelect = false; /// 状态复位
        bool bFind = false;


        if(m_last_yolo_res.boxes.size() > 0)
        {
            for(size_t i = 0; i < m_last_yolo_res.boxes.size();i++)
            {
                if(m_last_yolo_res.boxes[i].contains(g_param->displayParam.mouseClickPos))
                {
                    g_param->trackParam.trackGateRoi = m_last_yolo_res.boxes[i];
                    /// 20190726 wangzy
                    if(g_param->trackParam.trackGateRoi.width > g_param->trackParam.trackGateSize.width)
                    {
                        g_param->trackParam.trackGateRoi.width = g_param->trackParam.trackGateSize.width;
                        g_param->trackParam.trackGateRoi.x = g_param->displayParam.mouseClickPos.x - g_param->trackParam.trackGateRoi.width / 2;
                    }
                    if(g_param->trackParam.trackGateRoi.height > g_param->trackParam.trackGateSize.height)
                    {
                        g_param->trackParam.trackGateRoi.height = g_param->trackParam.trackGateSize.height;
                        g_param->trackParam.trackGateRoi.y = g_param->displayParam.mouseClickPos.y - g_param->trackParam.trackGateRoi.height / 2;
                    }
                    bFind = true;
                    break;
                }
            }
        }
        qDebug()<< "bFind = " << bFind;
        if(bFind == false)
        {
            g_param->trackParam.objPosPix = g_param->displayParam.mouseClickPos; /// 目标位置直接更新
            g_param->trackParam.trackGateSize.width  = g_param->trackParam.trackGateSize.width>256?256:g_param->trackParam.trackGateSize.width;
            g_param->trackParam.trackGateSize.height = g_param->trackParam.trackGateSize.height>256?256:g_param->trackParam.trackGateSize.height;
            if(g_param->pccontrolparam.TrackGateSize == 0)
            {
                g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2;
                g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2;
            }
            else
            {
                switch(g_param->pccontrolparam.GatePositionTurn)
                {
                case 1:
                    g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2 + g_param->controlParam.GatePositionVariableStep;
                    g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2;
                    break;
                case 2:
                    g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2 - g_param->controlParam.GatePositionVariableStep;
                    g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2;
                    break;
                case 3:
                    g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2;
                    g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2 + g_param->controlParam.GatePositionVariableStep;
                    break;
                case 4:
                    g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2;
                    g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2 - g_param->controlParam.GatePositionVariableStep;
                    break;
                default:
                    g_param->trackParam.trackGateRoi.x = g_param->trackParam.objPosPix.x - g_param->trackParam.trackGateSize.width / 2;
                    g_param->trackParam.trackGateRoi.y = g_param->trackParam.objPosPix.y - g_param->trackParam.trackGateSize.height / 2;
                }
                g_param->pccontrolparam.TrackGateSize = 0;
            }
            g_param->trackParam.trackGateRoi.width = g_param->trackParam.trackGateSize.width; /// default
            g_param->trackParam.trackGateRoi.height = g_param->trackParam.trackGateSize.height;

        }

        checkTrackGate();
        qDebug() << "enter manual intervention";
        g_param->trackParam.state = TRACK;
        g_param->debugParam.detectNum = 1;
        //g_param->debugParam.avgProcessTime = 0;
        //g_param->debugParam.inputCount = 0;
        //g_param->debugParam.processCount = 0;
        m_loop_track = 0;
        m_count_lost = 0;
        m_count_occlude = 0;

        m_last_yolo_res.boxes.clear();
        m_last_yolo_res.classNamesID.clear();
        m_last_yolo_res.classNamesVec.clear();
        m_last_yolo_res.prob.clear();

        g_param->yolo_res.boxes.clear();
        g_param->yolo_res.classNamesID.clear();
        g_param->yolo_res.classNamesVec.clear();
        g_param->yolo_res.prob.clear();

     //   qDebug()<<"x:" <<g_param->trackParam.trackGateRoi.x << "y:" <<g_param->trackParam.trackGateRoi.y <<"w:" <<g_param->trackParam.trackGateRoi.width << "h:" <<g_param->trackParam.trackGateRoi.height;

//        m_eco.reset(); /// 20190722 wangzy
    }
}

void FastTrack::checkTargetAvailable()
{
    double psr = 1.0;
    switch (g_param->trackParam.method)
    {
    case TRACK_KCF_HC:

        break;
    case TRACK_KCF:
        //psr = m_tracker->getPSR();
        //psr = m_tracker->getPeakValue();
      //  psr = m_tracker->getTrackingScore();
         // m_tracker->dynamicCast<TrackerDaSiamRPN>->getTrackingScore();
         if(g_param->trackParam.use_scale == true)
         {
             Ptr<TrackerDaSiamRPN> aa =  m_tracker.dynamicCast<TrackerDaSiamRPN>();
             psr =  aa->getTrackingScore();
             //qDebug()<<"aaa:"<<psr;
         }
      break;
    case TRACK_ECO_HC:
//        psr = m_eco.getScore();
    default:
        break;
    }

    g_param->trackParam.psr = psr;
    if(false == m_bkcfIsUpdate)
    {
        return;
    }

    //cout << "PSR : " << psr << endl;
    if(psr < g_param->trackParam.thresh_lost)
    {
        qDebug()  << m_count_lost <<" someone has blind my eyes, low score:" << psr <<  endl;
        /// lost
        m_count_lost++;
        if(m_count_lost >= 3)
        {
            g_param->trackstatu = 3;
            /// target lost
            if(3 == g_param->servoXXTParam.guideMode)
            {
                QTimer::singleShot(g_param->trackParam.occlude_time*1000,this,&FastTrack::continueTrack);
                m_bkcfIsUpdate = false;
                g_param->trackParam.objPosPix.x = m_frame.size().width/2;
                g_param->trackParam.objPosPix.y = m_frame.size().height/2;
            }
            else
            {
                g_param->trackParam.state = DETECT;
                m_processThread->stopProcess();
            }
             m_count_lost = 0;
             qDebug() << "target lost, score:" << psr << endl;
        }

    }
    else if(psr < g_param->trackParam.thresh_occlude)
    {
        qDebug()  << m_count_occlude << " someone has covered my eyes, low score:" << psr << endl;
        ///occlusion
        m_count_occlude++;
        if(m_count_occlude >= g_param->trackParam.occlude_time*25)
        {
            g_param->trackstatu = 3;
            /// target occlusion
            g_param->trackParam.state = DETECT;
            m_processThread->stopProcess();
              m_bkcfIsUpdate = true;
            m_count_occlude = 0;
            qDebug()  << "target occluded, score:" << psr << endl;
        }
    }
    else
    {

        /// continue recording
        m_count_lost -= 1;
        m_count_occlude -= 1;
        if(m_count_lost < 0 && m_count_occlude < 0)
        {
            g_param->trackstatu = 1;
        }
        if(m_count_lost < 0)
        {
            m_count_lost = 0;
        }
        else
        {
            g_param->trackstatu = 2;
        }
        if(m_count_occlude < 0)
        {
            m_count_occlude = 0;

        }
        else
        {
            g_param->trackstatu = 2;
        }


    }


}

void FastTrack::checkTrackGate()
{
    Rect2d& gate = g_param->trackParam.trackGateRoi;
    //Rect2d gate = g_param->trackParam.trackGateRoi;
    if(gate.width <= 0)
    {
        gate.width = g_param->trackParam.trackGateSize.width;
    }
    if(gate.height <= 0)
    {
        gate.height = g_param->trackParam.trackGateSize.height;
    }

    if(gate.width > g_param->trackParam.trackGateSize.width)
    {
        gate.x += (gate.width - g_param->trackParam.trackGateSize.width) / 2;
        gate.width = g_param->trackParam.trackGateSize.width;
    }
    if(gate.height > g_param->trackParam.trackGateSize.height)
    {
        gate.y += (gate.height - g_param->trackParam.trackGateSize.height) / 2;
        gate.height = g_param->trackParam.trackGateSize.height;
    }


    if(gate.x < 0)
    {
        gate.x = 1;
    }
    if(gate.y < 0)
    {
        gate.y = 1;
    }

    if(gate.x + gate.width > m_frame.cols)
    {
       // gate.x = g_param->displayParam.imgSize.width - gate.width - 1;
        gate.width = m_frame.cols - gate.x - 5;
    }
    if(gate.y + gate.height > m_frame.rows)
    {
        //gate.y = g_param->displayParam.imgSize.height - gate.height - 1;
        gate.height = m_frame.rows - gate.y - 5;
    }
}

void FastTrack::computeCentriod()
{
    if(g_param->trackParam.state == TRACK)
    {
        Mat roi = m_frame(g_param->trackParam.searchGateRoi).clone();
        /// do filter
        medianBlur(roi, roi, 3);
        /// compute mean

        /// compute centriod
        /// Moment
    }

}

void FastTrack::changeTrackGate()
{
    if(g_param->trackParam.bChangeTrackGateSize == true)
    {
        g_param->trackParam.bChangeTrackGateSize = false;
        /// value changed in io thread
        if(g_param->trackParam.state == TRACK)
        {
           g_param->displayParam.mouseClickPos = g_param->trackParam.objPosPix;
           g_param->trackParam.bManualSelect = true;
        }
    }
}

void FastTrack::run()
{
    double time_profile_counter = 0;
    int avgNum = 0;
    double totalFrame = 0;
    while(true == m_bTrack)
    {

        /// 获取原始图像
        if(g_param->displayParam.imgSource == VISUAL)
        {
            if (g_param->imageProcessQueue_VS.isEmpty())
            {
                msleep(1);
                continue;
            }
            if(g_param->trackParam.bBlackDetect)
            {
                Mat kkTemp;
                g_param->imageProcessQueue_VS.dequeue().copyTo(kkTemp);
                cvtColor(kkTemp,m_frame,cv::COLOR_BGR2GRAY);
            }
            else
            {
                g_param->imageProcessQueue_VS.dequeue().copyTo(m_frame);
            }
        }
        else if(g_param->displayParam.imgSource == IR)
        {
            if (g_param->imageProcessQueue_IR.isEmpty())
            {
                msleep(1);
                continue;
            }

            if(g_param->trackParam.bBlackDetect)
            {
                Mat kkTemp;
                g_param->imageProcessQueue_IR.dequeue().copyTo(kkTemp);
                cvtColor(kkTemp,m_frame,cv::COLOR_BGR2GRAY);
            }
            else
            {
                g_param->imageProcessQueue_IR.dequeue().copyTo(m_frame);
            }
        }

//        else if(g_param->displayParam.imgSource == IR1)
//        {
//            if (g_param->imageProcessQueue_IR1.isEmpty())
//            {
//                msleep(1);
//                continue;
//            }

//            if(g_param->trackParam.bBlackDetect)
//            {
//                Mat kkTemp;
//                g_param->imageProcessQueue_IR1.dequeue().copyTo(kkTemp);
//                cvtColor(kkTemp,m_frame,cv::COLOR_BGR2GRAY);
//            }
//            else
//            {
//                g_param->imageProcessQueue_IR1.dequeue().copyTo(m_frame);
//            }
//        }
//        else
//        {
//            if (g_param->imageProcessQueue_IR2.isEmpty())
//            {
//                msleep(1);
//                continue;
//            }

//            if(g_param->trackParam.bBlackDetect)
//            {
//                Mat kkTemp;
//                g_param->imageProcessQueue_IR2.dequeue().copyTo(kkTemp);
//                cvtColor(kkTemp,m_frame,cv::COLOR_BGR2GRAY);
//            }
//            else
//            {
//                g_param->imageProcessQueue_IR2.dequeue().copyTo(m_frame);
//            }
//        }

        if (m_frame.empty() || m_frame.cols <= 0 || m_frame.rows <= 0)
        {
            qDebug() << "FastTracker::run() m_frame size error" << endl;
            continue;
        }


        if(g_param->detect_flag == true)
        {
            if(1 == g_param->servoXXTParam.guideMode)
            {
                time_profile_counter = cv::getTickCount();
                 changeTrackGate();
                 manualIntervention();
                // qDebug()<<"current state:"<<g_param->trackParam.state;
                 QFuture<void> res;
                 switch (g_param->trackParam.state)
                 {
                 case IDLE:
                     break;
                 case DETECT:
                      m_processThread->stopProcess();
                      m_bkcfIsUpdate = true;
                      detectTradition();
                      m_loop_track = 0;
                     break;
                 case TRACK:
                     if(g_param->trackParam.bTrackTradition)
                     {
                         trackTradition();
                     }
                     else
                     {
                          track();
                          if(m_loop_track > 3) /// 20190726 wangzy fixed fist frames score equal 0
                          {
                              checkTargetAvailable();
                          }
                          m_loop_track++;
                     }
                     break;
                 case PREDICT:
                     predict();
                     break;
                }
                 time_profile_counter = cv::getTickCount() - time_profile_counter;
                 totalFrame = totalFrame +  cv::getTickFrequency()/ time_profile_counter;
                 avgNum = avgNum + 1;
                 if(avgNum == 100)
                 {
                     g_param->debugParam.processFPS = totalFrame/100.0;
                     avgNum = 0;
                     totalFrame = 0;
                 }

                // g_param->debugParam.processFPS = cv::getTickFrequency()/ time_profile_counter;

                 if(TRACK == g_param->trackParam.state)
                 {
                     //g_param->debugParam.processFPS = g_param->servoXXTParam.captureFPS;
                     g_param->debugParam.processFPS = QString::number(g_param->camerafps,'f',2).toFloat();
                 }
            }
            else
            {
                changeTrackGate(); /// 20191026 wangzy

                manualIntervention();

                time_profile_counter = cv::getTickCount();
                QFuture<void> res;
                /// 各阶段逻辑
                switch (g_param->trackParam.state)
                {
                case IDLE:
                    break;
                case DETECT:
                     m_processThread->stopProcess();
                     m_bkcfIsUpdate = true;
                       detect();
                   // detectTradition();
                    if(g_param->trackParam.bTriggerEnable)
                    {
                         triggerConditon();
                    }
                    else
                    {
                        m_bCondition1 = false;
                        m_bCondition2 = false;
                        m_bCondition3 = false;
                        m_triggerNum1 = 0;
                        m_triggerNum2 = 0;
                        m_triggerNum3 = 0;
                    }

                    m_loop_track = 0;
                    break;
                case TRACK:
                    if(g_param->debugParam.bTrackAndDetect)
                    {
                        res = QtConcurrent::run(this,&FastTrack::detect);
                    }

                    track();
                    // detect();
                    /// if target available
                    if(m_loop_track > 3) /// 20190726 wangzy fixed fist frames score equal 0
                    {
                        checkTargetAvailable();
                    }
                    m_loop_track++;

                     if(g_param->debugParam.bTrackAndDetect)
                     {
                         if(!res.isFinished())
                         {
                             res.waitForFinished();
                         }
                         qDebug()<<"resFinished";
                     }

                    break;
                case PREDICT:
                    predict();
                    break;
                }
                checkTrackGate();
                //computeCentriod();
                /// pos
                g_param->trackParam.objPosPix.x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2;
                g_param->trackParam.objPosPix.y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;
                g_param->debugParam.processCount++;

        //        if(g_param->trackParam.state != DETECT)
        //        {
        //            m_frame.copyTo(g_param->imageDisplay);
        //        }
        //        m_frame.copyTo(g_param->imageDisplay);

                time_profile_counter = cv::getTickCount() - time_profile_counter;

                totalFrame = totalFrame +  cv::getTickFrequency()/ time_profile_counter;
                avgNum = avgNum + 1;
                if(avgNum == 100)
                {
                    g_param->debugParam.processFPS = totalFrame/100.0;
                    avgNum = 0;
                    totalFrame = 0;
                }

               // g_param->debugParam.processFPS = cv::getTickFrequency()/ time_profile_counter;
                if(TRACK == g_param->trackParam.state)
                {
                    //g_param->debugParam.processFPS = g_param->servoXXTParam.captureFPS;
                    g_param->debugParam.processFPS = QString::number(g_param->camerafps,'f',2).toFloat();
                }
            }
        }

    }
}

void FastTrack::trackComSend()
{
    /*float delt_x = 0.0;
       float delt_y = 0.0;
       cv::Moments Moments;
       unsigned  char T_sendData[16] = {0};
       T_sendData[0] = 0x43;
       T_sendData[1] = 0xAE;
       T_sendData[2] = g_param->servoXXTParam.trackMode;
       T_sendData[3] = qAtan(1.0944/g_param->servoXXTParam.focusValue)*1800/3.1415926;
       T_sendData[15] = 0x63;
       float m_focusValue = g_param->servoXXTParam.focusValue;
       float m_pixelSize = 0.0038; //pixelSize
       //different Camera
           switch (g_param->displayParam.imgSource) {
           case VISUAL: //720*576
                m_pixelSize = 0.007125;
                m_focusValue = g_param->servoXXTParam.focusValue;
                T_sendData[3] = qAtan(2.052/m_focusValue)*1800/3.1415926;
               break;
           case IR:  //LIR  640*512  17um
               m_pixelSize = 0.017;
               m_focusValue = g_param->servoXXTParam.LIRfocusValue;
               T_sendData[3] = qAtan(4.352/m_focusValue)*1800/3.1415926;
               break;
           default:
               break;
           }


       int tempA,tempB;
       //KCF Tracking

           int result_x = resultkcf.x;
           int result_y = resultkcf.y;
           int result_w = resultkcf.width;
           int result_h = resultkcf.height;
           if(result_x<0) result_x = 0;
           if(result_y<0) result_y = 0;
           tempA = (result_y+result_h)> m_frame.size().height-1?(m_frame.size().height-1):(result_y+result_h);
           tempB = (result_x+result_w)> m_frame.size().width-1?(m_frame.size().width-1):(result_x+result_w);
           cv::Mat roi = m_frame(cv::Range(result_y,tempA),cv::Range(result_x,tempB));
           if(roi.empty())
           {
               return;
           }
           cv::cvtColor(roi, roi, cv::COLOR_BGR2GRAY);
           Moments = cv::moments(roi,false);
           float pos_x = (float)Moments.m10 / (float)Moments.m00;
           float pos_y = (float)Moments.m01 / (float)Moments.m00;

           pos_x = result_x+pos_x;
           pos_y = result_y+pos_y;

           pos_x = g_param->trackParam.objPosPix.x;
           pos_y = g_param->trackParam.objPosPix.y;
          //qDebug()<<"pos_x:"<<pos_x<<"E:"<<pos_y;

           g_param->trackParam.objCenterPix.x = pos_x;
           g_param->trackParam.objCenterPix.y = pos_y;


           //int m_focusValue = 50;  //For Test

           delt_x =  pos_x - m_frame.size().width/2 ;
           delt_y =  m_frame.size().height/2 - pos_y;

           g_param->servoXXTParam.trackTuobaX = delt_x;
           g_param->servoXXTParam.trackTuobaY = delt_y;
          float tuobaX;

          double xPixelSize;
          if(VISUAL == g_param->displayParam.imgSource)
              xPixelSize = m_pixelSize*1.3333333;
          else
              xPixelSize = m_pixelSize;

          if(delt_x > 0)
          {
              tuobaX = qAtan(xPixelSize*delt_x/m_focusValue)*206264.806247;
          }
          else
          {
             tuobaX =  -qAtan(xPixelSize*abs(delt_x)/m_focusValue)*206264.806247;
          }

         if(false == m_bkcfIsUpdate)
         {
             tuobaX = 0;
         }
          int startInt = tuobaX;
         // qDebug() << "A_Pixel: " << tuobaX/3600 << endl;
          T_sendData[4] = (startInt>>24)%256;
          T_sendData[7] = startInt%256;
          T_sendData[6] = (startInt>>8)%256;
          T_sendData[5] = (startInt>>16)%256;
          float tuobaY;


          if(delt_y > 0)
          {
              tuobaY = qAtan(m_pixelSize*delt_y/m_focusValue)*206264.806247;
          }
          else
          {
              tuobaY =  -qAtan(m_pixelSize*abs(delt_y)/m_focusValue)*206264.806247;
          }

          if(false == m_bkcfIsUpdate)
          {
              tuobaY = 0;
          }

          startInt = tuobaY;
         // qDebug() << "E_Pixel: " << tuobaY/3600 << endl;
          T_sendData[8] = (startInt>>24)%256;
          T_sendData[11] = startInt%256;
          T_sendData[10] = (startInt>>8)%256;
          T_sendData[9] = (startInt>>16)%256;


          g_param->servoXXTParam.trackTuobaX = delt_x;
          g_param->servoXXTParam.trackTuobaY = delt_y;
          g_param->servoXXTParam.trackTuobaA = tuobaX;
          g_param->servoXXTParam.trackTuobaE = tuobaY;


   //      static struct timeval tv2,tv1;
   //      gettimeofday(&tv2, NULL);
   //      long long T = (tv2.tv_sec - tv1.tv_sec) * 1000 + (tv2.tv_usec - tv1.tv_usec) / 1000;
   //      tv1 = tv2;
   //       qDebug()<<T<<"A:"<<tuobaX<<"E:"<<tuobaY;
          //Send Acuqier Image Time Stamp
          T_sendData[12] = g_param->servoXXTParam.timeStampAcquire;
          //T_sendData[13] = (unsigned char)Area;
               //End Send Area value
          T_sendData[14] = T_sendData[0] + T_sendData[1] + T_sendData[2] + T_sendData[3]+ T_sendData[4]+ T_sendData[5]+ T_sendData[6]
               +T_sendData[7] + T_sendData[8] + T_sendData[9] + T_sendData[10]+ T_sendData[11] + T_sendData[12] + T_sendData[13];

       //KCF Delt x and y Send
       if(NULL != m_t210com && g_param-> trackParam.bSendServer)
       {
           m_t210com->sendCommand(T_sendData);
       }*/

}

void FastTrack::continueTrack()
{
    /*//g_param->trackParam.state = DETECT;
    m_processThread->stopProcess();
    if(NULL !=m_t210com)
    {
        m_t210com->stop210();
         QTimer::singleShot(100,m_t210com,&T210Com::secondStop210);
    }
    m_count_lost = 0;
    m_bkcfIsUpdate = true;
    qDebug()<<"enter contiuneTrack";*/
}

void FastTrack::triggerConditon()
{
    for(unsigned int ii = 0; ii <m_last_yolo_res.classNamesID.size();ii++)
    {
        int ObjIndex = m_last_yolo_res.classNamesID[ii];
        if(ObjIndex == g_param->trackParam.triggerIndex1)
        {
            m_triggerNum1 = m_triggerNum1+1;
        }

        if(ObjIndex == g_param->trackParam.triggerIndex2)
        {
            m_triggerNum2 = m_triggerNum2+1;
        }

        if(ObjIndex == g_param->trackParam.triggerIndex3)
        {
            m_triggerNum3 = m_triggerNum3+1;
        }

        if(m_triggerNum1 > g_param->trackParam.triggerNum1)
        {
            m_bCondition1 = true;
        }

        if(m_triggerNum2 > g_param->trackParam.triggerNum2)
        {
            m_bCondition2 = true;
        }

        if(m_triggerNum3 > g_param->trackParam.triggerNum3)
        {
            m_bCondition3 = true;
        }
    }

    bool bConditon = false;
    switch (g_param->trackParam.triggerRelation) {
     case 0:
          bConditon = m_bCondition1 || m_bCondition2 || m_bCondition3;
        break;
    case 1:
          bConditon = (m_bCondition1 && m_bCondition2) || m_bCondition3;
      break;
    case 2:
          bConditon = (m_bCondition1 || m_bCondition2) && m_bCondition3;
      break;
    case 3:
          bConditon =  m_bCondition1 && m_bCondition2 && m_bCondition3;
      break;
    default:
       break;
    }
    if(bConditon)
    {
        bConditon = false;
        m_bCondition1 = false;
        m_bCondition2 = false;
        m_bCondition3 = false;
        m_triggerNum1 = 0;
        m_triggerNum2 = 0;
        m_triggerNum3 = 0;
        emit gaoSuTriggerSig();
        qDebug()<<"gaoSuTriggerSig is emit";
    }
}

WorkerFasttrackThread::WorkerFasttrackThread(FastTrack* fastTrack)
{
    m_pFastTrack = fastTrack;
    m_bProcessing = false;
}

WorkerFasttrackThread::~WorkerFasttrackThread()
{
    stopProcess();
    msleep(10);
}

void WorkerFasttrackThread::init()
{
    m_bProcessing = true;
    start();
}

void WorkerFasttrackThread::stopProcess()
{
    m_bProcessing = false;
}

void WorkerFasttrackThread::run()
{
    while(m_bProcessing)
    {
       m_pFastTrack->trackComSend();
       msleep(33);
    }
}


