#include "cameraerr.h"
#include "ui_cameraerr.h"

CameraErr::CameraErr(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CameraErr)
{
    ui->setupUi(this);
    setWindowTitle("错误提示");
}

CameraErr::~CameraErr()
{
    delete ui;
}
