#ifndef SMALLIMAGEDISPLAYFORM_H
#define SMALLIMAGEDISPLAYFORM_H

#include <QWidget>
#include <QTimer>
#include <QImage>
#include <QPixmap>
#include <QMouseEvent>
#include <QPainter>
#include <QFont>
#include <QPen>
#include <QDebug>
#include <QDockWidget>
#include "Tool/GlobalParameter.h"

namespace Ui {
class SmallImageDisplayForm;
}

class SmallImageDisplayForm : public QWidget
{
    Q_OBJECT

public:
    explicit SmallImageDisplayForm(QWidget *parent = 0);
    ~SmallImageDisplayForm();
    void startDisplay(int ms = 50);
    void stopDisplay();
    void updateImage(Mat& frame);
public slots:
    void onTimerDisplay();
protected:
    void mousePressEvent(QMouseEvent *event);
    void mouseDoubleClickEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);
private:
    Ui::SmallImageDisplayForm *ui;
    QTimer m_timer;
    GlobalParameter* g_param;
    Mat m_rgbFrame;
    QImage m_qimage;
};

#endif // SMALLIMAGEDISPLAYFORM_H
