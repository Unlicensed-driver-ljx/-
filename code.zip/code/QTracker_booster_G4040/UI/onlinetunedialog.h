#ifndef ONLINETUNEDIALOG_H
#define ONLINETUNEDIALOG_H

#include <QDialog>
#include <QDir>
#include <QFile>
#include <QTimer>
#include "Track/fasttrack.h"
#include "Tool/GlobalParameter.h"
#include "Camera/g400camera.h"
#include <QtConcurrent>
#include <QThread>
//#include <QValueAxis>
#include <QtCharts/QChart>
#include <QtCharts/QValueAxis>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QChartView>
#include <QBarSet>
#include <QBarSeries>
#include <QBarCategoryAxis>
#include <QFileDialog>
#include <QDesktopServices>
#include <QUrl>
#include "IO/serialport.h"
//#include <QtWebKitWidgets/QWebView>

QT_CHARTS_USE_NAMESPACE

namespace Ui {
class OnlineTuneDialog;
}

class OnlineTuneDialog : public QDialog
{
    Q_OBJECT

public:
    explicit OnlineTuneDialog(QWidget *parent = 0);
    ~OnlineTuneDialog();

    void setG400CameraPtr(G400Camera* g400_camera);
public slots:
    void onG400Detect(int state);
    void onDisplayContrastUpFactor(double val);
    void onDisplayContrastLowFactor(double val);
    void onSaveImage();
    void onTrackChangeThresh_0(double val);
    void onTrackChangeThresh_1(double val);
    void onTrackChangeThresh_3(int val);

    void onG400CamerasaveimagestateChange(int index);
    void onG400Camerastartsaveimage();
    void onG400Camerastopsaveimage();

    void btnToggleddisply(bool checked);
    void btnToggleddisplyC(bool checked);
    void btnToggleddisplyLU(bool checked);
    void btnToggleddisplyLD(bool checked);
    void btnToggleddisplyRU(bool checked);
    void btnToggleddisplyRD(bool checked);

    void onG400CameraAuxiliaryLine(int state);

    void btnToggledshowByteStretch(bool checked);
    void btnToggledshowMeanStretch(bool checked);
    void btnToggledshowSkylightStretch(bool checked);

    void onG400CameraSetType(int state);
    void onG400ImageBitShow(int index);
    void SetLongWaveCameraType();
    void SetMediumWaveCameraType();
    void SetMediumWaveInfraredCameraType();
    void SetVisibleLightCameraType();
    void SetNoCameraMode();

    void Delay_MSec(unsigned int msec);

    void btnToggledGuideModeTradition(bool checked);
    void btnToggledGuideModeSinglerod(bool checked);
    void onTrackChangeTrackGate(int val);
    void btnToggledTrackTradition(bool checked);
    void btnToggledTrackAI_1(bool checked);
    void btnToggledTrackAI_2(bool checked);
    void btnToggledModeTraditionXingxin(bool checked);
    void btnToggledModeTraditionZhixin(bool checked);
    void btnToggledModeTraditionUp(bool checked);
    void btnToggledModeTraditionDown(bool checked);
    void btnToggledModeTraditionLeft(bool checked);
    void btnToggledModeTraditionRight(bool checked);
    void btnToggledModeTraditionLeftUp(bool checked);
    void btnToggledModeTraditionLeftDown(bool checked);
    void btnToggledModeTraditionRightUp(bool checked);
    void btnToggledModeTraditionRightDown(bool checked);

    void ImageProcessingLoadPath();
    void ImageProcessingDisplayStart();
    void ImageProcessingDisplayEnd();
    void ImageProcessingStartMeasurement(int state);
    void ImageProcessingMeasurementShape(int index);
    void ImageProcessingDataEmpty();

    //void OpenURL();
    void OpenSoftwareManual();

    void saveHistogram(QString path,int S,Mat D);
    void saveProjection(QString path,int S,Mat D);

    void onC640CameraState();

    void CameraSetCameraLinkMode(int state);
    void CameraSetImageFormat(int state);
    void CameraImageLive(bool checked);
    void CameraImageunLive(bool checked);
    void CameraSetImageBit(int val);
    void CameraSetImageTap(int val);
    void CameraEleImageStab(int state);
    void CameraImageEnhancement(int state);

private:
    Ui::OnlineTuneDialog *ui;
    GlobalParameter* g_param;

    G400Camera* m_g400_camera;
    FastTrack m_track;

    int saveimagestate = 0;
    QTimer *m_recordBarTimer;
    QTimer *m_DisplayResolutionTimer;
    QTimer *m_DisplayDiskSpace;
    QTimer *m_DisplayDate;
    QTimer *m_SerialSendTimer;
    int m_recordInt = 0;
    QString strCheckBoxStyle;

    QMutex softTrieMutex;
    QWaitCondition softTriWaitCondition;

};

#endif // ONLINETUNEDIALOG_H
