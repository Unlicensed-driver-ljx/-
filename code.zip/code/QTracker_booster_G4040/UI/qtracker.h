#ifndef QTRACKER_H
#define QTRACKER_H

#include "Track/fasttrack.h"
#include <QMainWindow>
#include <QtCore>
#include "Camera/g400camera.h"
#include "Camera/visualcamera.h"
#include "Detect/YOLO/detectoryologpu.h"
#include "UI/smallimagedisplayform.h"
#include "UI/onlinetunedialog.h"
#include "Tool/GlobalParameter.h"
#include "IO/serialport.h"
#include "IO/communication.h"
#include "Camera/imageprocessing.h"
#include "IO/udptransdata.h"
#include "IO/tcpworker.h"
#include <math.h>

namespace Ui {
class QTracker;
}

class QTracker : public QMainWindow
{
    Q_OBJECT

public:
    explicit QTracker(QWidget *parent = 0);
    void setTuneDialog(OnlineTuneDialog* tuneDialog);
    void keyPressEventMM(QKeyEvent *event);
    void enterClose();
    ~QTracker();
protected:
    void resizeEvent(QResizeEvent *);
    void closeEvent(QCloseEvent *);
    void keyPressEvent(QKeyEvent *event);
    void paintEvent(QPaintEvent *event);
public slots:
    void init();
signals:
    void initTcpSig();
private:
    Ui::QTracker *ui;
    SmallImageDisplayForm *m_small_form;
    OnlineTuneDialog* m_tune_dialog;
    GlobalParameter* g_param;

    VisualCamera* m_visual_camera;
    G400Camera* m_g400_camera;

    TcpWorker* m_tcpWork;
    UDPTransData* udp;
    FastTrack m_track;
    Communication* m_comm;
    ImageProcessing* img_processing;
    QThread tcpworkerThread;

};

#endif // QTRACKER_H
