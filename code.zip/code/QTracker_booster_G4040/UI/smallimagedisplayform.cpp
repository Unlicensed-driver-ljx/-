#include "smallimagedisplayform.h"
#include "ui_smallimagedisplayform.h"

SmallImageDisplayForm::SmallImageDisplayForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SmallImageDisplayForm)
{
    ui->setupUi(this);
    g_param = GlobalParameter::getInstance();
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(onTimerDisplay()));
    //setFeatures(QDockWidget::DockWidgetMovable | DockWidgetFloatable);
    //setMinimumSize(640,380);
    setMinimumSize(g_param->displayParam.small_win_size, g_param->displayParam.small_win_size / 16 * 9);
}

SmallImageDisplayForm::~SmallImageDisplayForm()
{
    stopDisplay();
    delete ui;
}

void SmallImageDisplayForm::startDisplay(int ms)
{
    m_timer.stop();
    m_timer.start(ms);
}

void SmallImageDisplayForm::stopDisplay()
{
    m_timer.stop();
}

void SmallImageDisplayForm::updateImage(Mat &frame)
{
    if (frame.channels() == 3)
    {
        try
        {
            if(frame.empty())
            {
                qDebug() << "SmallImageDisplayForm::updateImage frame empty";
                return;
            }
            cv::cvtColor(frame, m_rgbFrame, COLOR_BGR2RGB);
            m_qimage = QImage((const unsigned char*)(m_rgbFrame.data),
                m_rgbFrame.cols, m_rgbFrame.rows, QImage::Format_RGB888);
        }
        catch (cv::Exception* e)
        {
            qDebug() << "QImageDisplayLabel::updateImage exception " << e->what();
        }
    }
    else
    {
        m_qimage = QImage((const unsigned char*)(frame.data),
            frame.cols, frame.rows, QImage::Format_Indexed8);
    }
    if (!m_qimage.isNull())
    {
        //g_param->debugParam.displayCount++;
        ui->label->setPixmap(QPixmap::fromImage(m_qimage));

    }
    else
    {
        qDebug() << "QImageDisplayLabel::updateImage m_qimage.isNull() ";
    }
}

void SmallImageDisplayForm::onTimerDisplay()
{
    if((g_param->focus_flag == true)&&(g_param->focusParam.mouseDoubleClick == true))
    {
//        IplImage RoiImage;
//        //RoiImage = cvIplImage(g_param->ROI_image);
//        RoiImage = cvIplImage(g_param->imageDisplay);
//        qDebug()<<"x"<<g_param->displayParam.mouseClickPos.x<<"y"<<g_param->displayParam.mouseClickPos.y;
//        if((g_param->displayParam.mouseClickPos.x<200)||(g_param->displayParam.mouseClickPos.y<200)||(g_param->displayParam.mouseClickPos.x>1720)||(g_param->displayParam.mouseClickPos.y>880))
//        {
//            updateImage(g_param->imageDisplay_small);
//        }
//        else
//        {
//            cvSetImageROI(&RoiImage,cvRect(g_param->displayParam.mouseClickPos.x,g_param->displayParam.mouseClickPos.y,g_param->focusParam.image_w,g_param->focusParam.image_h));

//            Mat ROI = cvarrToMat(&RoiImage);
//            ROI.copyTo(g_param->imageDisplay_small);
//            //g_param->dst.copyTo(g_param->imageDisplay_small);
//            cvResetImageROI(&RoiImage);
//            updateImage(g_param->imageDisplay_small);
//        }
    }

    /*if (g_param->imageDisplay_small.rows > 0 && g_param->imageDisplay_small.cols > 0 && !g_param->imageDisplay_small.empty())
    {
        updateImage(g_param->imageDisplay_small);
    }*/
}

void SmallImageDisplayForm::mouseDoubleClickEvent(QMouseEvent *)
{
    g_param->trackParam.state = DETECT;
    if(g_param->displayParam.imgSource == VISUAL)
    {
        g_param->displayParam.imgSource = IR;
        g_param->displayParam.imgSize.width = g_param->displayParam.IR_size.width;
        g_param->displayParam.imgSize.height = g_param->displayParam.IR_size.height;
    }
    else
    {
        g_param->displayParam.imgSource = VISUAL;
        g_param->displayParam.imgSize.width = g_param->displayParam.VS_size.width;
        g_param->displayParam.imgSize.height = g_param->displayParam.VS_size.height;
    }
}

void SmallImageDisplayForm::wheelEvent(QWheelEvent *event)
{
    if(event->delta()>0)
    {
        if((g_param->focusParam.image_w>20)&&(g_param->focusParam.image_h>20))
        {
            g_param->focusParam.image_w = g_param->focusParam.image_w - 10;
            g_param->focusParam.image_h = g_param->focusParam.image_h - 10;
        }
        if((g_param->focusParam.image_w<=10)&&(g_param->focusParam.image_h<=10))
        {
            g_param->focusParam.image_w = 10;
            g_param->focusParam.image_h = 10;
        }

    }
    else
    {
        if((g_param->focusParam.image_w<500)&&(g_param->focusParam.image_h<500))
        {
            g_param->focusParam.image_w = g_param->focusParam.image_w + 10;
            g_param->focusParam.image_h = g_param->focusParam.image_h + 10;
        }
        if((g_param->focusParam.image_w>=500)&&(g_param->focusParam.image_h>=500))
        {
            g_param->focusParam.image_w = 500;
            g_param->focusParam.image_h = 500;
        }
    }
}

void SmallImageDisplayForm::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton )
    {
        int x = (int)((float)event->pos().x() / g_param->displayParam.imgScale.x);
        int y = (int)((float)event->pos().y() / g_param->displayParam.imgScale.y);

        if (x < g_param->displayParam.imgSize.width && y < g_param->displayParam.imgSize.height)
        {
            g_param->displayParam.mouseClickPos.x = x;
            g_param->displayParam.mouseClickPos.y = y;
        }
    }
}

