#pragma once

#include <QLabel>
#include <QTimer>
#include <QImage>
#include <QPixmap>
#include <QMouseEvent>
#include <QWheelEvent>
#include <QPainter>
#include <QFont>
#include <QPen>
#include <QDebug>
#include <QApplication>
#include <QDateTime>
#include <qdesktopwidget.h>
#include "ui_QImageDisplayLabel.h"
#include "Tool/GlobalParameter.h"
#include "cameraerr.h"
#include "MainSlaver.h"

/**
* @brief ����QLabel��Ƶ�ͼ����ʾ�ؼ��ࡣ
* @date 2018/03/06
* @version 1.1
* @author Wangzy
*/
class QImageDisplayLabel : public QLabel
{
	Q_OBJECT

public:
	
	QImageDisplayLabel(QWidget *parent = Q_NULLPTR);
	~QImageDisplayLabel();
    void startDisplay(int ms = 40);
	void stopDisplay();
	void updateImage(Mat frame);
	void OverlayCharacter();

    void drawDetectBox(Mat frame); /// 20190714 wangzy
    void drawMeasurementBox(Mat frame);
    void drawPred(int classId, float conf, int left, int top, int right, int bottom, Mat &frame);
    float get_color(int c, int x, int max);
    void Delay_MSec(unsigned int msec);
public slots:
	void onTimerDisplay();
protected:
	/**
	* @brief ��Ӧ��굥��
	*/
	void mousePressEvent(QMouseEvent *event);
	/**
	* @brief ��Ӧ���˫��
	*/
	void mouseDoubleClickEvent(QMouseEvent *event);
    void wheelEvent(QWheelEvent *event);
private:
	Ui::QImageDisplayLabel ui;

	QTimer m_timer;
	/// ȫ�ֲ���
	GlobalParameter* g_param;
	/// ͼƬ����
	Mat m_rgbFrame;
	QImage m_qimage;
	/// ����ͼƬ��ʾ
	QImage m_qimageScale;
	/// ��ˢ����
	QPainter m_painter;
	/// ����
	QFont m_font;
	/// ����
	QPen m_pen;
    QImage image_1;
    CameraErr* m_cameraerr;

    bool fuhaox = true;
    bool fuhaoy = true;

    int waitdisplayC640DateTime = 0;
    // H264
    MainSlaver mainSlaver;

};
