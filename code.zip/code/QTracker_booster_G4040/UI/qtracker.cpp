#include "qtracker.h"
#include "ui_qtracker.h"
#include <QDebug>

QTracker::QTracker(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::QTracker)
{
    ui->setupUi(this);
    this->setWindowIcon(QIcon(":new/prefix1/20220307042212386.ico"));
    g_param = GlobalParameter::getInstance();  
    m_tune_dialog = new OnlineTuneDialog(this);
    udp = new UDPTransData(this);
      qDebug()<<"111111111111111QTracker_QTracker_QTracker Communication";
    m_g400_camera = new G400Camera();
        qDebug()<<"222222222222222QTracker_QTracker_QTracker Communication";
    img_processing = new ImageProcessing();
     qDebug()<<"QTracker_QTracker_QTracker";
    m_comm = new Communication();
     qDebug()<<"QTracker_QTracker_QTracker Communication";

}

QTracker::~QTracker()
{
    closecameralink_recv();
    xdma_app_stop();
    g_param->uart_recv_work = false;
    tcpworkerThread.quit();
    tcpworkerThread.wait();
    if(m_g400_camera != NULL)
    {
        delete m_g400_camera;
        m_g400_camera = NULL;
    }
    if(img_processing != NULL)
    {
        delete img_processing;
        img_processing = NULL;
    }
    delete ui;
}

void QTracker::paintEvent(QPaintEvent *event)
{
    if(g_param->b_showBackgroundMap == false && g_param->ready_power == false)
    {
        if(g_param->cameraconfigParam.CameraLive == true)
        {
            m_g400_camera->init();
            m_g400_camera->startCapture();
            g_param->ready_power = true;
        }
    }
    if(g_param->b_showBackgroundMap == true && g_param->ready_power == true)
    {
        m_g400_camera->close();
        g_param->ready_power = false;
    }
    if(g_param->b_showBackgroundMap == true && g_param->ImageProcessingdisplaystart == true)
    {
        img_processing->init();
        img_processing->startCapture();
        g_param->ImageProcessingdisplaystart = false;
    }
    if(g_param->b_showBackgroundMap == false && g_param->ImageProcessingdisplayend == true)
    {
        img_processing->close();
        g_param->ImageProcessingdisplayend = false;
    }
}
void QTracker::setTuneDialog(OnlineTuneDialog *tuneDialog)
{
    if(NULL != tuneDialog)
    {
       m_tune_dialog = tuneDialog;

       init();
       if(g_param->controlParam.TCPOPEN == true)
       {
           m_tcpWork = new TcpWorker;
           m_tcpWork->moveToThread(&tcpworkerThread);
           connect(this,SIGNAL(initTcpSig()),m_tcpWork,SLOT(initTcp()));
           connect(m_g400_camera,SIGNAL(SignalGrabData()),m_tcpWork,SLOT(slot_sendmessage()));
           tcpworkerThread.start();

           emit initTcpSig();
       }
    }

}

void QTracker::resizeEvent(QResizeEvent *)
{
    if(g_param->displayParam.imgSource == VISUAL)
    {
        g_param->displayParam.imgSize = g_param->displayParam.VS_size;
    }
    else
    {
        g_param->displayParam.imgSize = g_param->displayParam.IR_size;
    }
    g_param->displayParam.imgScale.x = ui->labelImageDisplay->width() / (double)g_param->displayParam.imgSize.width;
}

void QTracker::closeEvent(QCloseEvent *)
{
    g_param->uart_recv_work = false;
    ui->labelImageDisplay->stopDisplay();
    m_tune_dialog->close();

    if(m_comm != NULL)
    {
        m_comm->close();
    }
    if(m_g400_camera != NULL)
    {
        m_g400_camera->close();
        QThread::msleep(50);
    }
    if(img_processing != NULL)
    {
        img_processing->close();
        QThread::msleep(50);
    }
    m_track.close();
    QThread::msleep(50);
    qApp->exit();
}

void QTracker::enterClose()
{
    ui->labelImageDisplay->stopDisplay();
    m_tune_dialog->close();
    if(m_g400_camera != NULL)
    {
        m_g400_camera->close();
    }
    if(img_processing != NULL)
    {
        img_processing->close();
    }
    if(m_comm != NULL)
    {
        m_comm->close();
    }

    m_track.close();
    QThread::msleep(50);
    qApp->exit();
}

void QTracker::keyPressEvent(QKeyEvent *event)
{

    /// ctrl+M
    if((event->modifiers() == Qt::ControlModifier) && (event->key() == Qt::Key_M))
    {
        g_param->trackParam.bAutoDetect2Track = false;
        g_param->trackParam.state = DETECT;
        cout << "Change Mode: Manual select target" << endl;
    }
    /// ctrl+A
    if((event->modifiers() == Qt::ControlModifier) && (event->key() == Qt::Key_A))
    {
        g_param->trackParam.bAutoDetect2Track = true;
        g_param->trackParam.state = DETECT;
        cout << "Change Mode: Auto select target" << endl;
    }
    /// ctrl+1
    if(event->key() == Qt::Key_1)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 1)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[0].x + g_param->yolo_res.boxes[0].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[0].y + g_param->yolo_res.boxes[0].height / 2;
            cout << "Select Target 1" << endl;
        }
    }
    /// ctrl+2
    if(event->key() == Qt::Key_2)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 2)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[1].x + g_param->yolo_res.boxes[1].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[1].y + g_param->yolo_res.boxes[1].height / 2;
            cout << "Select Target 2" << endl;
        }
    }
    /// ctrl+3
    if(event->key() == Qt::Key_3)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 3)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[2].x + g_param->yolo_res.boxes[2].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[2].y + g_param->yolo_res.boxes[2].height / 2;
            cout << "Select Target 3" << endl;
        }
    }
    /// ctrl+4
    if(event->key() == Qt::Key_4)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 4)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[3].x + g_param->yolo_res.boxes[3].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[3].y + g_param->yolo_res.boxes[3].height / 2;
            cout << "Select Target 4" << endl;
        }
    }
    /// ctrl+5
    if(event->key() == Qt::Key_5)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 5)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[4].x + g_param->yolo_res.boxes[4].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[4].y + g_param->yolo_res.boxes[4].height / 2;
            cout << "Select Target 5" << endl;
        }
    }
    /// ctrl+6
    if(event->key() == Qt::Key_6)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 6)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[5].x + g_param->yolo_res.boxes[5].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[5].y + g_param->yolo_res.boxes[5].height / 2;
            cout << "Select Target 6" << endl;
        }
    }
    /// ctrl+7
    if(event->key() == Qt::Key_7)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 7)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[6].x + g_param->yolo_res.boxes[6].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[6].y + g_param->yolo_res.boxes[6].height / 2;
            cout << "Select Target 5" << endl;
        }
    }
    ///ESC
    if(event->key() == Qt::Key_Escape)
    {
        m_tune_dialog->show(); /// 20190723 wangzy
    }

}
void QTracker::keyPressEventMM(QKeyEvent *event)
{
    if(event->key() == Qt::Key_Escape)
    {
        //qDebug()<<"Escape is down";
    }

    /// ctrl+M
    if((event->modifiers() == Qt::ControlModifier) && (event->key() == Qt::Key_M))
    {
        g_param->trackParam.bAutoDetect2Track = false;
        g_param->trackParam.state = DETECT;
        cout << "Change Mode: Manual select target" << endl;
    }
    /// ctrl+A
    if((event->modifiers() == Qt::ControlModifier) && (event->key() == Qt::Key_A))
    {
        g_param->trackParam.bAutoDetect2Track = true;
        g_param->trackParam.state = DETECT;
        cout << "Change Mode: Auto select target" << endl;
    }
    /// ctrl+1
    if(event->key() == Qt::Key_1)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 1)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[0].x + g_param->yolo_res.boxes[0].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[0].y + g_param->yolo_res.boxes[0].height / 2;
            cout << "Select Target 1" << endl;
        }
    }
    /// ctrl+2
    if(event->key() == Qt::Key_2)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 2)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[1].x + g_param->yolo_res.boxes[1].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[1].y + g_param->yolo_res.boxes[1].height / 2;
            cout << "Select Target 2" << endl;
        }
    }
    /// ctrl+3
    if(event->key() == Qt::Key_3)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 3)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[2].x + g_param->yolo_res.boxes[2].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[2].y + g_param->yolo_res.boxes[2].height / 2;
            cout << "Select Target 3" << endl;
        }
    }
    /// ctrl+4
    if(event->key() == Qt::Key_4)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 4)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[3].x + g_param->yolo_res.boxes[3].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[3].y + g_param->yolo_res.boxes[3].height / 2;
            cout << "Select Target 4" << endl;
        }
    }
    /// ctrl+5
    if(event->key() == Qt::Key_5)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 5)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[4].x + g_param->yolo_res.boxes[4].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[4].y + g_param->yolo_res.boxes[4].height / 2;
            cout << "Select Target 5" << endl;
        }
    }
    /// ctrl+6
    if(event->key() == Qt::Key_6)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 6)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[5].x + g_param->yolo_res.boxes[5].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[5].y + g_param->yolo_res.boxes[5].height / 2;
            cout << "Select Target 6" << endl;
        }
    }
    /// ctrl+7
    if(event->key() == Qt::Key_7)
    {
        if(g_param->trackParam.state == DETECT && g_param->yolo_res.boxes.size() >= 7)
        {
            g_param->trackParam.bManualSelect = true;
            g_param->displayParam.mouseClickPos.x = g_param->yolo_res.boxes[6].x + g_param->yolo_res.boxes[6].width / 2;
            g_param->displayParam.mouseClickPos.y = g_param->yolo_res.boxes[6].y + g_param->yolo_res.boxes[6].height / 2;
            cout << "Select Target 5" << endl;
        }
    }
}

void QTracker::init()
{
    if(m_g400_camera->init() == true)
    {
        m_g400_camera->startCapture();
    }
    if(udp->initUDPPort() == false)
    {
        cout << "UDPTransData init error"<<endl;
    }
    if(m_track.init() == true)
    {
        m_track.startTrack();
    }
    if(m_comm->init() == false)
    {
        cout << "communication init error"<<endl;
    }

//    int disp_fps = (int)(1000.0f / (g_param->displayParam.fps + 0.00000001));
//    if(disp_fps < 33)
//    {
//        disp_fps = 33;
//        cout << "UI diplay fps too high, reset to 30Hz"<<endl;
//    }

    if(g_param->controlParam.ShowImage)
    {
       ui->labelImageDisplay->startDisplay(40);
    }

}
