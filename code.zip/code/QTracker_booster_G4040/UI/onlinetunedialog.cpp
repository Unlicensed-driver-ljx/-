#include "onlinetunedialog.h"
#include "ui_onlinetunedialog.h"


OnlineTuneDialog::OnlineTuneDialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::OnlineTuneDialog)
{
    ui->setupUi(this);
    g_param = GlobalParameter::getInstance();
    m_recordBarTimer = new QTimer(this);
    m_recordBarTimer->setInterval(200);
    m_SerialSendTimer = new QTimer(this);
    //m_SerialSendTimer->setInterval(g_param->controlParam.SerialPortSendTimer);
   // m_SerialSendTimer->start();
    m_recordInt = 0;
    ui->progressBarsaveimage->setTextVisible(false);
    ui->pushButtonstopsaveimage->setEnabled(false);
    m_DisplayResolutionTimer = new QTimer(this);
    m_DisplayResolutionTimer->setInterval(100);
    m_DisplayDiskSpace = new QTimer(this);
    m_DisplayDiskSpace->setInterval(1000);
    m_DisplayResolutionTimer->start();
    m_DisplayDiskSpace->start();
    m_DisplayDate = new QTimer(this);
    m_DisplayDate->setInterval(500);
    m_DisplayDate->start();
    ui->labelCameraSize->setVisible(false);
    ui->groupBox->setEnabled(false);
    ui->comboBoxImageBitShow->setEnabled(false);

    ui->tabWidget->removeTab(4);
    ui->groupBox_2->setVisible(false);
    connect(ui->doubleSpinBoxContrastUpFactor, SIGNAL(valueChanged(double)), this, SLOT(onDisplayContrastUpFactor(double)));
    connect(ui->doubleSpinBoxContrastLowFactor, SIGNAL(valueChanged(double)), this, SLOT(onDisplayContrastLowFactor(double)));
    connect(ui->pushButtonSaveImage, SIGNAL(clicked()), this, SLOT(onSaveImage()));
    connect(ui->doubleSpinBoxTrackThresh_0, SIGNAL(valueChanged(double)), this, SLOT(onTrackChangeThresh_0(double)));
    connect(ui->doubleSpinBoxTrackThresh_1, SIGNAL(valueChanged(double)), this, SLOT(onTrackChangeThresh_1(double)));
    connect(ui->spinBoxTrackThresh_3, SIGNAL(valueChanged(int)), this, SLOT(onTrackChangeThresh_3(int)));

    ui->progressBarsaveimage->setTextVisible(false);
    connect(ui->comboBoxsaveimagestate, SIGNAL(currentIndexChanged(int)), this, SLOT(onG400CamerasaveimagestateChange(int)));
    connect(ui->pushButtonstartsaveimage, SIGNAL(clicked()), this, SLOT(onG400Camerastartsaveimage()));
    connect(ui->pushButtonstopsaveimage, SIGNAL(clicked()), this, SLOT(onG400Camerastopsaveimage()));
    connect(m_recordBarTimer,&QTimer::timeout, [=](){
        m_recordInt = m_recordInt + 5;
        if(m_recordInt > 100)
        {
            m_recordInt = 0;
        }
        ui->progressBarsaveimage->setValue(m_recordInt);
        ui->labelsaveimage->setText(QString::number(m_recordInt)+"%");
    });
//    connect(m_SerialSendTimer,&QTimer::timeout, [=](){
//        uint32_t statu, cameraid, carid;
//        int32_t targetx, targety;
//        statu = g_param->trackstatu;
//        cameraid = g_param->controlParam.CameraID;
//        carid = g_param->controlParam.CarID;
//        if (g_param->trackParam.state == TRACK&&(g_param->trackParam.objPosPix.x != 0&&g_param->trackParam.objPosPix.y != 0))
//        {
//            targetx = (g_param->trackParam.objPosPix.x - g_param->cameraconfigParam.ResolutionW / 2)*1000;
//            targety = (g_param->cameraconfigParam.ResolutionH / 2 - g_param->trackParam.objPosPix.y)*1000;
//        }
//        else
//        {
//            targetx = 0;
//            targety = 0;
//        }

//        if(g_param->serial_send_satrt == true)
//        {
//            serial_send_set(statu, targetx, targety, cameraid, carid);
//        }

//    });

    connect(ui->radioButtondisply,SIGNAL(toggled(bool)),this,SLOT(btnToggleddisply(bool)));
    connect(ui->radioButtondisplyLU,SIGNAL(toggled(bool)),this,SLOT(btnToggleddisplyLU(bool)));
    connect(ui->radioButtondisplyRU,SIGNAL(toggled(bool)),this,SLOT(btnToggleddisplyRU(bool)));
    connect(ui->radioButtondisplyLD,SIGNAL(toggled(bool)),this,SLOT(btnToggleddisplyLD(bool)));
    connect(ui->radioButtondisplyRD,SIGNAL(toggled(bool)),this,SLOT(btnToggleddisplyRD(bool)));
    connect(ui->radioButtondisplyC,SIGNAL(toggled(bool)),this,SLOT(btnToggleddisplyC(bool)));

    connect(m_DisplayResolutionTimer,&QTimer::timeout, [=](){

        if(g_param->Width != 0)
        {
            ui->labelCameraSize->setText(QString::number(g_param->Width)+"*"+QString::number(g_param->Height));
        }
    });
//    connect(m_DisplayDate,&QTimer::timeout, [=](){
//        if(g_param->b_G400Camera == false && g_param->b_G4040Camera == false && g_param->b_USBCamera == false && g_param->b_C640Camera == false)
//        {
//            ui->lcdNumberMeanValue->display(g_param->MeanValue);
//            ui->lcdNumberVariance->display(g_param->Variance);
//            ui->lcdNumberMaxGrayValue->display(g_param->MaxGrayValue);
//            ui->lcdNumberMinGrayValue->display(g_param->MinGrayValue);
//            if(g_param->Measurement == true)
//            {
//                if(g_param->MeasurementState == 1)
//                {
//                    ui->lcdNumberStartXY->display(g_param->MeasurementStartX + "." + g_param->MeasurementStartY);
//                }
//                if(g_param->MeasurementState == 2)
//                {
//                    ui->lcdNumberEndXY->display(g_param->MeasurementEndX + "." + g_param->MeasurementEndY);
//                    ui->lcdNumberHorizontalDistance->display(g_param->HorizontalDistance);
//                    ui->lcdNumberVerticalDistance->display(g_param->VerticalDistance);
//                    ui->lcdNumberRegionalArea->display(g_param->RegionalArea);
//                }
//            }
//            else
//            {
//                ui->lcdNumberStartXY->display("0");
//                ui->lcdNumberEndXY->display("0");
//                ui->lcdNumberHorizontalDistance->display("0");
//                ui->lcdNumberVerticalDistance->display("0");
//                ui->lcdNumberRegionalArea->display("0");
//            }
//        }
//        //if(g_param->DATControlCamera == true)
//        {
//            if(g_param->bufdata_st.mid(2,8) == "")
//            {
//                ui->lcdNumberTime->display("2000-00-00 00:00:00:000");
//            }
//            else
//            {
//                ui->lcdNumberTime->display("20"+g_param->bufdata_st.mid(2,2)+"-"+g_param->bufdata_st.mid(4,2)+"-"+g_param->bufdata_st.mid(6,2)+" "+g_param->bufdata_st.mid(8,2)+":"+g_param->bufdata_st.mid(10,2)+":"+g_param->bufdata_st.mid(12,2)+":"+g_param->bufdata_st.mid(14,3));

//            }
//            ui->lcdNumberGain->display(g_param->gain_index);
//            ui->lcdNumberExptime->display(g_param->expose_ipd);
//            ui->lcdNumberAzimuth->display(QString("%1").arg(g_param->ang_azimuth,5,'f',2,QLatin1Char('0')));
//            ui->lcdNumberElevatio->display(QString("%1").arg(g_param->ang_elevatio,5,'f',2,QLatin1Char('0')));
//            ui->lcdNumberLongitude->display(QString("%1").arg(g_param->bufdata_j.toFloat(),5,'f',2,QLatin1Char('0')));
//            ui->lcdNumberLatitude->display(QString("%1").arg(g_param->bufdata_w.toFloat(),5,'f',2,QLatin1Char('0')));
//            ui->lcdNumberAltitude->display(g_param->bufdata_hb.toFloat());
//            ui->lcdNumberMistiming->display(g_param->miss_time);
//            ui->lcdNumberAzimuthZero->display(QString::number(g_param->struct_ccd_control_in.fAZeroError));
//            ui->lcdNumberElevatioZero->display(QString::number(g_param->struct_ccd_control_in.fEZeroError));
//            if(g_param->struct_ccd_control_in.bCCDPowerOn == true)
//            {
//                ui->checkBoxDATpowerstate->setChecked(true);
//            }
//            else
//            {
//                ui->checkBoxDATpowerstate->setChecked(false);
//            }
//            if(g_param->debugParam.bSaveRawFileOnceGrab == true)
//            {
//                ui->checkBoxDATsavefitsstate->setChecked(true);
//            }
//            else
//            {
//                ui->checkBoxDATsavefitsstate->setChecked(false);
//            }
//        }
//    });
    connect(ui->checkBoxAuxiliaryLine, SIGNAL(stateChanged(int)), this, SLOT(onG400CameraAuxiliaryLine(int)));

    connect(ui->radioButtonshowByteStretch,SIGNAL(toggled(bool)),this,SLOT(btnToggledshowByteStretch(bool)));
    connect(ui->radioButtonshowMeanStretch,SIGNAL(toggled(bool)),this,SLOT(btnToggledshowMeanStretch(bool)));
    connect(ui->radioButtonshowSkylightStretch,SIGNAL(toggled(bool)),this,SLOT(btnToggledshowSkylightStretch(bool)));

    connect(m_DisplayDiskSpace,&QTimer::timeout, [=](){
        QStorageInfo dirFress;
        dirFress.setPath("/home/pi/hdd");
        g_param->FreeStoreSize = dirFress.bytesAvailable()/1024/1024/1024;//G
        ui->lcdNumberDiskSpace->display(QString("%1").arg(g_param->FreeStoreSize,4,10,QLatin1Char('0')));
    });

    connect(ui->checkBoxDetect, SIGNAL(stateChanged(int)), this, SLOT(onG400Detect(int)));

    connect(ui->comboBoxType, SIGNAL(currentIndexChanged(int)), this, SLOT(onG400CameraSetType(int)));

    connect(ui->radioButtonGuideModeTradition,SIGNAL(toggled(bool)),this,SLOT(btnToggledGuideModeTradition(bool)));
    connect(ui->radioButtonGuideModeSinglerod,SIGNAL(toggled(bool)),this,SLOT(btnToggledGuideModeSinglerod(bool)));
    connect(ui->spinBoxSetTrackGateSize, SIGNAL(valueChanged(int)), this, SLOT(onTrackChangeTrackGate(int)));
    connect(ui->spinBoxthresTradition,static_cast<void(QSpinBox::*)(int)>(&QSpinBox::valueChanged),[=]{
        g_param->trackParam.thresValueTrad = ui->spinBoxthresTradition->value();
    });
    QObject::connect(ui->checkBoxAutoThresTradition, &QCheckBox::stateChanged, [=] (int stateValue) {
    if(0 == stateValue)
     {
         g_param-> trackParam.bAutoThresTrad = false;
         ui->spinBoxthresTradition->setEnabled(true);
     }
     else
     {
         g_param-> trackParam.bAutoThresTrad = true;
         ui->spinBoxthresTradition->setEnabled(false);
     }
   });
    connect(ui->spinBoxminSizeTradition,static_cast<void(QSpinBox::*)(int)>(&QSpinBox::valueChanged),[=]{
        g_param->trackParam.minSizeTrad = ui->spinBoxminSizeTradition->value();
    });
    connect(ui->radioButtonTrackTradition,SIGNAL(toggled(bool)),this,SLOT(btnToggledTrackTradition(bool)));
    connect(ui->radioButtonTrackAI_1,SIGNAL(toggled(bool)),this,SLOT(btnToggledTrackAI_1(bool)));
    //connect(ui->radioButtonTrackAI_2,SIGNAL(toggled(bool)),this,SLOT(btnToggledTrackAI_2(bool)));
    connect(ui->radioButtonModeTraditionXingxin,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionXingxin(bool)));
    connect(ui->radioButtonModeTraditionZhixin,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionZhixin(bool)));
    connect(ui->radioButtonModeTraditionUp,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionUp(bool)));
    connect(ui->radioButtonModeTraditionDown,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionDown(bool)));
    connect(ui->radioButtonModeTraditionLeft,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionLeft(bool)));
    connect(ui->radioButtonModeTraditionRight,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionRight(bool)));
    connect(ui->radioButtonModeTraditionLeftUp,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionLeftUp(bool)));
    connect(ui->radioButtonModeTraditionLeftDown,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionLeftDown(bool)));
    connect(ui->radioButtonModeTraditionRightUp,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionRightUp(bool)));
    connect(ui->radioButtonModeTraditionRightDown,SIGNAL(toggled(bool)),this,SLOT(btnToggledModeTraditionRightDown(bool)));

    connect(ui->pushButtonImagePath, SIGNAL(clicked()), this, SLOT(ImageProcessingLoadPath()));
    connect(ui->pushButtonImageDisplayStart, SIGNAL(clicked()), this, SLOT(ImageProcessingDisplayStart()));
    connect(ui->pushButtonImageDisplayEnd, SIGNAL(clicked()), this, SLOT(ImageProcessingDisplayEnd()));
    connect(ui->checkBoxStartMeasurement, SIGNAL(stateChanged(int)), this, SLOT(ImageProcessingStartMeasurement(int)));
    connect(ui->pushButtonDataEmpty, SIGNAL(clicked()), this, SLOT(ImageProcessingDataEmpty()));
    connect(ui->comboBoxMeasurementShape, SIGNAL(currentIndexChanged(int)), this, SLOT(ImageProcessingMeasurementShape(int)));

    //connect(ui->pushButtonURL, SIGNAL(clicked()), this, SLOT(OpenURL()));
    connect(ui->pushButtonSoftwareManual, SIGNAL(clicked()), this, SLOT(OpenSoftwareManual()));
    connect(ui->pushButtonCameraState, SIGNAL(clicked()), this, SLOT(onC640CameraState()));

    connect(ui->comboBoxImageBitShow, SIGNAL(currentIndexChanged(int)), this, SLOT(onG400ImageBitShow(int)));

    connect(ui->lineEditResolutionW,&QLineEdit::editingFinished,this,[=](){
        g_param->cameraconfigParam.ResolutionW = ui->lineEditResolutionW->text().toInt();
    });

    connect(ui->lineEditResolutionH,&QLineEdit::editingFinished,this,[=](){
        g_param->cameraconfigParam.ResolutionH = ui->lineEditResolutionH->text().toInt();
    });

    connect(ui->spinBoxImageBit, SIGNAL(valueChanged(int)), this, SLOT(CameraSetImageBit(int)));
    connect(ui->spinBoxImageTap, SIGNAL(valueChanged(int)), this, SLOT(CameraSetImageTap(int)));
    connect(ui->comboBoxCameraLinkMode, SIGNAL(currentIndexChanged(int)), this, SLOT(CameraSetCameraLinkMode(int)));
    connect(ui->comboBoxImageFormat, SIGNAL(currentIndexChanged(int)), this, SLOT(CameraSetImageFormat(int)));
    connect(ui->radioButtonlive,SIGNAL(toggled(bool)),this,SLOT(CameraImageLive(bool)));
    connect(ui->radioButtonunlive,SIGNAL(toggled(bool)),this,SLOT(CameraImageunLive(bool)));

    connect(ui->checkBoxEleImageStab, SIGNAL(stateChanged(int)), this, SLOT(CameraEleImageStab(int)));
    connect(ui->checkBoxImageEnhancement, SIGNAL(stateChanged(int)), this, SLOT(CameraImageEnhancement(int)));

    strCheckBoxStyle.append("QChecBox::indicator::unchecked{image:url(:new/prefix1/red.jpg);}");
    strCheckBoxStyle.append("QChecBox::indicator::checked{image:url(:new/prefix1/green.jpg);}");
    strCheckBoxStyle.append("QChecBox::indicator::unchecked:hover{image:url(:new/prefix1/yellow.jpg);}");
    strCheckBoxStyle.append("QChecBox::indicator::checked:hover  {image:url(:new/prefix1/yellow.jpg);}");
    strCheckBoxStyle.append("QChecBox::indicator::unchecked:pressed{image:url(:new/prefix1/red.jpg);}");
    strCheckBoxStyle.append("QChecBox::indicator::checked:pressed  {image:url(:new/prefix1/green.jpg);}");
    ui->checkBoxDATpowerstate->setStyleSheet(strCheckBoxStyle);
    ui->checkBoxDATsavefitsstate->setStyleSheet(strCheckBoxStyle);

    m_g400_camera = NULL;

    ui->spinBoxSetTrackGateSize->setValue(g_param->trackParam.trackGateSize.width);
    ui->doubleSpinBoxTrackThresh_0->setValue(g_param->trackParam.thresh_lost);
    ui->doubleSpinBoxTrackThresh_1->setValue(g_param->trackParam.thresh_occlude);
    ui->spinBoxTrackThresh_3->setValue(g_param->trackParam.occlude_time);
    ui->groupBox_30->setEnabled(false);

}

OnlineTuneDialog::~OnlineTuneDialog()
{
    delete ui;
    delete m_recordBarTimer;
    delete m_DisplayResolutionTimer;
    delete m_DisplayDiskSpace;
    delete m_DisplayDate;
    delete m_SerialSendTimer;
}



void OnlineTuneDialog::SetLongWaveCameraType()
{
    QString PathNameold;
    if(g_param->b_G4040Camera == false && g_param->b_G400Camera == false && g_param->b_C640Camera == false)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG4040.fmt";
        QFile::rename(PathNameold,g_param->XCAP);
    }
    if(g_param->b_G400Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG400.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
        PathNameold= "../CAMERACONTROL/xcvidsetG4040.fmt";
        QFile::rename(PathNameold,g_param->XCAP);
    }
    if(g_param->b_C640Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetC640.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
        PathNameold= "../CAMERACONTROL/xcvidsetG4040.fmt";
        QFile::rename(PathNameold,g_param->XCAP);
    }
    g_param->camerafps = 0;
    g_param->mousePressPos.x = 0;
    g_param->mousePressPos.y = 0;
    g_param->m_LeftButton = false;
    g_param->b_G4040Camera = true;
    g_param->b_G400Camera = false;
    g_param->b_USBCamera = false;
    g_param->b_C640Camera = false;
    g_param->b_showBackgroundMap = true;
    Delay_MSec(50);
    g_param->Width = 4096;
    g_param->Height = 4096;
    g_param->b_showBackgroundMap = false;
    ui->labelCameraSize->setVisible(true);
    ui->groupBox_19->setEnabled(false);
    ui->groupBox_4->setEnabled(false);
    ui->groupBox_5->setEnabled(false);
}
void OnlineTuneDialog::SetMediumWaveCameraType()
{
    QString PathNameold;
    if(g_param->b_G4040Camera == false && g_param->b_G400Camera == false && g_param->b_C640Camera == false)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG400.fmt";
        qDebug()<<"PathNameold"<<PathNameold;
        QFile::rename(PathNameold,g_param->XCAP);
    }
    if(g_param->b_G4040Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG4040.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
        PathNameold= "../CAMERACONTROL/xcvidsetG400.fmt";
        QFile::rename(PathNameold,g_param->XCAP);
    }
    if(g_param->b_C640Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetC640.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
        PathNameold= "../CAMERACONTROL/xcvidsetG400.fmt";
        QFile::rename(PathNameold,g_param->XCAP);
    }
    g_param->camerafps = 0;
    g_param->mousePressPos.x = 0;
    g_param->mousePressPos.y = 0;
    g_param->m_LeftButton = false;
    g_param->b_G4040Camera = false;
    g_param->b_G400Camera = true;
    g_param->b_USBCamera = false;
    g_param->b_C640Camera = false;
    g_param->b_showBackgroundMap = true;
    Delay_MSec(50);
    g_param->Width = 2048;
    g_param->Height = 2048;
    g_param->b_showBackgroundMap = false;
    ui->labelCameraSize->setVisible(true);
    ui->groupBox_19->setEnabled(false);
    ui->groupBox_4->setEnabled(false);
    ui->groupBox_5->setEnabled(false);
}

void OnlineTuneDialog::SetMediumWaveInfraredCameraType()
{
    QString PathNameold;
    if(g_param->b_G400Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG400.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
    }
    if(g_param->b_G4040Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG4040.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
    }
    if(g_param->b_C640Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetC640.fmt";
        QFile::rename(g_param->XCAP,PathNameold);
    }
    g_param->camerafps = 0;
    g_param->mousePressPos.x = 0;
    g_param->mousePressPos.y = 0;
    g_param->m_LeftButton = false;
    g_param->b_G4040Camera = false;
    g_param->b_G400Camera = false;
    g_param->b_USBCamera = true;
    g_param->b_C640Camera = false;
    g_param->b_showBackgroundMap = true;
    Delay_MSec(50);
    g_param->b_showBackgroundMap = false;
    ui->labelCameraSize->setVisible(true);
    ui->groupBox_19->setEnabled(false);
    ui->groupBox_4->setEnabled(false);
    ui->groupBox_5->setEnabled(false);
}

void OnlineTuneDialog::SetVisibleLightCameraType()
{
    g_param->camerafps = 0;
    g_param->mousePressPos.x = 0;
    g_param->mousePressPos.y = 0;
    g_param->m_LeftButton = false;
    g_param->b_G4040Camera = false;
    g_param->b_G400Camera = false;
    g_param->b_USBCamera = false;
    g_param->b_C640Camera = true;
    g_param->b_showBackgroundMap = true;
    Delay_MSec(50);
    g_param->Width = 1920;
    g_param->Height = 1080;
    g_param->b_showBackgroundMap = false;

}

void OnlineTuneDialog::SetNoCameraMode()
{
    //g_param->imageDisplay = Mat::zeros(g_param->Height,g_param->Width,CV_8UC1);
    g_param->b_showBackgroundMap = true;
    g_param->camerafps = 0;
    g_param->mousePressPos.x = 0;
    g_param->mousePressPos.y = 0;
    g_param->m_LeftButton = false;
    QString PathNameold;
    if(g_param->b_G4040Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG4040.fmt";
    }
    if(g_param->b_G400Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetG400.fmt";
    }
    if(g_param->b_C640Camera == true)
    {
        PathNameold= "../CAMERACONTROL/xcvidsetC640.fmt";
    }
    QFile::rename(g_param->XCAP,PathNameold);
    g_param->b_G4040Camera = false;
    g_param->b_G400Camera = false;
    g_param->b_USBCamera = false;
    g_param->b_C640Camera = false;
    ui->labelCameraSize->setVisible(false);
    ui->groupBox_19->setEnabled(true);
    ui->groupBox_4->setEnabled(true);
    ui->groupBox_5->setEnabled(true);
}

void OnlineTuneDialog::onG400ImageBitShow(int index)
{
    g_param->i_setImageBitShow = index;
}

void OnlineTuneDialog::onG400CameraSetType(int index)
{
    //if(m_g400_camera != NULL)
    {
        g_param->imageDisplay = NULL;
        g_param->hist = NULL;
        g_param->EstimateGather = false;
        switch(index)
        {
        case 0:
            SetNoCameraMode();
            break;
        case 1:
            SetLongWaveCameraType();
            break;
        case 2:
            SetMediumWaveCameraType();
            break;
        case 3:
            SetMediumWaveInfraredCameraType();
            break;
        case 4:
            SetVisibleLightCameraType();
            break;
        default:
            g_param->b_showBackgroundMap = true;
            g_param->b_G4040Camera = false;
            g_param->b_G400Camera = false;
            g_param->b_USBCamera = false;
            g_param->b_C640Camera = false;
            break;
        }

    }
}

void OnlineTuneDialog::btnToggledshowByteStretch(bool checked)
{
    if(checked == true)
    {
        g_param->bShowBit = true;
        g_param->bShowSkyRight = false;
        ui->doubleSpinBoxContrastUpFactor->setEnabled(false);
        ui->doubleSpinBoxContrastLowFactor->setEnabled(false);
        ui->comboBoxImageBitShow->setEnabled(true);
    }
}
void OnlineTuneDialog::btnToggledshowMeanStretch(bool checked)
{
    if(checked == true)
    {
        g_param->bShowBit = false;
        g_param->bShowSkyRight = false;
        ui->doubleSpinBoxContrastUpFactor->setValue(3.0);
        ui->doubleSpinBoxContrastLowFactor->setValue(1.0);
        ui->doubleSpinBoxContrastUpFactor->setEnabled(true);
        ui->doubleSpinBoxContrastLowFactor->setEnabled(true);
        ui->comboBoxImageBitShow->setEnabled(false);
    }
}
void OnlineTuneDialog::btnToggledshowSkylightStretch(bool checked)
{
    if(checked == true)
    {
        g_param->bShowBit = false;
        g_param->bShowSkyRight = true;
        ui->doubleSpinBoxContrastUpFactor->setValue(5.0);
        ui->doubleSpinBoxContrastLowFactor->setValue(0);
        ui->doubleSpinBoxContrastUpFactor->setEnabled(true);
        ui->doubleSpinBoxContrastLowFactor->setEnabled(true);
        ui->comboBoxImageBitShow->setEnabled(false);
    }
}

void OnlineTuneDialog::btnToggleddisply(bool checked)
{
    if(checked == true)
    {
        g_param->focus = 0;
    }
}

void OnlineTuneDialog::btnToggleddisplyC(bool checked)
{
    if(checked == true)
    {
        g_param->focus = 1;
    }
}
void OnlineTuneDialog::btnToggleddisplyLU(bool checked)
{
    if(checked == true)
    {
        g_param->focus = 2;
    }
}
void OnlineTuneDialog::btnToggleddisplyRU(bool checked)
{
    if(checked == true)
    {
        g_param->focus = 3;
    }
}
void OnlineTuneDialog::btnToggleddisplyLD(bool checked)
{
    if(checked == true)
    {
        g_param->focus = 4;
    }
}
void OnlineTuneDialog::btnToggleddisplyRD(bool checked)
{
    if(checked == true)
    {
        g_param->focus = 5;
    }
}

void OnlineTuneDialog::setG400CameraPtr(G400Camera *g400_camera)
{
    m_g400_camera = g400_camera;
}

void OnlineTuneDialog::onG400CamerasaveimagestateChange(int index)
{
    //if(m_g400_camera != NULL)
    {
        saveimagestate = index;
    }
}

void OnlineTuneDialog::onG400Camerastartsaveimage()
{
    //if(m_g400_camera != NULL)
    {
        switch(saveimagestate)
        {
        case 0:
            g_param->startsavejpg = true;
            break;
        case 1:
            g_param->startsavetiff = true;
            break;
        case 2:
            g_param->startsavefits = true;
            g_param->b_savefits = true;
            g_param->flag_hz = true;
            g_param->saveimageWaitCondition.wakeAll();
            break;
        case 3:
            g_param->startsaveraw = true;
            break;
        default:
            g_param->startsavetiff = true;
            break;
        }
        ui->pushButtonstartsaveimage->setEnabled(false);
        ui->pushButtonstopsaveimage->setEnabled(true);
        m_recordBarTimer->start();
        ui->progressBarsaveimage->setFormat("正在存储");
        ui->progressBarsaveimage->setTextVisible(true);
    }
}

void OnlineTuneDialog::onG400Camerastopsaveimage()
{
    //if(m_g400_camera != NULL)
    {
        g_param->startsavejpg = false;
        g_param->startsavetiff = false;
        g_param->startsaveraw = false;
        g_param->startsavefits = false;
        g_param->b_savefits = false;
        ui->pushButtonstartsaveimage->setEnabled(true);
        ui->pushButtonstopsaveimage->setEnabled(false);
        m_recordBarTimer->stop();
        m_recordInt = 0;
        ui->progressBarsaveimage->setValue(0);
        ui->labelsaveimage->setText(QString::number(0)+"%");
        ui->progressBarsaveimage->setTextVisible(false);
    }
}


void OnlineTuneDialog::onG400CameraAuxiliaryLine(int state)
{
    //if(m_g400_camera != NULL)
    {
        g_param->AuxiliaryLine = (state == 2);
    }
}

void OnlineTuneDialog::onG400Detect(int state)
{
    //if(m_g400_camera != NULL&&g_param->flag == true)
    {
        //g_param->trackParam.state = TRACK;

        g_param->detect_flag = (state == 2);
        if(g_param->detect_flag == false)
        {
            g_param->trackParam.bAutoDetect2Track = false;
            g_param->trackParam.state = DETECT;
        }
    }
}

void OnlineTuneDialog::onDisplayContrastUpFactor(double val)
{
    //if(m_g400_camera != NULL)
    {
        g_param->displayParam.IR_up_factor = val;
    }

}

void OnlineTuneDialog::onDisplayContrastLowFactor(double val)
{
    //if(m_g400_camera != NULL)
    {
        g_param->displayParam.IR_low_factor = val;
    }

}

void OnlineTuneDialog::onSaveImage()
{
    //if(m_g400_camera != NULL)
    {
        switch(saveimagestate)
        {
        case 0:
            g_param->savejpg = true;
            break;
        case 1:
            g_param->savetiff = true;
            break;
        case 2:
            g_param->savefits = true;
            g_param->flag_hz = true;
            g_param->saveimageWaitCondition.wakeAll();           
            break;
        case 3:
            g_param->saveraw = true;
            break;
        default:
            g_param->savetiff = true;
            break;
        }
    }

}

void OnlineTuneDialog::onTrackChangeThresh_0(double val)
{
    g_param->trackParam.thresh_lost = val;

}

void OnlineTuneDialog::onTrackChangeThresh_1(double val)
{
    g_param->trackParam.thresh_occlude = val;

}

void OnlineTuneDialog::onTrackChangeThresh_3(int val)
{
    g_param->trackParam.occlude_time = val;

}

void OnlineTuneDialog::btnToggledGuideModeTradition(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.bAutoDetect2Track = false;
        g_param->trackParam.state = DETECT;
        g_param->servoXXTParam.guideMode = 1;
        ui->spinBoxSetTrackGateSize->setValue(128);
        ui->groupBox_29->setEnabled(true);
    }
}

void OnlineTuneDialog::btnToggledGuideModeSinglerod(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.bAutoDetect2Track = false;
        g_param->trackParam.state = DETECT;
        g_param->servoXXTParam.guideMode = 0;
        ui->spinBoxSetTrackGateSize->setValue(1280);
        g_param->yolo_res.boxes.clear();
        g_param->yolo_res.classNamesID.clear();
        g_param->yolo_res.classNamesVec.clear();
        g_param->yolo_res.prob.clear();
        ui->groupBox_29->setEnabled(false);
    }
}

void OnlineTuneDialog::onTrackChangeTrackGate(int val)
{
    if( val != g_param->trackParam.trackGateSize.width || val != g_param->trackParam.trackGateSize.height)
    {
        g_param->trackParam.trackGateSize = cv::Size2d(val, val);
        g_param->trackParam.bChangeTrackGateSize = true;
    }
}

void OnlineTuneDialog::btnToggledTrackTradition(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.bTrackTradition = true;
        ui->groupBox_30->setEnabled(false);
    }
}

void OnlineTuneDialog::btnToggledTrackAI_1(bool checked)
{
    if(checked == true)
    {
        //g_param->trackParam.use_scale = false;
        g_param->trackParam.bTrackTradition = false;
        ui->groupBox_30->setEnabled(true);
        //m_track.init();
    }
}

void OnlineTuneDialog::btnToggledTrackAI_2(bool checked)
{
    if(checked == true)
    {
        qDebug()<<"bbbbbbbbbbbbbbbb";
        g_param->trackParam.use_scale = true;
        g_param->trackParam.bTrackTradition = false;
        ui->groupBox_30->setEnabled(true);
        m_track.init();
    }
}

void OnlineTuneDialog::btnToggledModeTraditionXingxin(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 0;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionZhixin(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 1;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionUp(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 2;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionDown(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 3;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionLeft(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 4;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionRight(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 5;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionLeftUp(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 6;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionLeftDown(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 7;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionRightUp(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 8;
    }
}

void OnlineTuneDialog::btnToggledModeTraditionRightDown(bool checked)
{
    if(checked == true)
    {
        g_param->trackParam.modeValueTradition = 9;
    }
}

void OnlineTuneDialog::ImageProcessingLoadPath()
{
    g_param->LoadPath = QFileDialog::getOpenFileName(NULL,"图片处理","/home/pi/","Images(*.tif)");
    ui->textEditImagePath->setText(g_param->LoadPath);
    qDebug()<<"g_param->BmpLoadPath"<<g_param->LoadPath;
}

void OnlineTuneDialog::ImageProcessingDisplayStart()
{
    g_param->ImageProcessingdisplaystart = true;
    ui->comboBoxType->setEnabled(false);
}

void OnlineTuneDialog::ImageProcessingDisplayEnd()
{
    g_param->ImageProcessingdisplayend = true;
    ui->textEditImagePath->clear();
    ui->checkBoxStartMeasurement->setChecked(false);
    ui->comboBoxType->setEnabled(true);

}
void OnlineTuneDialog::ImageProcessingStartMeasurement(int state)
{
    g_param->StartMeasurement = (state == 2);
    g_param->Measurement = (state == 2);
    if(g_param->Measurement == false)
    {
        g_param->MeasurementState = 0;
    }
}
void OnlineTuneDialog::ImageProcessingMeasurementShape(int index)
{
    g_param->MeasurementShape = index;
    switch(index)
    {
    case 0:
        ui->label_30->setText("起始位点");
        ui->label_31->setText("结束位点");
        ui->label_32->setText("水平距离");
        ui->label_33->setText("垂直距离");
        ui->label_34->setText("直线距离");
        break;
    case 1:
        ui->label_30->setText("左上位点");
        ui->label_31->setText("右下位点");
        ui->label_32->setText("水平宽度");
        ui->label_33->setText("垂直宽度");
        ui->label_34->setText("区域面积");
        break;
    case 2:
        ui->label_30->setText("圆心位点");
        ui->label_31->setText("边缘位点");
        ui->label_32->setText("半径长度");
        ui->label_33->setText("直径长度");
        ui->label_34->setText("区域面积");
        break;
    default:
        ui->label_30->setText("起始位点");
        ui->label_31->setText("结束位点");
        ui->label_32->setText("水平距离");
        ui->label_33->setText("垂直距离");
        ui->label_34->setText("直线距离");
        break;
    }
}

void OnlineTuneDialog::ImageProcessingDataEmpty()
{
    g_param->MeasurementState = 0;
    ui->lcdNumberStartXY->display("0");
    ui->lcdNumberEndXY->display("0");
    ui->lcdNumberHorizontalDistance->display("0");
    ui->lcdNumberVerticalDistance->display("0");
    ui->lcdNumberRegionalArea->display("0");
}

//void OnlineTuneDialog::OpenURL()
//{
////    QDesktopServices::openUrl(QUrl(QLatin1String("http://blog.const.net.cn")));

//    bool is_open = QDesktopServices::openUrl(QUrl("http://www.csdn.net",QUrl::TolerantMode));
//    qDebug()<<"is_open"<<is_open;
//}

void OnlineTuneDialog::OpenSoftwareManual()
{
    QDesktopServices::openUrl(QUrl("file:///home/pi/hdd/OrionCamera.pdf",QUrl::TolerantMode));
}

void OnlineTuneDialog::saveHistogram(QString path,int S,Mat D)
{
    QFile file(path);
    if(file.open(QFile::WriteOnly|QFile::Truncate))
    {
        QTextStream in(&file);
        for(int iii = 0 ;iii < S ;iii ++)
        {
            in<<iii<<"\t"<<D.at<float>(0,iii)<<"\n";
        }
    }
    file.close();
}

void OnlineTuneDialog::saveProjection(QString path,int S,Mat D)
{
    QFile file(path);
    if(file.open(QFile::WriteOnly|QFile::Truncate))
    {
        QTextStream in(&file);
        for(int iii = 0 ;iii < S ;iii ++)
        {
            in<<iii<<"\t"<<D.at<ushort>(0,iii)*2048<<"\n";
        }
    }
    file.close();
}

void OnlineTuneDialog::Delay_MSec(unsigned int msec)
{
    QEventLoop loop;
    QTimer::singleShot(msec, &loop, SLOT(quit()));
    loop.exec();
}

void OnlineTuneDialog::onC640CameraState()
{
    int Len = g_param->controlParam.TestCameraState.length();
    char temp[Len];
    int r;
    uint32_t count = Len;
    QByteArray arr;
    for(int i = 0; i < Len; i = i + 2)
    {
        int n = i/2;
        arr[n] = g_param->controlParam.TestCameraState.mid(i,2).toInt(nullptr,16);
        temp[n] = arr.at(n);
    }
    r = uart_write(0,temp,count);
    if(r != count)
    {
        qDebug()<<"TestCameraState is Error";
    }
    else
    {
        qDebug()<<"TestCameraState is ok";
    }
}

void OnlineTuneDialog::CameraSetCameraLinkMode(int state)
{
    g_param->cameraconfigParam.CameraLinkMode = state;
}

void OnlineTuneDialog::CameraSetImageFormat(int state)
{
    g_param->cameraconfigParam.ImageFormat = state;
}

void OnlineTuneDialog::CameraImageLive(bool checked)
{
    if(checked == true)
    {
        g_param->b_showBackgroundMap = true;
        g_param->camerafps = 0;
        g_param->mousePressPos.x = 0;
        g_param->mousePressPos.y = 0;
        g_param->m_LeftButton = false;
        g_param->cameraconfigParam.CameraLive = true;

        g_param->b_showBackgroundMap = true;
        Delay_MSec(50);
        g_param->b_showBackgroundMap = false;
    }
}

void OnlineTuneDialog::CameraImageunLive(bool checked)
{
    if(checked == true)
    {
        g_param->cameraconfigParam.CameraLive = false;
        g_param->Width = 0;
        g_param->Height = 0;
        g_param->b_showBackgroundMap = true;
        g_param->camerafps = 0;
        g_param->mousePressPos.x = 0;
        g_param->mousePressPos.y = 0;
        g_param->m_LeftButton = false;
        g_param->serial_send_satrt = false;

    }
}

void OnlineTuneDialog::CameraSetImageBit(int val)
{
    g_param->cameraconfigParam.ImageBit = val;
    if(val > 8)
    {
        ui->groupBox_2->setVisible(true);
    }
    else
    {
        ui->groupBox_2->setVisible(false);
    }
}

void OnlineTuneDialog::CameraSetImageTap(int val)
{
    g_param->cameraconfigParam.ImageTap = val;
}

void OnlineTuneDialog::CameraEleImageStab(int state)
{
    g_param->b_EleImageStab = (state == 2);
}

void OnlineTuneDialog::CameraImageEnhancement(int state)
{
    g_param->b_ImageEnhancement = (state == 2);
}
