#include "QImageDisplayLabel.h"

QImageDisplayLabel::QImageDisplayLabel(QWidget *parent)
	: QLabel(parent)
{
	ui.setupUi(this);
    g_param = GlobalParameter::getInstance();
    m_cameraerr = new CameraErr();
    image_1 .load("/home/orangepi/hdd/main/CAMERACONTROL/OR4040FSI.png");
    connect(&m_timer, SIGNAL(timeout()), this, SLOT(onTimerDisplay()));
}

QImageDisplayLabel::~QImageDisplayLabel()
{
	stopDisplay();
}

void QImageDisplayLabel::startDisplay(int ms /*= 40*/)
{
	m_timer.stop();
	m_timer.start(ms);
}

void QImageDisplayLabel::stopDisplay()
{
	m_timer.stop();
}

void QImageDisplayLabel::updateImage(Mat frame)
{
    if(!frame.empty() && frame.size)
    {
        drawMeasurementBox(frame);
       if(g_param->detect_flag == true)
       {
           drawDetectBox(frame);
       }
    }
	if (frame.channels() == 3)
    {
		try
        {
            m_qimage = QImage((const unsigned char*)(frame.data),
                frame.cols, frame.rows, QImage::Format_RGB888);
		}
		catch (cv::Exception* e)
		{
            qDebug() << "QImageDisplayLabel::updateImage exception " << e->what();
		}
	} 
	else
    {
		m_qimage = QImage((const unsigned char*)(frame.data),
			frame.cols, frame.rows, QImage::Format_Indexed8);
    }

 //   if (!m_qimage.isNull()&&g_param->b_showBackgroundMap == false&&g_param->EstimateGather == true)
    if(!m_qimage.isNull())
    {
        g_param->debugParam.displayCount++;
         qDebug() << "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBb_________"<<g_param->show;
        if(g_param->show == true)
        {
            // H264
            //qDebug() << "Display!";
            cv::Mat pushImg;
            cv::resize(frame,pushImg,cv::Size(1920,1080));
            mainSlaver.pushImageToEncodeQueue(pushImg);

            OverlayCharacter();
            this->setPixmap(QPixmap::fromImage(m_qimage));
        }
        else
        {
            g_param->camerafps = 0;
            g_param->mousePressPos.x = 0;
            g_param->mousePressPos.y = 0;
            g_param->m_LeftButton = false;
            m_qimage = image_1;
            OverlayCharacter();
            this->setPixmap(QPixmap::fromImage(m_qimage));
            this->setAttribute(Qt::WA_TranslucentBackground);
            this->show();
        }
	} 
	else
    {
         qDebug() << "CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCb_________"<<g_param->show;
        m_qimage = image_1;
        OverlayCharacter();
        this->setPixmap(QPixmap::fromImage(m_qimage));
        this->setAttribute(Qt::WA_TranslucentBackground);
        this->show();
        if((g_param->b_G400Camera == true || g_param->b_G4040Camera == true || g_param->b_USBCamera == true || g_param->b_C640Camera == true) && g_param->b_showBackgroundMap == false && g_param->HintClose == false)
        {
            g_param->num ++;
            if(g_param->num > 200)
            {
                g_param->num = 200;
                g_param->HintClose = true;
                QDesktopWidget* desktop = QApplication::desktop();
                m_cameraerr->move((desktop->width() - m_cameraerr->width())/2,(desktop->height() - m_cameraerr->height())/2);
                m_cameraerr->show();
            }

        }
    }
}

void QImageDisplayLabel::OverlayCharacter()
{
    m_painter.begin(&m_qimage);
	int len;
    int len_c;
    m_pen.setWidth(2);
    m_pen.setColor(Qt::green);
    m_painter.setPen(m_pen);
	if (g_param->trackParam.state == TRACK)
    {
        int ws = g_param->trackParam.trackGateRoi.width  / 2 + 2;
        int hs = g_param->trackParam.trackGateRoi.height  / 2 + 2;
		if (hs < 4) hs = 4;
        len = hs / 4 + 1;
        int x = g_param->trackParam.trackGateRoi.x + g_param->trackParam.trackGateRoi.width / 2; /// 20190720 wangzy
        int y = g_param->trackParam.trackGateRoi.y + g_param->trackParam.trackGateRoi.height / 2;

        m_painter.drawLine(x - ws, y - hs, x - ws + len, y - hs);
        m_painter.drawLine(x - ws, y - hs, x - ws, y - hs + len);
        m_painter.drawLine(x - ws, y + hs, x - ws + len, y + hs);
        m_painter.drawLine(x - ws, y + hs, x - ws, y + hs - len);
        m_painter.drawLine(x + ws, y - hs, x + ws - len, y - hs);
        m_painter.drawLine(x + ws, y - hs, x + ws, y - hs + len);
        m_painter.drawLine(x + ws, y + hs, x + ws - len, y + hs);
        m_painter.drawLine(x + ws, y + hs, x + ws, y + hs - len);
	}
    /// center cross
    m_pen.setWidth(1);
    m_font.setPointSize(10.5);
    m_pen.setColor(Qt::green);
    m_painter.setPen(m_pen);
    m_painter.setFont(m_font);
    m_painter.setPen(m_pen);
    len = 128;
    len_c = 64;
    if(g_param->AuxiliaryLine == true || g_param->pccontrolparam.CrossSilkDisplay == true)
    {
        m_painter.drawLine(g_param->displayParam.imgSize.width / 2 - len, g_param->displayParam.imgSize.height / 2, g_param->displayParam.imgSize.width / 2 - len_c, g_param->displayParam.imgSize.height / 2);
        m_painter.drawLine(g_param->displayParam.imgSize.width / 2 + len_c, g_param->displayParam.imgSize.height / 2, g_param->displayParam.imgSize.width / 2 + len, g_param->displayParam.imgSize.height / 2);
        m_painter.drawLine(g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 - len, g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 - len_c);
        m_painter.drawLine(g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 + len_c, g_param->displayParam.imgSize.width / 2, g_param->displayParam.imgSize.height / 2 + len);
    }
    /// info
    QString info_1 = QString(" FPS %1")\
            .arg(QString("%1").arg(g_param->camerafps,4,'f',2,QLatin1Char('0')));
    m_painter.drawText(m_qimage.rect(),Qt::AlignLeft|Qt::AlignTop,info_1);
    QString info_2 = QString("  POS [%1%2 , %3%4]   %5")\
            .arg(g_param->mousePressPos.x == 0 ? "" : fuhaox ? "+" : "-")\
            .arg(QString::number(g_param->mousePressPos.x,'f',2))\
            .arg(g_param->mousePressPos.y == 0 ? "" : fuhaoy ? "+" : "-")\
            .arg(QString::number(g_param->mousePressPos.y,'f',2))\
            .arg(g_param->m_LeftButton ? "GRAYVAL:" + QString::number(g_param->grayval) : "");
    m_painter.drawText(m_qimage.rect(),Qt::AlignLeft|Qt::AlignBottom,info_2);

    m_painter.end(); ///
}



void QImageDisplayLabel::drawMeasurementBox(Mat frame)
{
    if(frame.channels() == 4)
    {
        cvtColor(frame, frame, COLOR_BGRA2BGR);
    }
    int thickniss = 1;
    switch(g_param->MeasurementState)
    {
    case 0:

        break;
    case 1:
        circle(frame,g_param->MeasuremenStartmouseClickPos,3,Scalar(0,255,120),-1);
        if(g_param->Measurement == true)
        {
            g_param->StartMeasurement = true;
        }
        break;
    case 2:
        if(g_param->MeasurementShape == 1)
        {
            cv::Rect rect;
            int w;
            int h;
            w = g_param->MeasuremenEndmouseClickPos.x - g_param->MeasuremenStartmouseClickPos.x;
            rect.width = abs(w);
            g_param->HorizontalDistance = QString::number(rect.width);
            if(w > 0)
            {
                rect.x = g_param->MeasuremenStartmouseClickPos.x;
            }
            else
            {
                rect.x = g_param->MeasuremenEndmouseClickPos.x;
            }
            h = g_param->MeasuremenEndmouseClickPos.y - g_param->MeasuremenStartmouseClickPos.y;
            if(h > 0)
            {
                rect.y = g_param->MeasuremenStartmouseClickPos.y;
            }
            else
            {
                rect.y = g_param->MeasuremenEndmouseClickPos.y;
            }
            rect.height = abs(h);
            g_param->VerticalDistance = QString::number(rect.height);
            float s = rect.width * rect.height;
            g_param->RegionalArea = QString::number(s);
            rectangle(frame,rect,Scalar(0,255,120),thickniss);
        }
        else if(g_param->MeasurementShape == 2)
        {
            int w;
            int h;
            w = abs(g_param->MeasuremenEndmouseClickPos.x - g_param->MeasuremenStartmouseClickPos.x);
            h = abs(g_param->MeasuremenEndmouseClickPos.y - g_param->MeasuremenStartmouseClickPos.y);
            int r = sqrt(w * w + h * h);
            g_param->HorizontalDistance = QString::number(r);
            g_param->VerticalDistance = QString::number(2*r);
            float s = 3.14 * r * r;
            g_param->RegionalArea = QString::number(s);
            circle(frame,g_param->MeasuremenStartmouseClickPos,r,Scalar(0,255,120),thickniss);
        }
        else if(g_param->MeasurementShape == 0)
        {
            line(frame,g_param->MeasuremenStartmouseClickPos,g_param->MeasuremenEndmouseClickPos,Scalar(0,255,120),thickniss);
            float h = abs(g_param->MeasuremenStartmouseClickPos.x - g_param->MeasuremenEndmouseClickPos.x);
            float v = abs(g_param->MeasuremenStartmouseClickPos.y - g_param->MeasuremenEndmouseClickPos.y);
            float l = sqrt( h * h + v * v);
            g_param->HorizontalDistance = QString::number(h);
            g_param->VerticalDistance = QString::number(v);
            g_param->RegionalArea = QString::number(l);
        }
        if(g_param->Measurement == true)
        {
            g_param->StartMeasurement = true;
        }
        break;
    default:

        break;

    }

}

void QImageDisplayLabel::drawDetectBox(Mat frame)
{
    if(g_param->detect_flag == true)
    {
        if(g_param->yolo_res.boxes.size() <= 0)
        {
            return;
        }
        if(frame.channels() == 4)
        {
            cvtColor(frame, frame, COLOR_BGRA2BGR);
        }
        double fontScale = 0.5;
        int thickniss = 1;
        if(g_param->displayParam.imgSize.width < 800)
        {
            fontScale = 0.5;
            thickniss = 1;
         }
        else
        {
            fontScale = 0.9;
            thickniss = 2;
         }
         int baseLine = 0;
        for(size_t i=0;i < g_param->yolo_res.boxes.size();i++)
        {
            if(i >= g_param->yolo_res.classNamesID.size() || i >= g_param->yolo_res.prob.size())
            {
                qDebug() << "detection sync";
                break;
            }
            int offset = g_param->yolo_res.classNamesID[i]*123457 % 80;
            float red = 255*get_color(2,offset,80);
            float green = 255*get_color(1,offset,80);
            float blue = 255*get_color(0,offset,80);

            rectangle(frame,g_param->yolo_res.boxes[i],Scalar(blue,green,red),thickniss);

            string label_prob, label, label_id;
            if(g_param->yolo_res.classNamesID[i] >= (int)g_param->yolo_res.classNamesVec.size())
            {
                label = "unknow";
            }
            else
            {
                label_prob = format("%.2f", g_param->yolo_res.prob[i]);
                label = string(g_param->yolo_res.classNamesVec[g_param->yolo_res.classNamesID[i]]) + ":" + label_prob;
                Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, fontScale, thickniss, &baseLine);
                putText(frame, label, Point(g_param->yolo_res.boxes[i].x + g_param->yolo_res.boxes[i].width - labelSize.width, g_param->yolo_res.boxes[i].y - labelSize.height - 2),
                        FONT_HERSHEY_SIMPLEX,fontScale, Scalar(red, blue, green),thickniss);
            }

            label_id = format("%i", i+1 );
            putText(frame, label_id, Point(g_param->yolo_res.boxes[i].x, g_param->yolo_res.boxes[i].y + getTextSize(label_id, FONT_HERSHEY_SIMPLEX, fontScale, thickniss, &baseLine).height + 2),
                    FONT_HERSHEY_SIMPLEX, fontScale, Scalar(red, blue, green),thickniss);
        }
    }
    else
    {
        g_param->yolo_res.boxes.clear();
        g_param->yolo_res.classNamesID.clear();
        g_param->yolo_res.classNamesVec.clear();
        g_param->yolo_res.prob.clear();
    }




}
void QImageDisplayLabel::drawPred(int classId, float conf, int left, int top, int right, int bottom, Mat &frame)
{
    //Draw a rectangle displaying the bounding box
    rectangle(frame, Point(left, top), Point(right, bottom), Scalar(255, 0, 0), 3);

    //Get the label for the class name and its confidence
    string label = format("%.5f", conf);
    if (!g_param->yolo_res.classNamesVec.empty())
    {
        if(classId < (int)g_param->yolo_res.classNamesVec.size())
        {
            label = g_param->yolo_res.classNamesVec[classId] + ":" + label;
        }
        else
        {
            label = "unknow:" + label;
            //return;
        }
    }

    //Display the label at the top of the bounding box
    int baseLine;
    Size labelSize = getTextSize(label, FONT_HERSHEY_SIMPLEX, 0.5, 1, &baseLine);
    top = max(top, labelSize.height);
    rectangle(frame, Point(left, top - round(1.5*labelSize.height)), Point(left + round(1.5*labelSize.width), top + baseLine), Scalar(255, 255, 255), FILLED);
    putText(frame, label, Point(left, top), FONT_HERSHEY_SIMPLEX, 0.5, Scalar(0, 0, 0), 1);
}

float QImageDisplayLabel::get_color(int c, int x, int max)
{
    float colors[6][3] = { {1,0,1}, {0,0,1},{0,1,1},{0,1,0},{1,1,0},{1,0,0} };
    float ratio = ((float)x/max)*5;
    int i = floor(ratio);
    int j = ceil(ratio);
    ratio -= i;
    float r = (1-ratio) * colors[i][c] + ratio*colors[j][c];
    return r;
}
void QImageDisplayLabel::onTimerDisplay()
{
    updateImage(g_param->imageDisplay);
}

void QImageDisplayLabel::mousePressEvent(QMouseEvent *event)
{
	if (event->button() == Qt::LeftButton )
	{
        int x = (int)((float)event->pos().x() / g_param->displayParam.imgScale.x);
        int y = (int)((float)event->pos().y() / g_param->displayParam.imgScale.y);
	
		if (x < g_param->displayParam.imgSize.width && y < g_param->displayParam.imgSize.height)
        {
			g_param->displayParam.mouseClickPos.x = x;
			g_param->displayParam.mouseClickPos.y = y;

            if(x - 512 < 0)
            {
                fuhaox = false;
                g_param->mousePressPos.x = 512 - x;
            }
            else
            {
                fuhaox = true;
                g_param->mousePressPos.x = x - 512;
            }
            if(512 - y < 0)
            {
                fuhaoy = false;
                g_param->mousePressPos.y = y - 512;
            }
            else
            {
                fuhaoy = true;
                g_param->mousePressPos.y = 512 - y;
            }
            g_param->m_LeftButton = true;
		}        
	}
}

void QImageDisplayLabel::wheelEvent(QWheelEvent *event)
{
    if(event->delta()>0)
    {
        if((g_param->focusParam.image_w>20)&&(g_param->focusParam.image_h>20))
        {
            g_param->focusParam.image_w = g_param->focusParam.image_w - 10;
            g_param->focusParam.image_h = g_param->focusParam.image_h - 10;
        }
        if((g_param->focusParam.image_w<=10)&&(g_param->focusParam.image_h<=10))
        {
            g_param->focusParam.image_w = 10;
            g_param->focusParam.image_h = 10;
        }

    }
    else
    {
        if((g_param->focusParam.image_w<500)&&(g_param->focusParam.image_h<500))
        {
            g_param->focusParam.image_w = g_param->focusParam.image_w + 10;
            g_param->focusParam.image_h = g_param->focusParam.image_h + 10;
        }
        if((g_param->focusParam.image_w>=500)&&(g_param->focusParam.image_h>=500))
        {
            g_param->focusParam.image_w = 500;
            g_param->focusParam.image_h = 500;
        }
    }
}


void QImageDisplayLabel::mouseDoubleClickEvent(QMouseEvent *event)
{
    g_param->displayParam.imgScale.x = width() / (double)g_param->displayParam.imgSize.width;
    g_param->displayParam.imgScale.y = height() / (double)g_param->displayParam.imgSize.height;

	if (event->button() == Qt::LeftButton)
    {
        g_param->focusParam.mouseDoubleClick = true;
        int x = (int)((float)event->pos().x() / g_param->displayParam.imgScale.x);
        int y = (int)((float)event->pos().y() / g_param->displayParam.imgScale.y);
		if (x < g_param->displayParam.imgSize.width && y < g_param->displayParam.imgSize.height)
		{
			g_param->displayParam.mouseClickPos.x = x;
			g_param->displayParam.mouseClickPos.y = y;

            if(g_param->StartMeasurement == true)
            {
                if(g_param->MeasurementState == 0)
                {
                    g_param->MeasuremenStartmouseClickPos.x = x;
                    g_param->MeasuremenStartmouseClickPos.y = y;
                    if(x - 512 < 0)
                    {
                        g_param->MeasurementStartX = "-" + QString::number(512 - x);
                    }
                    else if(x - 512 > 0)
                    {
                        g_param->MeasurementStartX = "+" + QString::number(x - 512);
                    }
                    else if(x - 512 == 0)
                    {
                        g_param->MeasurementStartX = "0";
                    }
                    if(512 - y < 0)
                    {
                        g_param->MeasurementStartY = "-" + QString::number(y - 512);
                    }
                    else if(512 - y > 0)
                    {
                        g_param->MeasurementStartY = "-" + QString::number(512 - y);
                    }
                    else if(512 - y == 0)
                    {
                        g_param->MeasurementStartY = "0";
                    }
                }
                if(g_param->MeasurementState == 1)
                {
                    g_param->MeasuremenEndmouseClickPos.x = x;
                    g_param->MeasuremenEndmouseClickPos.y = y;
                    if(x - 512 < 0)
                    {
                        g_param->MeasurementEndX = "-" + QString::number(512 - x);
                    }
                    else if(x - 512 > 0)
                    {
                        g_param->MeasurementEndX = "+" + QString::number(x - 512);
                    }
                    else if(x - 512 == 0)
                    {
                        g_param->MeasurementEndX = "0";
                    }
                    if(512 - y < 0)
                    {
                        g_param->MeasurementEndY = "-" + QString::number(y - 512);
                    }
                    else if(512 - y > 0)
                    {
                        g_param->MeasurementEndY = "-" + QString::number(512 - y);
                    }
                    else if(512 - y == 0)
                    {
                        g_param->MeasurementEndY = "0";
                    }
                }
                g_param->MeasurementState ++;
                g_param->StartMeasurement = false;
            }

            g_param->trackParam.bManualSelect = true;
            qDebug() << "Maunal click pos: " << x << y;
		}
	}
}
void QImageDisplayLabel::Delay_MSec(unsigned int msec)
{
    QEventLoop loop;
    QTimer::singleShot(msec, &loop, SLOT(quit()));
    loop.exec();
}

